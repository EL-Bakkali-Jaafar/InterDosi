/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/
package interdosi_gui;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
 
/**
 *
 * @author jaafar
 */

public class StlDataExtraction {
String STL_FILE_NAME="";
List<Vec3D> array_vertex ;
List<Integer> IndexOfVertexArray;
float MaxXAbsoluteValue=0;
float MaxYAbsoluteValue=0;
float MaxZAbsoluteValue=0;
float MaxXValue=0;
float MinXValue=0;
float MinYValue=0;
float MinZValue=0;
float MaxYValue=0;
float MaxZValue=0;
float[] arrayMaxXValue ;
int TotalNumberOfLinesInSTLFile; 
void  SetSTLFileName(String   _value){
this.STL_FILE_NAME=_value;
};
float returnHighest(float[] numbers) {
boolean firstTime = true;
float highest = 0;
for(int i = 0; i < numbers.length; i++) {
if(firstTime || numbers[i] > highest) {
highest = numbers[i];
firstTime = false;
}
}
return highest;
}

float returnLowest(float[] numbers) {
float Lowest = numbers[0];
for(int i = 0; i < numbers.length; i++) {
if(  numbers[i] < Lowest) {
Lowest = numbers[i];
}
}
return Lowest;
}
void obtenainMinXYZValues( List<Vec3D>  _arrayvalue){
 float x_value=  _arrayvalue .get(0).x;
 float y_value=  _arrayvalue .get(0).y;
 float z_value=  _arrayvalue .get(0).z;
 for (int i=0; i<      _arrayvalue.size();i++)
 {
 if ( x_value  <   _arrayvalue .get(i).x) {this.MinXValue=x_value;}   else {this.MinXValue= _arrayvalue .get(i).x;}
 if ( y_value  <   _arrayvalue .get(i).y) {this.MinYValue=y_value;}   else {this.MinYValue= _arrayvalue .get(i).y;}
 if (z_value  <   _arrayvalue .get(i).z) {this.MinZValue=z_value;}   else {this.MinZValue= _arrayvalue .get(i).z;}
}
}
void obtenainMaxXYZValues( List<Vec3D>  _arrayvalue){
 float x_value=  _arrayvalue .get(0).x;
 float y_value=  _arrayvalue .get(0).y;
 float z_value=  _arrayvalue .get(0).z;    
for (int i=0; i<      _arrayvalue.size();i++)
{
if ( x_value >  _arrayvalue .get(i).x) {this.MaxXValue=x_value;}   else {this.MaxXValue= _arrayvalue .get(i).x;}
if ( y_value  >   _arrayvalue .get(i).y) {this.MaxYValue=y_value;}   else {this.MaxYValue= _arrayvalue .get(i).y;}
if (z_value  >  _arrayvalue .get(i).z) {this.MaxZValue=z_value;}   else {this.MaxZValue= _arrayvalue .get(i).z;}
}
}
void obtenainMaxXAbsoluteValue(float _value){
if (Math.abs(_value) > Math.abs(this.MaxXAbsoluteValue)) {this.MaxXAbsoluteValue=Math.abs(_value);}
}
void obtenainMaxYAbsoluteValue(float _value){
if (Math.abs(_value) > Math.abs(this.MaxYAbsoluteValue)) {this.MaxYAbsoluteValue=Math.abs(_value);}
}
void obtenainMaxZAbsoluteValue(float _value){
if (Math.abs(_value)> Math.abs(this.MaxZAbsoluteValue)) {this.MaxZAbsoluteValue=Math.abs(_value);}
}
void ReadSTLDataIntoArrayDataF() throws IOException
{
long starttime =  System.nanoTime();
String  vertex_keyword="vertex";
int j=0;
array_vertex = new ArrayList<>();
IndexOfVertexArray = new ArrayList<> (); 
List<String> data =Files.readAllLines(Paths.get(STL_FILE_NAME));
for (int i=0; i< data.size();  i++){
String strLine;
strLine = data.get(i);
if (strLine.contains(vertex_keyword)) {
strLine = strLine.replace(vertex_keyword, "");
String[]  vertex_str = strLine.split("\\s+");
Vec3D myVec3D = new Vec3D();
myVec3D.set(Float.parseFloat(vertex_str[1]),Float.parseFloat(vertex_str[2]), Float.parseFloat(vertex_str[3]));
if (  array_vertex.contains(myVec3D)==false )
{  
array_vertex.add(myVec3D);
obtenainMaxXAbsoluteValue(myVec3D.x);  
obtenainMaxYAbsoluteValue(myVec3D.y);  
obtenainMaxZAbsoluteValue(myVec3D.z); 
IndexOfVertexArray.add(j);
j++;
}
else
{  IndexOfVertexArray.add(  array_vertex.indexOf(myVec3D));}
}
}
long endtime =  System.nanoTime();
System.out.println("STLtoGDML--> Reading elapsed time (s): "+(endtime -starttime)/1000000000);
 }
 
void  ReadSTLDataIntoArrayData() throws FileNotFoundException, IOException{
long starttime =  System.nanoTime();
String  vertex_keyword="vertex";
int j=0;
int i=0;
int l=0;
int v=0;
array_vertex = new ArrayList<>();
IndexOfVertexArray = new ArrayList<> ();
 try {
FileInputStream fstream = new FileInputStream(STL_FILE_NAME);
 
try ( DataInputStream in = new DataInputStream(fstream)) {
BufferedReader br = new BufferedReader(new InputStreamReader(in) );
String strLine;
 while ((strLine = br.readLine()) != null) 
{
if (strLine.contains(vertex_keyword)) {
strLine = strLine.replace(vertex_keyword, "");
String[]  vertex_str = strLine.split("\\s+");
Vec3D myVec3D = new Vec3D( Float.parseFloat(vertex_str[1]),Float.parseFloat(vertex_str[2]), Float.parseFloat(vertex_str[3]));
//if (  array_vertex.contains(myVec3D)==false )
 if( myVec3D.Vec3DExist( array_vertex,myVec3D)==false)   
 {  
 array_vertex.add(myVec3D);
 
obtenainMaxXAbsoluteValue(myVec3D.x);  
obtenainMaxYAbsoluteValue(myVec3D.y);  
obtenainMaxZAbsoluteValue(myVec3D.z); 
IndexOfVertexArray.add(j);
j++;
}
else
{  IndexOfVertexArray.add( myVec3D.IndexVec3D (array_vertex,  myVec3D  )  );
 
 }}
i++;
} }}
catch (IOException | NumberFormatException e)
{
System.err.println("Error  1: " + e.getMessage());
}
 obtenainMinXYZValues( array_vertex);
 obtenainMaxXYZValues( array_vertex);
}   

void  SetTotalNumberOfLinesInSTLFile(int  _value){
this.TotalNumberOfLinesInSTLFile=_value;
}
List<Vec3D>  Getarray_vertex( ){
return this.array_vertex ;
}
 List<Integer>   GetIndexOfVertexArray(  ){
return this.IndexOfVertexArray ;
}
}