/*
 * The MIT License
 *
 * Copyright 2018 jupiter.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package interdosi_gui;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
/**
 * based on a treeviewer class developed by Gilbert Le Blanc, link:https://stackoverflow.com/questions/23804675/list-files-and-directories-with-jtree-and-file-in-java
 * @author jupiter
 */ 
public class FileExplorer implements Runnable {
 
    private DefaultMutableTreeNode root;

    private DefaultTreeModel treeModel;

      JTree tree;
public String  directory;
public JInternalFrame InternalFrame;
    
    
    void OpenFile(String _File){
    
    try {
      Desktop desktop = null;
      if (Desktop.isDesktopSupported()) {
        desktop = Desktop.getDesktop();
      }

       desktop.open(new File(_File));
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    
    
    }
    
        @Override

    public void run() {
    JFrame frame = new JFrame("File Browser");

        File fileRoot = new File(this.directory);
        root = new DefaultMutableTreeNode(new FileNode(fileRoot));
        treeModel = new DefaultTreeModel(root);

       tree = new JTree(treeModel);
       
tree.addTreeSelectionListener(new TreeSelectionListener() {
    public void valueChanged(TreeSelectionEvent e) {
        TreePath tp = tree.getSelectionPath();
        if (tp != null) {
            Object filePathToAdd = tp.getLastPathComponent();
            String s= tp.getParentPath().toString();
            String replace0 = s.replace(", ", "");
            String replace = replace0.replace("]", "");
            String replace1 = replace.replace("[", "");
            String replace2 = replace1.replace(filePathToAdd.toString(), "");
            String replace3 = replace2.replace("Dosimetric_files", "");

            
            

            OpenFile(directory+"/"+replace3+"/"+filePathToAdd.toString());
                        System.out.println( directory+"/"+replace3+"/"+filePathToAdd.toString());

             
        }
    }
});

        tree.setShowsRootHandles(true);
        JScrollPane scrollPane = new JScrollPane(tree);

        frame.add(scrollPane);
        frame.setLocationByPlatform(true);
        frame.setSize(380, 380);
      //  frame.pack();
        //
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        CreateChildNodes ccn = 
                new CreateChildNodes(fileRoot, root);
        new Thread(ccn).start();
    }
    
    
     
public void SetDirectory(String _dir){
this.directory=_dir;
}
public void SetFrame(JInternalFrame _InternalFrame ){
this.InternalFrame=_InternalFrame ;


}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new FileExplorer());
    }

    public class CreateChildNodes implements Runnable {

        private DefaultMutableTreeNode root;

        private File fileRoot;

        public CreateChildNodes(File fileRoot, 
                DefaultMutableTreeNode root) {
            this.fileRoot = fileRoot;
            this.root = root;
        }

        @Override
        public void run() {
            createChildren(fileRoot, root);
        }

        private void createChildren(File fileRoot, 
                DefaultMutableTreeNode node) {
            File[] files = fileRoot.listFiles();
            if (files == null) return;

            for (File file : files) {
             if (!file.isHidden())

             {
                DefaultMutableTreeNode childNode = 
                        new DefaultMutableTreeNode(new FileNode(file));
                node.add(childNode);
                if (file.isDirectory()) {
                    createChildren(file, childNode);
                }
            }
           }    
        }

    }

    public class FileNode {

        private final File file;

        public FileNode(File file) {
            this.file = file;
        }

        @Override
        public String toString() {
            String name = file.getName();
            if (name.equals("")) {
                return file.getAbsolutePath();
            } else {
                return name;
            }
        }
    }

}