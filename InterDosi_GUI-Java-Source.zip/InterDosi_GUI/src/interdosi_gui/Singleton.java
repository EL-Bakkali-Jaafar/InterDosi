/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/
package interdosi_gui;

/**
 *
 * @author jaafar
 */
public class Singleton {
 private String geant4_installation_directory;
 int Number_Of_Voxels_Along_x = 0;
 int Number_Of_Voxels_Along_y = 0;
 int Number_Of_Voxels_Along_z = 0;     
      
      
   private static Singleton singleton = new Singleton( );

private Singleton(){ }
   
   /* Static 'instance' method */
   public static Singleton getInstance( ) {
      return singleton;
   }
   public void Set_Geant4_installation_directory(String _geant4_installation_directory){
  
  this.geant4_installation_directory=_geant4_installation_directory;
  }
 String  Get_Geant4_installation_directory(){
return this.geant4_installation_directory;
  }
  
  public void Set_Number_Of_Voxels_Along_XYZ(int  x, int y,int z){
  
this.Number_Of_Voxels_Along_x=x;
 this.Number_Of_Voxels_Along_y=y;
this.Number_Of_Voxels_Along_z=z;
   }
 int  Get_Number_Of_Voxels_Along_X(){
 return this.Number_Of_Voxels_Along_x;
  }
int  Get_Number_Of_Voxels_Along_Y(){
 return this.Number_Of_Voxels_Along_y;
  }

int  Get_Number_Of_Voxels_Along_Z(){
return this.Number_Of_Voxels_Along_z;
}
}

