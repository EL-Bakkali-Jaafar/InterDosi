/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/ 
package interdosi_gui;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author jaafar
 */
public class VertexInGdmlCode {
 List<Vec3D> array_vertex ;
 List<String> solid_name;
 String VertexInGdmlCode_str="" ;
 List<Integer>  IndexOfVertexArray;
 String tesslated_solid_file_name ;
void InitializeVertexData(){
StringBuilder sb = new   StringBuilder("");
this. solid_name = new  ArrayList<>();
String  keyword="",Pos_x_str="",Pos_y_str="",Pos_z_str="";
for ( int i=0; i< this.array_vertex.size();i++)
{
this. solid_name.add(this.tesslated_solid_file_name+"_"+ i );
Pos_x_str= String.valueOf(this.array_vertex.get(i).x);
Pos_y_str= String.valueOf(this.array_vertex.get(i).y);
Pos_z_str= String.valueOf(this.array_vertex.get(i).z);
keyword="<position name=\""+this.solid_name.get(i)+"\" unit=\"mm\" x=\""+Pos_x_str+"\" y=\""+Pos_y_str+"\" z=\""+Pos_z_str+"\"/>";
sb.append(keyword+"\n");
}
VertexInGdmlCode_str= sb.toString();
}    
void  SetTesslated_Solid_File_Name( String  data){
this.tesslated_solid_file_name= data;
}
void   SetArrayVertex( List<Vec3D>  data){
this.array_vertex= data;
}
void  SetIndexOfVertexArray( List<Integer>  data)
{
 this.IndexOfVertexArray=data;
}
void ResetAll(){
this.IndexOfVertexArray.clear();
this.array_vertex.clear();
this.tesslated_solid_file_name="";
this.VertexInGdmlCode_str="";
}
}
