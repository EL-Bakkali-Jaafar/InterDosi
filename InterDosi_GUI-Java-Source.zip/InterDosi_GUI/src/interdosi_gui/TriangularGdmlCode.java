/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/ 
package interdosi_gui;

 import java.util.List;

/**
 *
 * @author jaafar
 */
public class TriangularGdmlCode {
List<Vec3D> array_vertex ;
 List<VecInt3D> array_faces;
  List<Integer>  IndexOfVertexArray;
List<String> solid_name ;
 String solid_name_s;
 String tesslated_solid_file_name,Tesslated_gdml_block=" ";
  void  construct_triangular_gdml_codeFromOBJData()
{
      long starttime =  System.nanoTime();
    StringBuilder sb = new   StringBuilder("");

    //TriangularArrayStr = new ArrayList<String>();
    
 String code=   "\n" +"<tessellated aunit=\"deg\" lunit=\"mm\" name=\""+tesslated_solid_file_name+"_Solid"+"\">";
    Tesslated_gdml_block+=code;
      String  triangular_gdml_code="";

   for (int i = 0; i <this.array_faces.size();i++ )
    {
  
 
   
     String  vertex1_str= solid_name_s+"_"+ Integer.toString(array_faces.get(i).x-1);
     String  vertex2_str= solid_name_s+"_"+Integer.toString(array_faces.get(i).y-1);
     String  vertex3_str= solid_name_s+"_"+Integer.toString(array_faces.get(i).z-1);


    triangular_gdml_code="<triangular vertex1=\""+ vertex1_str+"\" vertex2=\""+vertex2_str+"\" vertex3=\""+vertex3_str+"\"/>";

    
   // TriangularArrayStr.add(triangular_gdml_code);
   // Tesslated_gdml_block+=   "\n" +triangular_gdml_code;
   sb.append("\n" +triangular_gdml_code);
 
    }
   Tesslated_gdml_block+=sb.toString();
   
     long endtime =  System.nanoTime();



    }
   
 
 void  construct_triangular_gdml_codeFromSTLData()
{
      long starttime =  System.nanoTime();
    StringBuilder sb = new   StringBuilder("");

    //TriangularArrayStr = new ArrayList<String>();
    
 String code=   "\n" +"<tessellated aunit=\"deg\" lunit=\"mm\" name=\""+tesslated_solid_file_name+"_Solid"+"\">";
    Tesslated_gdml_block+=code;
      String  triangular_gdml_code="";
      
   for (int i = 0; i <this.IndexOfVertexArray.size()-2; i+=3)
    {
  

      String vertex1_str= solid_name.get(IndexOfVertexArray.get(i));
      String vertex2_str= solid_name.get(IndexOfVertexArray.get(i+1));
      String vertex3_str= solid_name.get(IndexOfVertexArray.get(i+2));
            

    triangular_gdml_code="<triangular vertex1=\""+ vertex1_str+"\" vertex2=\""+vertex2_str+"\" vertex3=\""+vertex3_str+"\"/>";
   // TriangularArrayStr.add(triangular_gdml_code);
   // Tesslated_gdml_block+=   "\n" +triangular_gdml_code;
   sb.append("\n" +triangular_gdml_code);
 
    }
   Tesslated_gdml_block+=sb.toString();
   
     long endtime =  System.nanoTime();

    }
   
void  Setarray_vertex( List<Vec3D>   data){
        this .array_vertex=data;
    }

void  Setarray_faces(List<VecInt3D>   data){
        this .array_faces=data;
    }

void  SetSolidArrayNames( List<String>  data){
       this .solid_name=data;
    }
void SetIndexOfVertexArray   (List<Integer>   data){ 
        this.IndexOfVertexArray  =data;
}
}
