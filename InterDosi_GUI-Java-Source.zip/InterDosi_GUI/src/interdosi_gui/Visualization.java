/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/
package interdosi_gui;

/**
 *
 * @author Jaafar EL Bakkali
 */
 import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.panel.CrosshairOverlay;
import org.jfree.chart.plot.Crosshair;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.LookupPaintScale;
import org.jfree.chart.renderer.xy.XYBlockRenderer;
import org.jfree.chart.title.PaintScaleLegend;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.chart.ui.RectangleEdge;

public class Visualization {
Crosshair xCrosshair;  
Crosshair yCrosshair;
ChartPanel chartPanel ;
static String _Title;
static int _Max_X, _Max_Y;
int scalex, scaley;
static String x_axis_title,y_axis_title;
static double [][] _Dose;
  int Number_Of_Voxels_Along_x= 0;
  int Number_Of_Voxels_Along_y= 0;
 int Number_Of_Voxels_Along_z= 0;
static int [][][]_organIdInxyz  ;

int id_x, id_y,id_z, organId;
static int _slice_number;
String  _DoseInXYZ_file_name,graph_title="";
//Function  used  to  get maximum value   of  dose
static double MaxDoseValue(double [][] d, int max_1, int max_2) 
{
    double dmax=0.0;
    for (int i=0; i< max_1; i++)
    {
        for (int j=0; j< max_2; j++)
        {
         if (dmax <d[i][j] ) {
         dmax=d[i][j];
         }   
        }
    }
return dmax;
}
 

public Visualization(String title, int Max_X, int Max_Y, double [][] Dose, int slice_number,String  DoseInXYZ_file_name, String file, int _Number_Of_Voxels_Along_x, int _Number_Of_Voxels_Along_y, int _Number_Of_Voxels_Along_z ) throws IOException, Exception {
 _slice_number=slice_number; 
 _Title=title;
 _Max_Y=Max_Y;
_Max_X=Max_X;
_DoseInXYZ_file_name=DoseInXYZ_file_name;
 _Dose=Dose;
 Number_Of_Voxels_Along_x = _Number_Of_Voxels_Along_x;
Number_Of_Voxels_Along_y = _Number_Of_Voxels_Along_y;
 Number_Of_Voxels_Along_z = _Number_Of_Voxels_Along_z;

 
  _organIdInxyz = new int [Number_Of_Voxels_Along_x][Number_Of_Voxels_Along_y][Number_Of_Voxels_Along_z];

 
 String[] strarrays = _DoseInXYZ_file_name.split("_");
 graph_title=" S: "+slice_number+", O: "+strarrays[0]+",E: "+strarrays[1]+" MeV, P: "+strarrays[2];
//String file =  getJarContainingFolder(g4crabdose_main.class)+"/core/G4VoxelizedCrab/VoxelizedCrab.txt";

 for ( int  i = 0; i < Number_Of_Voxels_Along_x;i++){
for ( int  j = 0; j< Number_Of_Voxels_Along_y;j++){
for ( int  k = 0; k < Number_Of_Voxels_Along_z;k++){
 _organIdInxyz[i][j][k]=-1;
}}}
    
try{
FileInputStream fstream = new FileInputStream(file);
DataInputStream in = new DataInputStream(fstream);
BufferedReader br = new BufferedReader(new InputStreamReader(in));
String strLine;
while ((strLine = br.readLine()) != null)   {
String[] tokens = strLine.split("\t");
id_x=Integer.parseInt(tokens[0]);
id_y=Integer.parseInt(tokens[1]);
id_z=Integer.parseInt(tokens[2]);
organId=Integer.parseInt(tokens[3]);
// 
//

//System.out.println(id_x+","+id_y+","+id_z+","+organId);
_organIdInxyz[ id_x][  id_y][ id_z]=organId;
 
}
in.close();
}catch (IOException | NumberFormatException e){
System.err.println("Error  1: " + e.getMessage());
}  

JFrame f = new JFrame(title);
JButton b = new JButton ("Close");
JLabel lbl = new JLabel (graph_title);
lbl.setBounds(50,375,250,50);
b.setBounds(50,375,250,50);
b.addActionListener((ActionEvent e) -> {
f.show(false);
});
f.add(b,BorderLayout.PAGE_END);
f.add(lbl, BorderLayout.PAGE_START);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        
if ( title.toLowerCase().contains("YZ".toLowerCase())) 
{
scalex=3; scaley=6;x_axis_title="Y Axis";y_axis_title="Z Axis"; 
}
else 
if ( title.toLowerCase().contains("XY".toLowerCase())) 
{ 
scalex=2; scaley=2; x_axis_title="X Axis";y_axis_title="Y Axis"; 
}
else 
if ( title.toLowerCase().contains("XZ".toLowerCase()))  
{ 
scalex=4; scaley=6;x_axis_title="X Axis";y_axis_title="Z Axis";  
}


chartPanel = new ChartPanel(createChart(createDataset())) 
{
@Override
public Dimension getPreferredSize() 
{
return new Dimension( scalex*_Max_X, scaley*_Max_Y);
}
};

chartPanel.addChartMouseListener(new ChartMouseListener(){
 @Override
public void chartMouseClicked(ChartMouseEvent event)
{

}

@Override
public void chartMouseMoved(ChartMouseEvent event) {
/*
    Rectangle2D dataArea =chartPanel.getScreenDataArea();   
JFreeChart chart = event.getChart();
XYPlot plot = (XYPlot) chart.getPlot();
ValueAxis xAxis = plot.getDomainAxis();
ValueAxis yAxis = plot.getRangeAxis();
double x = (int)xAxis.java2DToValue(event.getTrigger().getX(), dataArea, RectangleEdge.BOTTOM); 
double y = (int)yAxis.java2DToValue(event.getTrigger().getY(), dataArea, RectangleEdge.TOP); 
xCrosshair.setValue(x);
yCrosshair.setValue(y);
lbl.setText("Selected  Organ:  "+OrganNameFromVoxel( (int)x, (int)y,_slice_number));
*/
}     
});
        
CrosshairOverlay crosshairOverlay = new CrosshairOverlay();
xCrosshair = new Crosshair(Double.NaN, Color.GRAY, new BasicStroke(0f));
xCrosshair.setLabelVisible(true);
yCrosshair = new Crosshair(Double.NaN, Color.GRAY, new BasicStroke(0f));
yCrosshair.setLabelVisible(true);
crosshairOverlay.addDomainCrosshair(xCrosshair);
crosshairOverlay.addRangeCrosshair(yCrosshair);
chartPanel.addOverlay(crosshairOverlay);           
f.add(chartPanel);
f.pack();
f.setLocationRelativeTo(null);
f.setVisible(true);
}
private static JFreeChart createChart(XYDataset dataset) throws IOException 
{
NumberAxis xAxis = new NumberAxis(x_axis_title);
NumberAxis yAxis = new NumberAxis(y_axis_title);
XYBlockRenderer _XYBlockRenderer =  new XYBlockRenderer();
XYPlot _XYPlot = new XYPlot(dataset, xAxis, yAxis, _XYBlockRenderer);
NumberAxis scaleAxis = new NumberAxis("Relative Dose (%)");
LookupPaintScale _LookupPaintScale = new LookupPaintScale(0, 101, Color.GREEN);
String [] iron_palette   = {
"#00000a","#000014","#00001e","#000025","#00002a","#00002e","#000032","#000036","#00003a","#00003e",
"#000042","#000046","#00004a","#00004f","#000052","#010055","#010057","#020059","#02005c","#03005e",
"#040061","#040063","#050065","#060067","#070069","#08006b","#09006e","#0a0070","#0b0073","#0c0074",
"#0d0075","#0d0076","#0e0077","#100078","#120079","#13007b","#15007c","#17007d","#19007e","#1b0080",
"#1c0081","#1e0083","#200084","#220085","#240086","#260087","#280089","#2a0089","#2c008a","#2e008b",
"#30008c","#32008d","#34008e","#36008e","#38008f","#390090","#3b0091","#3c0092","#3e0093","#3f0093",
"#410094","#420095","#440095","#450096","#470096","#490096","#4a0096","#4c0097","#4e0097","#4f0097",
 "#510097","#520098","#540098","#560098","#580099","#5a0099","#5c0099","#5d009a","#5f009a","#61009b",
"#63009b","#64009b","#66009b","#68009b","#6a009b","#6c009c","#6d009c","#6f009c","#70009c","#71009d",
"#73009d","#75009d","#77009d","#78009d","#7a009d","#7c009d","#7e009d","#7f009d","#81009d","#83009d",
"#84009d","#86009d","#87009d","#89009d","#8a009d","#8b009d","#8d009d","#8f009c","#91009c","#93009c",
"#95009c","#96009b","#98009b","#99009b","#9b009b","#9c009b","#9d009b","#9f009b","#a0009b","#a2009b",
"#a3009b","#a4009b","#a6009a","#a7009a","#a8009a","#a90099","#aa0099","#ab0099","#ad0099","#ae0198",
"#af0198","#b00198","#b00198","#b10197","#b20197","#b30196","#b40296","#b50295","#b60295","#b70395",
"#b80395","#b90495","#ba0495","#ba0494","#bb0593","#bc0593","#bd0593","#be0692","#bf0692","#bf0692",
"#c00791","#c00791","#c10890","#c10990","#c20a8f","#c30a8e","#c30b8e","#c40c8d","#c50c8c","#c60d8b",
"#c60e8a","#c70f89","#c81088","#c91187","#ca1286","#ca1385","#cb1385","#cb1484","#cc1582","#cd1681",
"#ce1780","#ce187e","#cf187c","#cf197b","#d01a79","#d11b78","#d11c76","#d21c75","#d21d74","#d31e72",
"#d32071","#d4216f","#d4226e","#d5236b","#d52469","#d62567","#d72665","#d82764","#d82862","#d92a60",
 "#da2b5e","#da2c5c","#db2e5a","#db2f57","#dc2f54","#dd3051","#dd314e","#de324a","#de3347","#df3444",
"#df3541","#df363d","#e0373a","#e03837","#e03933","#e13a30","#e23b2d","#e23c2a","#e33d26","#e33e23",
"#e43f20","#e4411d","#e4421c","#e5431b","#e54419","#e54518","#e64616","#e74715","#e74814","#e74913",
"#e84a12","#e84c10","#e84c0f","#e94d0e","#e94d0d","#ea4e0c","#ea4f0c","#eb500b","#eb510a","#eb520a",
"#eb5309","#ec5409","#ec5608","#ec5708","#ec5808","#ed5907","#ed5a07","#ed5b06","#ee5c06","#ee5c05",
"#ee5d05","#ee5e05","#ef5f04","#ef6004","#ef6104","#ef6204","#f06303","#f06403","#f06503","#f16603",
"#f16603","#f16703","#f16803","#f16902","#f16a02","#f16b02","#f16b02","#f26c01","#f26d01","#f26e01",
"#f36f01","#f37001","#f37101","#f37201","#f47300","#f47400","#f47500","#f47600","#f47700","#f47800",
"#f47a00","#f57b00","#f57c00","#f57e00","#f57f00","#f68000","#f68100","#f68200","#f78300","#f78400",
"#f78500","#f78600","#f88700","#f88800","#f88800","#f88900","#f88a00","#f88b00","#f88c00","#f98d00",
"#f98d00","#f98e00","#f98f00","#f99000","#f99100","#f99200","#f99300","#fa9400","#fa9500","#fa9600",
"#fb9800","#fb9900","#fb9a00","#fb9c00","#fc9d00","#fc9f00","#fca000","#fca100","#fda200","#fda300",
"#fda400","#fda600","#fda700","#fda800","#fdaa00","#fdab00","#fdac00","#fdad00","#fdae00","#feaf00",
"#feb000","#feb100","#feb200","#feb300","#feb400","#feb500","#feb600","#feb800","#feb900","#feb900",
"#feba00","#febb00","#febc00","#febd00","#febe00","#fec000","#fec100","#fec200","#fec300","#fec400",
"#fec500","#fec600","#fec700","#fec800","#fec901","#feca01","#feca01","#fecb01","#fecc02","#fecd02",
"#fece03","#fecf04","#fecf04","#fed005","#fed106","#fed308","#fed409","#fed50a","#fed60a","#fed70b",
"#fed80c","#fed90d","#ffda0e","#ffda0e","#ffdb10","#ffdc12","#ffdc14","#ffdd16","#ffde19","#ffde1b",
"#ffdf1e","#ffe020","#ffe122","#ffe224","#ffe226","#ffe328","#ffe42b","#ffe42e","#ffe531","#ffe635",
"#ffe638","#ffe73c","#ffe83f","#ffe943","#ffea46","#ffeb49","#ffeb4d","#ffec50","#ffed54","#ffee57",
"#ffee5b","#ffee5f","#ffef63","#ffef67","#fff06a","#fff06e","#fff172","#fff177","#fff17b","#fff280",
"#fff285","#fff28a","#fff38e","#fff492","#fff496","#fff49a","#fff59e","#fff5a2","#fff5a6","#fff6aa",
"#fff6af","#fff7b3","#fff7b6","#fff8ba","#fff8bd","#fff8c1","#fff8c4","#fff9c7","#fff9ca","#fff9cd",
"#fffad1","#fffad4","#fffbd8","#fffcdb","#fffcdf","#fffde2","#fffde5","#fffde8","#fffeeb","#fffeee",
"#fffef1","#fffef4","#fffff6"  };
_LookupPaintScale.add(101, new Color(255,255,255));
  for (int i=0 ; i< 101; i++) _LookupPaintScale.add(i ,  Color.decode(iron_palette[i*3]));
 
 

PaintScaleLegend _PaintScaleLegend = new PaintScaleLegend(_LookupPaintScale, scaleAxis);
_PaintScaleLegend .setPosition(RectangleEdge.RIGHT);
_PaintScaleLegend .setAxisLocation(AxisLocation.TOP_OR_RIGHT);
_PaintScaleLegend .setMargin(50.0, 20.0, 80.0, 0.0);
scaleAxis.setAxisLinePaint(Color.white);
scaleAxis.setTickMarkPaint(Color.white);
((XYBlockRenderer)_XYPlot.getRenderer()).setPaintScale(_LookupPaintScale);
JFreeChart _JFreeChart  = new JFreeChart(null, null, _XYPlot, false);
_JFreeChart .addSubtitle(_PaintScaleLegend );
return _JFreeChart ;
}

static DefaultXYZDataset   FillDataSet(){
DefaultXYZDataset dataset = new DefaultXYZDataset();
double maxd= MaxDoseValue(_Dose,_Max_X,_Max_Y);
for (int i = 0; i < _Max_X; i = i + 1) {
double[][] data = new double[3][_Max_Y];
for (int j = 0; j < _Max_Y; j = j+ 1) {
data[0][j] = i;
data[1][j] = j;
//System.out.println("i,j,k  "+ i +" "+ j + " "+ _slice_number);
if ( _Title.toLowerCase().contains("XY".toLowerCase())) {
if (_organIdInxyz[i][j][_slice_number]!=-1) 
{
data[2][j] =(100* _Dose[ i][ j]/ maxd);
}   else 
{
data[2][j] =101;
}
}
if ( _Title.toLowerCase().contains("YZ".toLowerCase())) {
if (_organIdInxyz[_slice_number][i][j]!=-1) 
{
data[2][j] =100* _Dose[ i][ j]/ maxd;
}   else
{
data[2][j] =101;
}
}
if ( _Title.toLowerCase().contains("XZ".toLowerCase())) {
if (_organIdInxyz[i][_slice_number][j]!=-1) 
{
data[2][j] =100* _Dose[ i][ j]/ maxd;
}   else 
{
data[2][j] =101;
}
}
}
dataset.addSeries("Series" + i, data);
}
return dataset; 
}
  
  
private static XYZDataset createDataset() 
{
return FillDataSet();
} 
}