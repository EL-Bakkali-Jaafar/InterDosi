/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/ 
package interdosi_gui;


import interdosi_gui.PointXY;
import java.util.ArrayList;
import java.util.List;

 
public class OrganData {
 private String organ_name="";
 private  List<Float> ArrayOfZCoordinates;
 private  List<PointXY> ArrayOfXYCoordinates;

 
 public void OrganData(){
 ArrayOfZCoordinates = new ArrayList<Float>();
  ArrayOfXYCoordinates = new ArrayList<PointXY>();

 
 }
void SetupOrganData(String organ_name, List<Float> ArrayOfZCoordinates,List<PointXY> ArrayOfXYCoordinates ){
this.organ_name=organ_name;
this.ArrayOfXYCoordinates=ArrayOfXYCoordinates;
this.ArrayOfZCoordinates=ArrayOfZCoordinates;
}    
List<Float> GetArrayOfZCoordinates (){
return this.ArrayOfZCoordinates;
}
List<PointXY> GetArrayOfXYCoordinates(){
return this.ArrayOfXYCoordinates;
}

String GetOrganName(){

return this.organ_name;
}

void SetOrganName(String _name){
this.organ_name=_name;

}

void SetArrayOfXYCoordinates(List<PointXY> _value){ 

this.ArrayOfXYCoordinates= _value;
}

void SetArrayOfZCoordinates(List<Float> _value)
{
this.ArrayOfZCoordinates=_value;
}


    
}
