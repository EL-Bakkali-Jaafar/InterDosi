/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/ 
package interdosi_gui;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
 
/**
 *
 * @author jaafar
 */

public class ObjDataExtraction {
String OBJ_FILE_NAME="";
List<Vec3D> array_vertex ;
List<VecInt3D> array_faces;
List<Integer> IndexOfVertexArray;
float MaxXAbsoluteValue=0;
float MaxYAbsoluteValue=0;
float MaxZAbsoluteValue=0;
int TotalNumberOfLinesInOBJFile; 
void  SetOBJFileName(String   _value){
this.OBJ_FILE_NAME=_value;

};
void obtenainMaxXAbsoluteValue(float _value){
if (Math.abs(_value) > Math.abs(this.MaxXAbsoluteValue)) {this.MaxXAbsoluteValue=Math.abs(_value);}
}
void obtenainMaxYAbsoluteValue(float _value){
if (Math.abs(_value) > Math.abs(this.MaxYAbsoluteValue)) {this.MaxYAbsoluteValue=Math.abs(_value);}
}

void obtenainMaxZAbsoluteValue(float _value){
if (Math.abs(_value)> Math.abs(this.MaxZAbsoluteValue)) {this.MaxZAbsoluteValue=Math.abs(_value);}
}
 
 void ReadOBJDataIntoArrayDataF() throws IOException
 {
long starttime =  System.nanoTime();
String  vertex_keyword="v",face_keyword="f";
int j=0;
array_vertex = new ArrayList<Vec3D>();
array_faces = new  ArrayList<VecInt3D>();
IndexOfVertexArray = new ArrayList<Integer> (); 
List<String> data =Files.readAllLines(Paths.get(OBJ_FILE_NAME));
for (int i=0; i< data.size();  i++)
{//1
String strLine;
strLine = data.get(i);
if (strLine.contains(vertex_keyword))
{//2
String[]  vertex_str = strLine.split("\\s+");
if (        vertex_str[0] == null ? vertex_keyword == null : vertex_str[0].equals(vertex_keyword))
{//3
Vec3D myVec3D = new Vec3D();
myVec3D.set(Float.parseFloat(vertex_str[1]),Float.parseFloat(vertex_str[2]), Float.parseFloat(vertex_str[3]));
array_vertex.add(myVec3D);
obtenainMaxXAbsoluteValue(myVec3D.x);  
obtenainMaxYAbsoluteValue(myVec3D.y);  
obtenainMaxZAbsoluteValue(myVec3D.z); 
}//3
}//2
if (strLine.contains(face_keyword)) 
{//4
String[]  vertex_str = strLine.split("\\s+");
VecInt3D myVec3D = new VecInt3D();
String[]  face_str1 = vertex_str[1].split("//") ;
String[]  face_str2 = vertex_str[2].split("//") ;
String[]  face_str3 = vertex_str[3].split("//") ;
myVec3D.set(Integer.parseInt( face_str1[0]),Integer.parseInt(face_str2[0]),Integer.parseInt(face_str3[0]));
 array_faces.add(myVec3D);
  }//4
}//1
long endtime =  System.nanoTime();
 System.out.println(" ReadOBJDataIntoArrayData, ELAPSED TIME (s) :"+(endtime -starttime)/1000000000);
 for (int i=0; i<array_faces.size(); i++)  
 {//5
System.out.println(" v1= "+ array_faces.get(i).x+ " v2= "+array_faces.get(i).y+ " v3= "+array_faces.get(i).z );
}//5
}
 void  ReadOBJDataIntoArrayData() throws FileNotFoundException, IOException{
long starttime =  System.nanoTime();
String  vertex_keyword="vertex";
int j=0;
int i=0;
int l=0;
int v=0;
array_vertex = new ArrayList<Vec3D>();
IndexOfVertexArray = new ArrayList<Integer> ();
 try {
FileInputStream fstream = new FileInputStream(OBJ_FILE_NAME);
try ( DataInputStream in = new DataInputStream(fstream)) {
BufferedReader br = new BufferedReader(new InputStreamReader(in) );
String strLine;
 while ((strLine = br.readLine()) != null) 
{
if (strLine.contains(vertex_keyword)) {
strLine = strLine.replace(vertex_keyword, "");
String[]  vertex_str = strLine.split("\\s+");
Vec3D myVec3D = new Vec3D( Float.parseFloat(vertex_str[1]),Float.parseFloat(vertex_str[2]), Float.parseFloat(vertex_str[3]));
if( myVec3D.Vec3DExist( array_vertex,myVec3D)==false)   
{  
array_vertex.add(myVec3D);
obtenainMaxXAbsoluteValue(myVec3D.x);  
obtenainMaxYAbsoluteValue(myVec3D.y);  
obtenainMaxZAbsoluteValue(myVec3D.z); 
IndexOfVertexArray.add(j);
j++;
}
else
{  IndexOfVertexArray.add( myVec3D.IndexVec3D (array_vertex,  myVec3D  )  );
}}
i++;
} }}
catch (IOException | NumberFormatException e)
{
System.err.println("Error  1: " + e.getMessage());
}
 long endtime =  System.nanoTime();
System.out.println(" ELAPSED TIME (s) :"+(endtime -starttime)/1000000000);
 }   

void  SetTotalNumberOfLinesInOBJFile(int  _value){
this.TotalNumberOfLinesInOBJFile=_value;
}
List<Vec3D>  Getarray_vertex( ){
return this.array_vertex ;
}
 List<Integer>   GetIndexOfVertexArray(  ){
return this.IndexOfVertexArray ;
}
}

