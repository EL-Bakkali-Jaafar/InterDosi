/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/
package interdosi_gui;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import javax.swing.JTextArea;
public class Console extends OutputStream    {
String CharInOneLine="",TextInOneLine="";
String l="";
String TextContent="";
private final JTextArea textArea;
public void Clean(){
TextContent="";
  }
public void Dump(){
this.textArea.setText(TextContent);
}
private void updateTextArea(final String text) {
textArea.setText(textArea.getText() + text);
}
public Console(JTextArea _textArea) {
this.textArea = _textArea;
this.textArea.setBackground(Color.black);
this.textArea.setForeground(Color.green);
}
@Override
public void write(int paramInt) throws IOException {
CharInOneLine=String.valueOf((char)paramInt);
TextInOneLine=TextInOneLine+CharInOneLine;      
if ("\n".equals(CharInOneLine))
{
updateTextArea(TextInOneLine);  
textArea.setAutoscrolls(true);
TextContent+=TextInOneLine;
textArea.setCaretPosition(textArea.getDocument().getLength()-1);
textArea.update(textArea.getGraphics());
if (textArea.getDocument().getLength()> 600){
textArea.setText("");
}
TextInOneLine="";
}     
}
}