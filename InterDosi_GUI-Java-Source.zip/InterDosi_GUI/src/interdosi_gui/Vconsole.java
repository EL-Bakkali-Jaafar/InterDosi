/*
 * Copyright (C) 2019 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
package interdosi_gui;
*/
package interdosi_gui;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JTextArea;
/*
G4Linac_MT, a Geant4-based application for Medical Linear Accelerator
Developed by Dr.Jaafar EL Bakkali,Assistant Prof. of Nuclear Physics
Rabat, Morocco, 10/10/ 2017
Webpage :https://github.com/EL-Bakkali-Jaafar/G4Linac_MT
 */
/**
 *
 * @author jaafar
 */
 public class Vconsole extends OutputStream    {
String s="",d="";
String l="";
        int m=0;

String content="";
    private final JTextArea textArea;
  public void Clean(){
  content="";
  }
    public void Dump(){
    // 
    this.textArea.setText(content);
    
}
private void updateTextArea(final String text) {
    //SwingUtilities.invokeLater(() -> {
        //
        textArea.setText(textArea.getText() + text);
  //  }
//);
  }
  public Vconsole(JTextArea _textArea) {
        this.textArea = _textArea;
        this.textArea.setBackground(Color.black);
        this.textArea.setForeground(Color.green);


    }

    @Override
    public void write(int paramInt) throws IOException {
        // redirects data to the text area
        s=String.valueOf((char)paramInt);
       d=d+s;  
      

        if ("\n".equals(s) )
{
    
        updateTextArea(d);  
textArea.setAutoscrolls(true);
//T

content+=d;
//
textArea.setCaretPosition(textArea.getDocument().getLength()-1);

textArea.update(textArea.getGraphics());
            try {
                TimeUnit.MILLISECONDS.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Vconsole.class.getName()).log(Level.SEVERE, null, ex);
            }
//
//
if (textArea.getDocument().getLength()> 600){
//if (textArea.getLineCount()>42){

//
textArea.setText("");
//
//
}
//
//
d="";
    }
        
}
    }