/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "PrimaryGeneratorAction.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4RunManager.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4Navigator.hh"
#include "G4TransportationManager.hh"
#include "G4ThreeVector.hh"
#include <iostream>
#include <math.h>
#include <fstream>
#include "G4EventManager.hh"
#include "DetectorConstruction.hh"
using namespace std;
G4ThreadLocal int INCR_NUMBER_OF_POINTS_IN_CURRENT_ORGANE =0;
G4ThreadLocal unsigned int max_points=0;
const unsigned long infinity=1000000000000000;
const unsigned int NUMBER_OF_POINTS_PER_CM3_UNIT=15000000;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::PrimaryGeneratorAction()
: G4VUserPrimaryGeneratorAction(),fParticleGun(0)
{
G4int n_particle = 1;
fParticleGun  = new G4ParticleGun(n_particle);
G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
G4String particleName;
G4ParticleDefinition* particle
= particleTable->FindParticle(particleName="gamma");
fParticleGun->SetParticleDefinition(particle);
fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0.,0.,1.));
fParticleGun->SetParticleEnergy(1.*MeV);
this->runManager = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(this->runManager->GetUserDetectorConstruction()); 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::BuildVoxelizedCrabDataFiles()
{//1

list<string> OrganList;

std::ofstream  TextFile;
//TextFile.open("BeeFromSTLphantom.ijkid",  std::ios::out | std::ios::app);
TextFile.open("BeeFromSTLphantom.ijkid",  std::ios::out );
G4Navigator* aNavigator = G4TransportationManager::GetTransportationManager()->GetNavigatorForTracking();
//
G4double phantomx_dim= this->pDetectorConstruction-> WorldDimensionX ;
//
G4double phantomy_dim=this->pDetectorConstruction-> WorldDimensionY  ;
//
G4double phantomz_dim= this->pDetectorConstruction-> WorldDimensionZ ;
 
 

 
G4double HalfVoxelDimensionAlongX=0.5*( phantomx_dim/(double) this->pDetectorConstruction->NumberOfVoxelsAlongX);
G4double HalfVoxelDimensionAlongY=0.5*( phantomy_dim/(double)  this->pDetectorConstruction->NumberOfVoxelsAlongY);
G4double HalfVoxelDimensionAlongZ=0.5*( phantomz_dim/ (double) this->pDetectorConstruction->NumberOfVoxelsAlongZ);
int ix,iy,iz,orang_id=0;
 cout << " phantom X " << phantomx_dim << endl;
 cout << " phantom Y " << phantomy_dim << endl;
 cout << " phantom Z " << phantomz_dim << endl;

 cout << " NumberOfVoxelsAlong X " << this->pDetectorConstruction->NumberOfVoxelsAlongX << endl;
 cout << " NumberOfVoxelsAlong Y " << this->pDetectorConstruction->NumberOfVoxelsAlongY << endl;
 cout << " NumberOfVoxelsAlong Z " << this->pDetectorConstruction->NumberOfVoxelsAlongZ<< endl;  
 cout << " HalfVoxelDimensionAlong X " << HalfVoxelDimensionAlongX/mm << endl;
 cout << " HalfVoxelDimensionAlong Y " << HalfVoxelDimensionAlongY/mm << endl;
 cout << " HalfVoxelDimensionAlong Z " << HalfVoxelDimensionAlongZ/mm << endl;

for(ix=0; ix< this->pDetectorConstruction->NumberOfVoxelsAlongX; ix++){//2
for(iy=0; iy< this->pDetectorConstruction->NumberOfVoxelsAlongY; iy++){//3
for(iz=0; iz< this->pDetectorConstruction->NumberOfVoxelsAlongZ; iz++){//4
G4double x= ( -  this->pDetectorConstruction->NumberOfVoxelsAlongX + 1+ 2*ix )*HalfVoxelDimensionAlongX;
G4double y= ( -  this->pDetectorConstruction->NumberOfVoxelsAlongY+ 1+ 2*iy )* HalfVoxelDimensionAlongY;
G4double z = ( -  this->pDetectorConstruction->NumberOfVoxelsAlongZ+ 1+ 2*iz)*HalfVoxelDimensionAlongZ;
G4VPhysicalVolume* aVolume = aNavigator->LocateGlobalPointAndSetup(G4ThreeVector( x,y,z));
 //cout << " aVolume" << aVolume->GetName()<< endl;
std::string organ_name = aVolume->GetLogicalVolume()->GetName() ;
for (int i=0; i<this->pDetectorConstruction->dim; i++){//5
if (this->pDetectorConstruction->_ORGANDATA[i].ORGAN_NAME==organ_name )
{//6
orang_id= this->pDetectorConstruction->_ORGANDATA[i].ORGAN_ID;
if(orang_id!=-1){//7
 if (orang_id==2){cout << "deected brain "<< endl;}
 OrganList.push_back(to_string(orang_id));
TextFile << ix<< "\t"<< iy << "\t"<<  iz<< "\t"<<orang_id<<endl;
}//7
}//6
}//5
 
}}}// 2 3 4
 
TextFile.close();
std::ofstream  InfoFile;
InfoFile.open("phantom.info", std::ios::out);
InfoFile <<"Phantom dimension along X,Y and Z axis (mm): "<<"\t" <<this->pDetectorConstruction-> WorldDimensionX <<"\t"<<this->pDetectorConstruction-> WorldDimensionY<< "\t"<<this->pDetectorConstruction-> WorldDimensionZ <<G4endl;
InfoFile <<"Number of voxels along X,Y and Z axis : "<<"\t" << this->pDetectorConstruction->NumberOfVoxelsAlongX <<"\t"<< this->pDetectorConstruction->NumberOfVoxelsAlongY<< "\t"<< this->pDetectorConstruction->NumberOfVoxelsAlongZ<<G4endl;
InfoFile <<"Voxel dimensions along X,Y and Z axis (mm): "<<"\t" <<2*HalfVoxelDimensionAlongX <<"\t"<<2*HalfVoxelDimensionAlongY<< "\t"<<2*HalfVoxelDimensionAlongZ<<G4endl;
InfoFile <<"ORGAN_NAME "<<"\t" << "ORGAN_ID "<<G4endl;
for (int i=0; i<this->pDetectorConstruction->dim; i++){ 
InfoFile << this ->pDetectorConstruction->_ORGANDATA[i].ORGAN_NAME<<"\t" <<this ->pDetectorConstruction->_ORGANDATA[i].ORGAN_ID<<G4endl;
}
OrganList.sort();
OrganList.unique();
G4cout <<"Number of organs "<<"\t" << OrganList.size() <<G4endl;
InfoFile.close();
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
BuildVoxelizedCrabDataFiles();
this->runManager->TerminateEventLoop(); 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

