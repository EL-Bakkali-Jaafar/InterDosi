/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#include "DetectorMessenger.hh"
#include "DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::DetectorMessenger(DetectorConstruction* pDetectorConstruction)
: G4UImessenger(),fDetectorConstruction(pDetectorConstruction)
{
 DetectorDir           = new G4UIdirectory("/IJKID_Builder/");
 DetectorDir           -> SetGuidance("............................");
 GDMLFilePathCmd = new G4UIcmdWithAString("/IJKID_Builder/GDMLFilePath",this);  
 GDMLFilePathCmd->SetGuidance("GDMLFilePath");
 GDMLFilePathCmd->SetParameterName("GDMLFilePath",false);
NumberOfVoxelsAlongXCmd = new G4UIcmdWithAnInteger("/IJKID_Builder/NumberOfVoxelsAlongX",this);  
NumberOfVoxelsAlongXCmd->SetGuidance("Set NumberOfVoxelsAlongX.");
NumberOfVoxelsAlongXCmd ->SetParameterName("NumberOfVoxelsAlongX",false);
NumberOfVoxelsAlongXCmd ->SetRange("NumberOfVoxelsAlongX>=0");
NumberOfVoxelsAlongYCmd = new G4UIcmdWithAnInteger("/IJKID_Builder/NumberOfVoxelsAlongY",this);  
NumberOfVoxelsAlongYCmd->SetGuidance("Set NumberOfVoxelsAlongY.");
NumberOfVoxelsAlongYCmd ->SetParameterName("NumberOfVoxelsAlongY",false);
NumberOfVoxelsAlongYCmd ->SetRange("NumberOfVoxelsAlongY>=0");
NumberOfVoxelsAlongZCmd = new G4UIcmdWithAnInteger("/IJKID_Builder/NumberOfVoxelsAlongZ",this);  
NumberOfVoxelsAlongZCmd->SetGuidance("Set NumberOfVoxelsAlongZ.");
NumberOfVoxelsAlongZCmd ->SetParameterName("NumberOfVoxelsAlongZ",false);
NumberOfVoxelsAlongZCmd ->SetRange("NumberOfVoxelsAlongZ>=0");
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::~DetectorMessenger()
{
delete GDMLFilePathCmd;
delete DetectorDir;   
delete NumberOfVoxelsAlongXCmd;
delete NumberOfVoxelsAlongYCmd;
delete NumberOfVoxelsAlongZCmd;
 }
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{       
      if(command==GDMLFilePathCmd ){fDetectorConstruction->SetGDMLFilePath( newValue);}  
else  if( command == NumberOfVoxelsAlongXCmd){fDetectorConstruction-> SetNumberOfVoxelsAlongX(NumberOfVoxelsAlongXCmd->GetNewIntValue(newValue));}  
 else  if( command == NumberOfVoxelsAlongYCmd){fDetectorConstruction-> SetNumberOfVoxelsAlongY(NumberOfVoxelsAlongYCmd->GetNewIntValue(newValue));}  
 else  if( command == NumberOfVoxelsAlongZCmd){fDetectorConstruction-> SetNumberOfVoxelsAlongZ(NumberOfVoxelsAlongZCmd->GetNewIntValue(newValue));}  
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
