#!/bin/bash 
number_of_cores=$(nproc)
geant4_installation=$2
g4interdosi_installation=$1
source $geant4_installation/bin/geant4.sh
cd $g4interdosi_installation
cd bin
mkdir -p IJKID_Builder.bin
cd IJKID_Builder.bin
 cp   $g4interdosi_installation/inputs/GDMLTesselatedPhantomFiles/*.gdml  ./

./IJKID_BUILDER run.mac

cp *.ijkid $g4interdosi_installation/inputs/Phantom_files/*
cp *.info $g4interdosi_installation/inputs/Phantom_files/*
exit
