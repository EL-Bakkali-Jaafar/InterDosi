#!/bin/bash 
ulimit unlimited
g4interdosi_installation=$1
geant4_installation=$2
organ_source_name=$3
source $geant4_installation/bin/geant4.sh
cd $g4interdosi_installation
cd bin
cd g4interdosi.bin
./G4InterDosi
exit
