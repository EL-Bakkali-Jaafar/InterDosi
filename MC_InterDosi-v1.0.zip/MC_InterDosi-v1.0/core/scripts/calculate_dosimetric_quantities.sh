#!/bin/bash 
ulimit unlimited
g4interdosi_installation=$1
geant4_installation=$2
organ_source_name=$3
source $geant4_installation/bin/geant4.sh
cd $g4interdosi_installation
cd bin
cd g4interdosi.bin
./start_calculations.sh

mkdir -p $g4interdosi_installation/outputs/Dosimetric_files/$organ_source_name
cp  *.xls $g4interdosi_installation/outputs/Dosimetric_files/$organ_source_name
cp  *.DoseInXYZ $g4interdosi_installation/outputs/DoseInXYZ_files/
cp  *.info $g4interdosi_installation/outputs/Phantom_organs
rm *.xls
exit
