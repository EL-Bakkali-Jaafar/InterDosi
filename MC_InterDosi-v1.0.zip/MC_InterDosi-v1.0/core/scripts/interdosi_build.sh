#!/bin/bash 
number_of_cores=$(nproc)
geant4_installation=$2
g4interdosi_installation=$1
source $geant4_installation/bin/geant4.sh
cd $g4interdosi_installation
cd bin
mkdir -p g4interdosi.bin
cd g4interdosi.bin
cmake  -DGeant4_DIR=$geant4_installation $g4interdosi_installation/core/G4InterDosi
make -j$number_of_cores
exit
