#!/bin/bash 
number_of_cores=$(nproc)
geant4_installation=$2
g4interdosi_installation=$1
source $geant4_installation/bin/geant4.sh
cd $g4interdosi_installation
cd bin
mkdir -p IJKID_Builder.bin
cd IJKID_Builder.bin
cmake  -DGeant4_DIR=$geant4_installation $g4interdosi_installation/core/IJKID_Builder
make -j$number_of_cores

exit
