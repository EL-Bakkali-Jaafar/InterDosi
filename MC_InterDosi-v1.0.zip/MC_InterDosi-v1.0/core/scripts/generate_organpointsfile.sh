#!/bin/bash 
ulimit unlimited
g4interdosi_installation=$1
geant4_installation=$2
organpoints_macro_name=$3
source $geant4_installation/bin/geant4.sh
cd $g4interdosi_installation
cd bin
cd g4interdosi.bin
#valgrind  --track-origins=yes ./G4InterDosi $g4interdosi_installation/inputs/Organpoints_macros/$organpoints_macro_name
#
./G4InterDosi $g4interdosi_installation/inputs/Organpoints_macros/$organpoints_macro_name
mkdir -p $g4interdosi_installation/outputs/Organpoints_files
cp  *.dat  $g4interdosi_installation/outputs/Organpoints_files
rm *.dat 
exit
