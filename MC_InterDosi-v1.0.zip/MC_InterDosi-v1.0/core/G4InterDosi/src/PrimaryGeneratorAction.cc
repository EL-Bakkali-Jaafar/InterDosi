/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4RunManager.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4Navigator.hh"
#include "G4TransportationManager.hh"
#include "G4ThreeVector.hh"
#include <iostream>
#include <math.h>
#include <fstream>
#include "G4EventManager.hh"
#include "Randomize.hh"
#include <cmath>
#include "G4PhysicalConstants.hh"
using namespace std;

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::PrimaryGeneratorAction():G4VUserPrimaryGeneratorAction(),fParticleGun(0)
{
fParticleGun                           = new G4ParticleGun(1);
auto str_thread                        = std::to_string(G4Threading::G4GetThreadId());
this->runManager                       = G4RunManager::GetRunManager();
this->pDetectorConstruction            = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
G4ParticleTable* particleTable         = G4ParticleTable::GetParticleTable();
G4ParticleDefinition* particle         = particleTable->FindParticle(this->pDetectorConstruction->particle_name);
fParticleGun                           ->SetParticleDefinition(particle);
fParticleGun                           ->SetParticleEnergy(this->pDetectorConstruction->kinetic_energy);
G4cout<<"InterDosi-> Primary Kinetic Energy (MeV) : "  << this->pDetectorConstruction->kinetic_energy<<G4endl;
/*
probability.push_back(0.1667);
  probability.push_back(0.1667);
  probability.push_back(0.1667);
  probability.push_back(0.1667);
  probability.push_back(0.1666);
  probability.push_back(0.1666);
*/
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
delete fParticleGun;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent) 
{
GenerateOrgansMomentumDirection();
GenerateOrgansPositionData();
// GenerateIstotropicEmission();
int ParticleRecyclingFactor=this->pDetectorConstruction->ParticleRecyclingFactor;
for (int i=0; i<ParticleRecyclingFactor ;i++) 
{  

//
fParticleGun->GeneratePrimaryVertex(anEvent);};
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GenerateOrgansPositionData()
{
int random_id, low_v=0;
int high_v = this->pDetectorConstruction->PhysicsVolPosList.size()-1;
int range =  (high_v - low_v) +1 ;
random_id = low_v + int (range *G4UniformRand() );
G4double x = this->pDetectorConstruction->PhysicsVolPosList[random_id].x()+ 0.5* this->pDetectorConstruction->VOXEL_X_DIM*(1-2*G4UniformRand());
G4double y = this->pDetectorConstruction->PhysicsVolPosList[random_id].y()+ 0.5* this->pDetectorConstruction->VOXEL_Y_DIM*(1-2*G4UniformRand());
G4double z = this->pDetectorConstruction->PhysicsVolPosList[random_id].z()+ 0.5* this->pDetectorConstruction->VOXEL_Z_DIM*(1-2*G4UniformRand());
fParticleGun->SetParticlePosition(G4ThreeVector(x ,y,z));
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GenerateOrgansMomentumDirection(){
G4double a,b,c,n;
do  {
a = ( G4UniformRand() - 0.5 )/0.5;
b = ( G4UniformRand() - 0.5 )/0.5;
c = ( G4UniformRand() - 0.5 )/0.5;
n = a * a + b*b + c*c;

    } while (n > 1  || n == 0.0);

n = std::sqrt(n);
a /=n;
b /=n;
c /=n;
G4ThreeVector direction(a,b,c);
 fParticleGun->SetParticleMomentumDirection(direction);
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
