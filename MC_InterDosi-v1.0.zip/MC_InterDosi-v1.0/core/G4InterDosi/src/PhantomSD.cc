/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "G4Run.hh"
#include "G4Event.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VSolid.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4RunManager.hh"
#include "G4SDManager.hh"
#include "G4ParticleDefinition.hh"
#include "G4VVisManager.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"
#include "G4UnitsTable.hh"
#include "G4Circle.hh"
#include "G4ThreeVector.hh"
#include "G4ios.hh"
#include <stdio.h>
#include "PhantomSD.hh"
#include "DetectorConstruction.hh"
#include <vector>
#include "G4SystemOfUnits.hh"
#include "G4Threading.hh"
#include "G4Threading.hh"
#include "G4EventManager.hh"
#include "G4Threading.hh"
#include "G4AutoLock.hh"
#include <iostream>
#include <math.h>
#include <fstream>
#include <math.h>
#include "G4Timer.hh"
using namespace std;
G4ThreadLocal      int                         fuse=-1;
                   int                         fffuse=-1;
G4ThreadLocal      int                         ffuse=-1;
G4ThreadLocal      int                         Enough_Events_Number=-1;
G4ThreadLocal      int                         last_event_id=0;
G4ThreadLocal      int                         first_event_id=0;
G4ThreadLocal std::ofstream  _File;
namespace {G4Mutex _Mutex = G4MUTEX_INITIALIZER;}  
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD::PhantomSD(G4String name )
: G4VSensitiveDetector(name)
{ 
this->runManager = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(this->runManager->GetUserDetectorConstruction()); 
{
this-> NumberTotalEvents=0;
this-> VoxelVolume=0.;
this-> VoxelMass=0.*g;
this->pDetectorConstruction->NumberOfThread=G4Threading::GetNumberOfRunningWorkerThreads();
this-> NumberOfThreads =pDetectorConstruction->NumberOfThread;
this->_InterDosiData = new InterDosiData[this->pDetectorConstruction->NumberOfPhantomOrgans];
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
for ( unsigned short int i=0;i< this->pDetectorConstruction->NumberOfPhantomOrgans  ;i++) 
{ 
const char *organ_name= this->pDetectorConstruction->_VoxelizedPhantomStruc[i].ORGAN_NAME.c_str();
strcpy (this->_InterDosiData[i].ORGANE_NAME,organ_name );
this->_InterDosiData[i].ORGANE_ID=this->pDetectorConstruction->OrganeID(this->_InterDosiData[i].ORGANE_NAME);
this->_InterDosiData[i].KINETIC_ENERGY=0.0;
this->_InterDosiData[i].ABSORBED_ENERGY=0.0;
this->_InterDosiData[i].ABSORBED_ENERGY2=0.0;
this->_InterDosiData[i].STD_DEV=-1;
this->_InterDosiData[i].NEVENT=0;
this->_InterDosiData[i].ORGANE_MASSE=0;
this->_InterDosiData[i].ORGANE_VOLUME=0;
}
}
this->DVoxels=new dvxl**[this->pDetectorConstruction->Number_Of_Voxels_Along_x];
for (int ix=0; ix< this->pDetectorConstruction->Number_Of_Voxels_Along_x; ix++)
{
this->DVoxels[ix]=new dvxl*[this->pDetectorConstruction->Number_Of_Voxels_Along_y];
for (int iy=0; iy< this->pDetectorConstruction->Number_Of_Voxels_Along_y; iy++)
{
this->DVoxels[ix][iy]=new dvxl[this->pDetectorConstruction->Number_Of_Voxels_Along_z];
for (int iz=0; iz< this->pDetectorConstruction->Number_Of_Voxels_Along_z; iz++)
{
this->DVoxels[ix][iy][iz].absorbed_dose  = 0.;
}}}}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int* PhantomSD::GetIdsVoxelXYZ(std::string _physical_volume_name) {
static int  r[4];
std::istringstream iss(_physical_volume_name);
std::string _s;
int i=0;
while ( std::getline( iss, _s, ' ' ) ) {
r[i]=std::stoi( _s);
i++;
}
return r;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD::~PhantomSD()
{
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
string PhantomSD::StrWithoutDigits(string _str)
{
string _str1;
for  (char& c: _str) {
if (std::isdigit(c)==false){_str1+=c;}
}
//_str.erase (std::remove_if (std::begin(_str), std::end(_str), [](char ch) {std::isdigit(ch);}), _str.end());

return _str1;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4bool PhantomSD::ProcessHits(G4Step* aStep,G4TouchableHistory*)
{//1
{//2
G4double ENERGY_DEPOSIT = aStep -> GetTotalEnergyDeposit();

ENERGY_DEPOSIT *=MeV;
if(ENERGY_DEPOSIT  == 0.) {return false;}
if(ENERGY_DEPOSIT  != 0) 
{//3
std::string _organName;
for (int i= 0;i<this->pDetectorConstruction->NumberOfPhantomOrgans; i++)
{//4
const G4Step * real_step = aStep-> GetTrack()->GetStep();
std::string vol_selected = this->pDetectorConstruction->OrganeName(this->pDetectorConstruction->_VoxelizedPhantomStruc[i].ORGAN_ID);
std::string vol_current  = real_step -> GetPreStepPoint() -> GetPhysicalVolume() -> GetLogicalVolume()->GetName();
//if (vol_selected==real_step -> GetPreStepPoint() -> GetPhysicalVolume() -> GetLogicalVolume()->GetName())

if ( StrWithoutDigits(vol_current) == vol_selected  )
{
 //cout << "vol_current  " << vol_current<<endl;
 
int ix,iy,iz;
ix= GetIdsVoxelXYZ(real_step -> GetPreStepPoint() -> GetPhysicalVolume()->GetName())[0] ;
iy= GetIdsVoxelXYZ(real_step -> GetPreStepPoint() -> GetPhysicalVolume()->GetName())[1] ;
iz= GetIdsVoxelXYZ(real_step -> GetPreStepPoint() -> GetPhysicalVolume()->GetName())[2] ;
G4double _density=real_step->GetPreStepPoint()->GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetDensity();
G4double volume = this->pDetectorConstruction->VOXEL_X_DIM*this->pDetectorConstruction->VOXEL_Y_DIM*this->pDetectorConstruction->VOXEL_Z_DIM;
G4double voxel_masse;
voxel_masse*=g;
voxel_masse= _density*volume;
DVoxels[ix][iy][iz].absorbed_dose+=ENERGY_DEPOSIT/voxel_masse/(MeV/g) ;
 
this->_InterDosiData[i].ABSORBED_ENERGY+=ENERGY_DEPOSIT/(MeV);
this->_InterDosiData[i].ABSORBED_ENERGY2+= (ENERGY_DEPOSIT*ENERGY_DEPOSIT)/(MeV*MeV);
this->_InterDosiData[i].NEVENT++;
if(this->_InterDosiData[i].NEVENT>1)
{//7
G4double absorbed_energy =this->_InterDosiData[i].ABSORBED_ENERGY;
G4double absorbed_energy2=this->_InterDosiData[i].ABSORBED_ENERGY2;
G4double absorbed_energy_mean=absorbed_energy/this->_InterDosiData[i].NEVENT;
G4double absorbed_energy2_mean=absorbed_energy2/this->_InterDosiData[i].NEVENT;
G4double sigma=sqrt((absorbed_energy2_mean-absorbed_energy_mean*absorbed_energy_mean)/(this->_InterDosiData[i].NEVENT-1));
this->_InterDosiData[i].STD_DEV= 100*sigma/absorbed_energy_mean;
}//7
//}//6
}//5
}//4
}//3
}//2
}//1
//*#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDosimetricDataInTextFile(){
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
_File.open(this->pDetectorConstruction->SourceOrganeName+"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+"_"+this->pDetectorConstruction->particle_name+"_"+str_thread+".txt", std::ios::app);
for (int ix=0; ix< this->pDetectorConstruction->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->pDetectorConstruction->Number_Of_Voxels_Along_y; iy++){
for (int iz=0; iz< this->pDetectorConstruction->Number_Of_Voxels_Along_z; iz++){
if ( this->DVoxels[ix][iy][iz].absorbed_dose!=0.0) _File<<  ix << " "<< iy<< " "<< iz<< " "<< this->DVoxels[ix][iy][iz].absorbed_dose<<endl;
}}}
_File.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::EndOfEvent(G4HCofThisEvent*)
{//1
G4AutoLock _m(&_Mutex);
{//2
const G4Event * event                            = this->runManager ->GetCurrentEvent();
this->Total_Events_To_Be_Processed               = this->runManager ->GetNumberOfEventsToBeProcessed();
G4int event_id                                   = event->GetEventID();
G4ThreadLocal int b                              = (int) this->Total_Events_To_Be_Processed/(float) pDetectorConstruction->NumberOfThread;
if (fuse==-1)
{//3
first_event_id=event_id;
last_event_id=event_id+ b-1;
G4cout<< "FIRST_EVENT_ID  "<< first_event_id << " LAST_EVENT_ID "<<last_event_id<<" THREAD_ID  "<<G4Threading::G4GetThreadId()<<  G4endl;
fuse=1;
}//3
if (this->pDetectorConstruction->ApplyStdThreshold==true)
{//4
if ( IsAllStdValuesAreLessThanUnit()==true  )
{//5
Enough_Events_Number= this->runManager ->GetCurrentEvent()->GetEventID()-first_event_id;
pDetectorConstruction->NumberOfEventsEnoughToBeProcessed +=Enough_Events_Number;
this->runManager->AbortRun();
 pDetectorConstruction->myTimer->Stop();
this->cpu_time=  pDetectorConstruction->myTimer->GetRealElapsed();
SaveDataInBinaryFileP();
 G4cout<< this->_InterDosiData[0].ORGANE_NAME<< " STD_DEV  "<< this->_InterDosiData[0].STD_DEV<<" ThreadId  "<< G4Threading::G4GetThreadId()<<G4endl;
G4cout<< this->_InterDosiData[1].ORGANE_NAME<< " STD_DEV  "<< this->_InterDosiData[1].STD_DEV<<" ThreadId  "<< G4Threading::G4GetThreadId()<<G4endl;
G4cout<< this->_InterDosiData[2].ORGANE_NAME<< " STD_DEV  "<< this->_InterDosiData[2].STD_DEV<<" ThreadId  "<< G4Threading::G4GetThreadId()<<G4endl;
G4cout<< this->_InterDosiData[3].ORGANE_NAME<< " STD_DEV  "<< this->_InterDosiData[3].STD_DEV<<" ThreadId  "<< G4Threading::G4GetThreadId()<<G4endl;
G4cout<< this->_InterDosiData[4].ORGANE_NAME<< " STD_DEV  "<< this->_InterDosiData[4].STD_DEV<<" ThreadId  "<< G4Threading::G4GetThreadId()<<G4endl; 
SaveDosimetricDataInTextFile();
SaveSimData();
}//5
}//4
else {//6
if( event_id==last_event_id )
{//7
SaveDataInBinaryFile ();
SaveDosimetricDataInTextFile();
}//7 
} //6
}//2
_m.unlock();
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::clear(){} 
/*#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::DrawAll(){}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::PrintAll()
{
}
//*#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#= #=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDataInASCIITextFile(int Number_Enough_Events )
{//1
std::ofstream   _File;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
_File.open( 
 this->pDetectorConstruction->SourceOrganeName+"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+"_"+this->pDetectorConstruction->particle_name+"_"+str_thread +"_saf.txt", std::ios::out );
for (int i=0;i<this->pDetectorConstruction->NumberOfPhantomOrgans;i++) {
_File << Number_Enough_Events  << "\t" << this->_InterDosiData[i].ORGANE_ID << "\t" <<  this->_InterDosiData[i].ORGANE_NAME <<  "\t" <<  this->_InterDosiData[i].STD_DEV<< endl;
}
_File.close();
G4cout<<"InterDosi-> SaveDataInASCIITextFile:  "<< G4Threading::G4GetThreadId()<<G4endl;
}
//*#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#= #=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDataInBinaryFile()
{//1
G4ThreadLocal fstream fs;
InterDosiData tmp_InterDosiData;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
fs.open(this->pDetectorConstruction->SourceOrganeName+"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+"_"+this->pDetectorConstruction->particle_name+"_"+str_thread +".dat", ios::out | ios::binary );
for (int i=0;i<this->pDetectorConstruction->NumberOfPhantomOrgans;i++) {
tmp_InterDosiData.ORGANE_ID        = this->_InterDosiData[i].ORGANE_ID;
strcpy(tmp_InterDosiData.ORGANE_NAME     , this->_InterDosiData[i].ORGANE_NAME);
tmp_InterDosiData.KINETIC_ENERGY   = this->pDetectorConstruction->kinetic_energy/MeV;
tmp_InterDosiData.ABSORBED_ENERGY  = this->_InterDosiData[i].ABSORBED_ENERGY;
tmp_InterDosiData.ABSORBED_ENERGY2 = this->_InterDosiData[i].ABSORBED_ENERGY2;
tmp_InterDosiData.STD_DEV          = this->_InterDosiData[i].STD_DEV;
tmp_InterDosiData.NEVENT           = this->_InterDosiData[i].NEVENT;
tmp_InterDosiData.ORGANE_VOLUME    = this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(_InterDosiData[i].ORGANE_NAME);
tmp_InterDosiData.ORGANE_MASSE     = this->pDetectorConstruction->GetOrganeDensity(_InterDosiData[i].ORGANE_ID)*this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(_InterDosiData[i].ORGANE_NAME)  ;// g.
fs.write(reinterpret_cast<char *>(&tmp_InterDosiData),sizeof(InterDosiData));
}
fs.close();
G4cout<<"InterDosi-> SAVING DOSIMETRIC DATA FROM THREAD:  "<< G4Threading::G4GetThreadId()<<G4endl;
}
//1/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
bool PhantomSD::IsAllStdValuesAreLessThanUnit()
{//1
float MAX_STD_DEV_IN_EACh_ThREAD = sqrt(this-> NumberOfThreads) * this->pDetectorConstruction->MAX_STD_DEV;
for (int i=0; i < this->pDetectorConstruction->NumberOfPhantomOrgans ; i++)
{//2
//or 
if (this->_InterDosiData[i].STD_DEV > MAX_STD_DEV_IN_EACh_ThREAD or this->_InterDosiData[i].STD_DEV==-1    ) 
{//3
return false;
}//3
}//2
return true;
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveSimData()
{//1
std::ofstream  File;
File.open("psim.data", std::ios::out);
 File <<this->pDetectorConstruction->SourceOrganeName+"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy) +"_"+this->pDetectorConstruction->particle_name+"P"<< "\n"<< this->cpu_time << "\n" <<this->pDetectorConstruction ->NumberOfThread<< "\n" <<this->pDetectorConstruction->NumberOfEventsEnoughToBeProcessed  << "\n" << this->pDetectorConstruction->ParticleRecyclingFactor << "\n"  <<this->pDetectorConstruction->kinetic_energy<<"\n"<< this->pDetectorConstruction->NumberOfPhantomOrgans <<endl ;
File.close();
}//1
//1/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDataInBinaryFileP()
{//1
G4ThreadLocal fstream fs;
InterDosiData tmp_InterDosiData;
G4cout<<"InterDosi-> UNDER SAVING DOSIMETRIC DATA FROM THREAD:  "<< G4Threading::G4GetThreadId()<<G4endl;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
fs.open(this->pDetectorConstruction->SourceOrganeName+"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+"_"+this->pDetectorConstruction->particle_name+"P_"+str_thread +".dat", ios::out | ios::binary );
for (int i=0;i<this->pDetectorConstruction->NumberOfPhantomOrgans;i++) {
tmp_InterDosiData.ORGANE_ID        = this->_InterDosiData[i].ORGANE_ID;
strcpy(tmp_InterDosiData.ORGANE_NAME     , this->_InterDosiData[i].ORGANE_NAME);
tmp_InterDosiData.KINETIC_ENERGY   = this->pDetectorConstruction->kinetic_energy/MeV;
tmp_InterDosiData.ABSORBED_ENERGY  = this->_InterDosiData[i].ABSORBED_ENERGY;
tmp_InterDosiData.ABSORBED_ENERGY2 = this->_InterDosiData[i].ABSORBED_ENERGY2;
tmp_InterDosiData.STD_DEV          = this->_InterDosiData[i].STD_DEV;
tmp_InterDosiData.NEVENT           = this->_InterDosiData[i].NEVENT;
tmp_InterDosiData.ORGANE_VOLUME    = this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(_InterDosiData[i].ORGANE_NAME);
tmp_InterDosiData.ORGANE_MASSE     = this->pDetectorConstruction->GetOrganeDensity(_InterDosiData[i].ORGANE_ID)*this->pDetectorConstruction->GetOrganTotalVoxelizedVolume(_InterDosiData[i].ORGANE_NAME);//gramme.
fs.write(reinterpret_cast<char *>(&tmp_InterDosiData),sizeof(InterDosiData));
}
fs.close();
G4cout<<"InterDosi->  SAVING OK FROM THREAD:  "<< G4Threading::G4GetThreadId()<<G4endl;
//1/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
}
