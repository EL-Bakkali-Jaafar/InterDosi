/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/ 
#include "RunAction.hh"
#include <ctime>
#include "G4Threading.hh"
#include <fstream>
#include <iostream>
#include "G4ios.hh"
#include <stdio.h>
#include <math.h>
#include "G4RunManager.hh"
#include <ctime>
#include  "DetectorConstruction.hh"
#include "G4tgbGeometryDumper.hh"
#include "G4Timer.hh"
using namespace std;
#include  "DetectorConstruction.hh"
#include "G4Timer.hh"
#include "G4Threading.hh"
G4Timer                     * myTimer;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
RunAction::RunAction()
{

myTimer                                     = new G4Timer();

}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
RunAction::~RunAction()
{
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void RunAction::BeginOfRunAction(const G4Run* )
{
this->runManager                    = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
this->pDetectorConstruction->myTimer= new G4Timer();
this->pDetectorConstruction->myTimer->Start();

 std::string                TERMINAL_HEADER =

"#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#\nInterDosi version 1.0: an open-source Geant4-based application for internal dosimetry in voxelized phantom\nDeveloped by Dr.Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco,  13/10/ 2019\nWebpage :https://github.com/EL-Bakkali-Jaafar/G4\n#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#\n";
G4cout <<  TERMINAL_HEADER  <<G4endl;
 if( IsMaster() )
{ 
myTimer->Start();
};
}



/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void RunAction::EndOfRunAction(const G4Run*)
{
 
myTimer->Stop();
this->cpu_time=myTimer->GetRealElapsed();

G4cout <<"CPU  TIME (S) " <<this->cpu_time <<G4endl;

//G4tgbGeometryDumper::GetInstance()->DumpGeometry(this->pDetectorConstruction->PhantomName+".geom");

 
 {
if (this->pDetectorConstruction->ApplyStdThreshold==false){
 std::ofstream  File;
File.open("sim.data", std::ios::out);
this->NumberOfThread =this->pDetectorConstruction ->NumberOfThread;
G4cout <<"END !  "  <<G4endl;
File <<this->pDetectorConstruction->SourceOrganeName+"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy) +"_"+this->pDetectorConstruction->particle_name<< "\n"<< this->cpu_time << "\n" <<this->NumberOfThread << "\n" <<this->runManager ->GetNumberOfEventsToBeProcessed()  << "\n" << this->pDetectorConstruction->ParticleRecyclingFactor << "\n"  <<this->pDetectorConstruction->kinetic_energy<<"\n"<< this->pDetectorConstruction->NumberOfPhantomOrgans<<"\n"<<this->pDetectorConstruction->PhantomName<< "\n"<< this->pDetectorConstruction->AnatomicalRegion << "\n"<< this->pDetectorConstruction ->PhantomDescriptorFileFullPath<<  endl ;
File.close();
 
std::ofstream  _File;
_File.open("DoseInXYZ.info", std::ios::out);
this->NumberOfThread =this->pDetectorConstruction ->NumberOfThread;

_File    << this->pDetectorConstruction->SourceOrganeName +"_"+ std::to_string(this->pDetectorConstruction->kinetic_energy)+ "_"+this->pDetectorConstruction->particle_name 
        << "\n"<<this->NumberOfThread 
        << "\n"<< this->pDetectorConstruction->Number_Of_Voxels_Along_x
        << "\n"<< this->pDetectorConstruction->Number_Of_Voxels_Along_y
        << "\n"<< this->pDetectorConstruction->Number_Of_Voxels_Along_z <<"\n"<< this->pDetectorConstruction ->PhantomDescriptorFileFullPath<<endl ;
_File.close();

}
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
