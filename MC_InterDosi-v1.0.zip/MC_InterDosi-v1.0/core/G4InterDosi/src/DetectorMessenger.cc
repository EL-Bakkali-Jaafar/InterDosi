 /*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#include "DetectorMessenger.hh"
#include "DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::DetectorMessenger(DetectorConstruction* pDetectorConstruction)
: G4UImessenger(),fDetectorConstruction(pDetectorConstruction)
{
 DetectorDir           = new G4UIdirectory("/InterDosi/");
 DetectorDir           -> SetGuidance("............................");
 PrimaryParticleKineticEnergyCmd = new G4UIcmdWithADoubleAndUnit("/InterDosi/PrimaryParticleKineticEnergy",this);  
 PrimaryParticleKineticEnergyCmd->SetGuidance("PrimaryParticleKineticEnergy.");
 PrimaryParticleKineticEnergyCmd->SetParameterName("PrimaryParticleKineticEnergy",false);
 PrimaryParticleKineticEnergyCmd->SetUnitCategory("Energy");
 PrimaryParticleKineticEnergyCmd->SetRange("PrimaryParticleKineticEnergy>0.0");
 PrimaryParticleNameCmd = new G4UIcmdWithAString("/InterDosi/PrimaryParticleName",this);  
 PrimaryParticleNameCmd->SetGuidance("PrimaryParticleName");
 PrimaryParticleNameCmd->SetParameterName("PrimaryParticleName",false);
 BackgroundID_Cmd = new G4UIcmdWithAnInteger("/InterDosi/BackgroundID",this);  
 BackgroundID_Cmd->SetGuidance("Set BackgroundID.");
 BackgroundID_Cmd ->SetParameterName("BackgroundID",false);
 BackgroundID_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 NumberOfSameParticle_Cmd = new G4UIcmdWithAnInteger("/InterDosi/ParticleRecyclingFactor",this);  
 NumberOfSameParticle_Cmd->SetGuidance("Set ParticleRecyclingFactor.");
 NumberOfSameParticle_Cmd ->SetParameterName("ParticleRecyclingFactor",false);
 NumberOfSameParticle_Cmd ->SetRange("ParticleRecyclingFactor>=0");
 NumberOfSameParticle_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 PhantomDescriptorFileFullPath_Cmd  = new G4UIcmdWithAString("/InterDosi/PhantomDescriptorFileFullPath",this);
 PhantomDescriptorFileFullPath_Cmd  ->SetGuidance("");
 PhantomDescriptorFileFullPath_Cmd ->SetParameterName("PhantomDescriptorFileFullPath",false);
 PhantomDescriptorFileFullPath_Cmd  ->SetDefaultValue("");
 PhantomDescriptorFileFullPath_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 MAX_STD_DEVCmd = new G4UIcmdWithADouble("/InterDosi/Set_MAX_STD_DEV",this);  
 MAX_STD_DEVCmd->SetGuidance("MAX_STD_DEV.");
 MAX_STD_DEVCmd->SetParameterName("MAX_STD_DEV",false);
 MAX_STD_DEVCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 ApplyStdThresholdCmd = new G4UIcmdWithABool("/InterDosi/ApplyStdThreshold",this);  
 ApplyStdThresholdCmd->SetGuidance("ApplyStdThreshold.");
 ApplyStdThresholdCmd->SetParameterName("ApplyStdThreshold",false);
 ApplyStdThresholdCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
 NumberOfThreads_Cmd = new G4UIcmdWithAnInteger("/InterDosi/NumberOfThreads",this);  
 NumberOfThreads_Cmd->SetGuidance("Set  Number Of Threads.");
 NumberOfThreads_Cmd ->SetParameterName("NumberOfThreads",false);
 NumberOfThreads_Cmd ->SetRange("NumberOfThreads>=0");
 NumberOfThreads_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 SourceOrganeNameCmd  = new G4UIcmdWithAString("/InterDosi/SourceOrganeName",this);
 SourceOrganeNameCmd  ->SetGuidance("");
 SourceOrganeNameCmd  ->SetParameterName("SourceOrganeName",false);
 SourceOrganeNameCmd  ->SetDefaultValue("");
 SourceOrganeNameCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 projectionCmd  = new G4UIcmdWithAString("/InterDosi/Projection",this);
 projectionCmd  ->SetGuidance("");
 projectionCmd  ->SetParameterName("Projection",false);
 projectionCmd  ->SetDefaultValue("");
 projectionCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 SliceIdCmd = new G4UIcmdWithAnInteger("/InterDosi/SliceId",this);  
 SliceIdCmd->SetGuidance("Set SliceId.");
 SliceIdCmd ->SetParameterName("SliceId",false);
 SliceIdCmd ->SetRange("SliceId>=0");
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::~DetectorMessenger()
{
  delete PrimaryParticleNameCmd;
  delete PrimaryParticleKineticEnergyCmd;
  delete DetectorDir;    
  delete PrimaryParticleKineticEnergyCmd;
  delete NumberOfSameParticle_Cmd;
  delete SourceOrganeNameCmd;
  delete projectionCmd;
  delete SliceIdCmd;
  delete PhantomDescriptorFileFullPath_Cmd;
  delete BackgroundID_Cmd;
  delete MAX_STD_DEVCmd;
  delete ApplyStdThresholdCmd;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{       
      if(command==NumberOfSameParticle_Cmd ){fDetectorConstruction->SetParticleRecyclingFactor(NumberOfSameParticle_Cmd->GetNewIntValue(newValue));}  
else  if( command == NumberOfThreads_Cmd ){fDetectorConstruction-> SetNumberOfThreads(NumberOfThreads_Cmd->GetNewIntValue(newValue));}  
else  if( command == PrimaryParticleKineticEnergyCmd ){ fDetectorConstruction->set_kinetic_energy(PrimaryParticleKineticEnergyCmd->GetNewDoubleValue(newValue));}
else  if( command == PrimaryParticleNameCmd ){ fDetectorConstruction->set_particle_name(newValue);}
else  if(command==SourceOrganeNameCmd ){fDetectorConstruction->SetSourceOrganeName(newValue);}   
else  if(command==projectionCmd ){fDetectorConstruction->SetProjection(newValue);}   
else  if( command == SliceIdCmd){fDetectorConstruction-> SetSliceId(SliceIdCmd->GetNewIntValue(newValue));} 
else  if(command==PhantomDescriptorFileFullPath_Cmd){fDetectorConstruction->SetPhantomDescriptorFileFullPath(newValue);} 
else  if( command == BackgroundID_Cmd){fDetectorConstruction-> SetBackgroundID(BackgroundID_Cmd->GetNewIntValue(newValue));}  
else  if( command == MAX_STD_DEVCmd ){ fDetectorConstruction->Set_MAX_STD_DEV(MAX_STD_DEVCmd->GetNewDoubleValue(newValue));}
else  if( command == ApplyStdThresholdCmd ){ fDetectorConstruction->setApplyStdThreshold(ApplyStdThresholdCmd->GetNewBoolValue(newValue));}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
