/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#include "G4RunManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <stdio.h> 
#include "Voxel.hh"
#include <iterator>
#include <stdlib.h>
#include <vector>
#include "G4tgbGeometryDumper.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"
#include "PhantomSD.hh"
#include "G4VisAttributes.hh"
#include "DetectorMessenger.hh"
#include "G4TransportationManager.hh"
#include "G4tgbVolumeMgr.hh"
#include "G4UserLimits.hh"
#include "G4tgrMessenger.hh"
#include "G4tgbMaterialMgr.hh"
#include "G4LogicalVolumeStore.hh"
#include <iostream>       
#include <cstddef>          
#include "G4ProductionCuts.hh"
#include "G4RegionStore.hh"

using namespace std;
vx ***Voxels;
static int l=0;
int N =0;
int B=0;
int C=0;
int NumberOfElements=0;
 
int NuMbeRoFmAtErIaL=0;
int incr =0;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::setApplyStdThreshold(bool _ApplyStdThreshold )
{
this->ApplyStdThreshold= _ApplyStdThreshold ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::Set_MAX_STD_DEV(G4double _MAX_STD_DEV)
{
this->MAX_STD_DEV= _MAX_STD_DEV;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ReadMaterialDataFromFile(const G4String _MaterialFile)
{//1
material_density*= g/cm3;
ifstream MaterialDataFromFileStream ;
int i=-1;
MaterialDataFromFileStream .open(_MaterialFile.c_str());
string STR;
while ( getline(MaterialDataFromFileStream ,STR))
{//2
vector<string>  _result;
istringstream  _iss(STR);
i++;
for(string  _s_data;  _iss >>  _s_data; )
{//3
_result.push_back( _s_data);
}//3
if (i==0) 
{//4
material_name= _result[0];
material_density =stod(  _result[1]);
number_of_elements_in_material=stoi(  _result[2]);
_ELEMENT_DATA = new  ELEMENT_DATA[number_of_elements_in_material];
}//4
if (i>0) 
{//5
_ELEMENT_DATA[i-1].FRACTION =stod(_result[1]);
_ELEMENT_DATA[i-1].ELEMENT= _result[0];
}//5
} //2
MaterialDataFromFileStream.close();
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Material *  DetectorConstruction::CreateMaterial(const G4String _MaterialName)
{
ReadMaterialDataFromFile("../../core/MaterialsDB/"+_MaterialName+".mat");
G4NistManager* nist = G4NistManager::Instance(); 
nist->SetVerbose(0);
G4Material * myMaterial = new G4Material(material_name,material_density*g/cm3,  number_of_elements_in_material );
for (int i=0; i< number_of_elements_in_material;i++) {
myMaterial->AddElement( nist->FindOrBuildElement(_ELEMENT_DATA[i].ELEMENT),   _ELEMENT_DATA[i].FRACTION);
}
return myMaterial ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::OrganeID(const string OrganeName)
{
int  _ORGAN_ID;
for (int i=0; i < this->NumberOfPhantomOrgans; i++) 
{
if (_VoxelizedPhantomStruc[i].ORGAN_NAME==OrganeName) {_ORGAN_ID=_VoxelizedPhantomStruc[i].ORGAN_ID;
};
}
return _ORGAN_ID;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
string  DetectorConstruction::OrganeName(const G4int OrganeId)
{
string  _ORGAN_NAME="";
for (int i=0; i < this->NumberOfPhantomOrgans; i++) 
{
if (_VoxelizedPhantomStruc[i].ORGAN_ID==OrganeId)
{_ORGAN_NAME=_VoxelizedPhantomStruc[i].ORGAN_NAME;
};
}
return _ORGAN_NAME;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Colour DetectorConstruction::OrganeColor(const G4int OrganeId)
{
int Organ_Color_R=0;
int Organ_Color_G=0;
int Organ_Color_B=0;
for (int i=0; i < this->NumberOfPhantomOrgans; i++) 
{
if (_VoxelizedPhantomStruc[i].ORGAN_ID==OrganeId) {
Organ_Color_R =_VoxelizedPhantomStruc[i].ORGAN_COLOR_R;
Organ_Color_G =_VoxelizedPhantomStruc[i].ORGAN_COLOR_G;
Organ_Color_B =_VoxelizedPhantomStruc[i].ORGAN_COLOR_B;
};
}
return  G4Colour(Organ_Color_R/255.,Organ_Color_G/255.,Organ_Color_B/255.);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Material * DetectorConstruction::MaterialName(const G4int OrganId)
{
string _ORGAN_MATERIAL="";
int mat_id=0;
for (int i=0; i < this->NumberOfPhantomOrgans; i++) 
{//2
if (_VoxelizedPhantomStruc[i].ORGAN_ID==OrganId)
{//3
_ORGAN_MATERIAL= _VoxelizedPhantomStruc[i].ORGAN_MATERIAL;
for (int j=0; j <  NuMbeRoFmAtErIaL; j++) 
{//4
if (_ORGAN_MATERIAL == ArrayMat[j]->GetName().c_str()) 
{//5
mat_id =j;
}//5
}//4
};//3
}//2
return ArrayMat[mat_id] ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_kinetic_energy(G4double _kinetic_energy)
{ 
this->kinetic_energy=_kinetic_energy;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetPhantomDescriptorFileFullPath(string  _PhantomDescriptorFileFullPath) {
this->PhantomDescriptorFileFullPath = _PhantomDescriptorFileFullPath;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::DetectorConstruction(): G4VUserDetectorConstruction()
{
pDetectorMessenger= new DetectorMessenger(this); 
this->BackgroundID=-1;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetSliceId( int _SliceId)
{
this->SliceId=_SliceId;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetBackgroundID( int _BackgroundID)
{
this->BackgroundID=_BackgroundID;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfThreads( int _NumberOfThread)
{
this->NumberOfThread=_NumberOfThread;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetParticleRecyclingFactor( int _ParticleRecyclingFactor)
{
this->ParticleRecyclingFactor=_ParticleRecyclingFactor;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::~DetectorConstruction()
{ 
PhysicsVolPosList.clear();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4VPhysicalVolume* DetectorConstruction::Construct()
{//1  
this->AnatomicalRegion="";
NumberOfEventsEnoughToBeProcessed=0;
ReadAndSetupVoxelizedPhantomParameters();
this->runManager = G4RunManager::GetRunManager();
this->Total_Events_To_Be_Processed= this->runManager->GetNumberOfEventsToBeProcessed();
this->NumberOfThread=G4Threading::G4GetNumberOfCores();
G4NistManager* nist = G4NistManager::Instance();
G4bool checkOverlaps = true;
G4Material* world_mat = nist->FindOrBuildMaterial("G4_Galactic");
G4Box* solidWorld =new G4Box("World",    PHANTOM_X_DIM,  PHANTOM_Y_DIM,  PHANTOM_Z_DIM);  
G4LogicalVolume* logicWorld =  new G4LogicalVolume(solidWorld,world_mat,"World");           
logicWorld ->SetVisAttributes(G4VisAttributes::GetInvisible());   
this->physWorld =  new G4PVPlacement(0,G4ThreeVector(),logicWorld,"World",0, false, 0,checkOverlaps);        
if (this->Projection=="none")  
{//2
Construct_Phantom( new G4ThreeVector(0.0,0.0,0.0));
}//2
 else 
{ //3
Construct_Partial_Phantom( new G4ThreeVector(0.0,0.0,0.0), this->SliceId) ;
}//3
return this->physWorld;
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructSDandField()
{//1
G4SDManager* pSDManager = G4SDManager::GetSDMpointer();
G4ThreadLocal PhantomSD *mSD = new PhantomSD(this->PhantomName);
pSDManager-> AddNewDetector(mSD);
for ( int i=0;i< this->NumberOfPhantomOrgans ;i++)  SetSensitiveDetector(OrganeName(_VoxelizedPhantomStruc[i].ORGAN_ID),mSD);  
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetProjection(string  _Projection) {
this->Projection = _Projection;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_particle_name(string  _particle_name) {
this->particle_name = _particle_name;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganeDensity(int  _organ_id) {
G4double density=0.0*g/cm3;
density= MaterialName(_organ_id)->GetDensity();
return density/(g/cm3) ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganTotalVoxelizedVolume(const string _OrganTotalVoxelizedVolumeName) {
int NumberOfVoxelsInCurrentOrgan=0;
G4double _OrganTotalVoxelizedVolume=0.0;
int organ_id=0;
for (int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
for (int iz=0; iz< this->Number_Of_Voxels_Along_z; iz++){

if (Voxels[ix][iy][iz].organe!=to_string(this->BackgroundID)){
if (OrganeName(stoi(Voxels[ix][iy][iz].organe))==_OrganTotalVoxelizedVolumeName )
{ NumberOfVoxelsInCurrentOrgan++; organ_id=stoi(Voxels[ix][iy][iz].organe); }}}};}

cout <<" Current Organ ID  "  << organ_id  <<" Current Organ  " << _OrganTotalVoxelizedVolumeName<<" Number of Constructed Voxels  "<< NumberOfVoxelsInCurrentOrgan  << endl;
_OrganTotalVoxelizedVolume=NumberOfVoxelsInCurrentOrgan* VOXEL_X_DIM*VOXEL_Y_DIM*VOXEL_Z_DIM;
return   _OrganTotalVoxelizedVolume/( cm* cm* cm);// cm3
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::OrganIDtoIterator(int  _OrganID)
{
int result=0;
for (int Iterator=0; Iterator< this->NumberOfPhantomOrgans; Iterator++) {
if (_VoxelizedPhantomStruc[Iterator].ORGAN_ID==_OrganID) { result=Iterator;} }
return result;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::ConstructLogicalVolumes(G4String _SourceOrganeName){
for (int Iterator=0; Iterator< this->NumberOfPhantomOrgans; Iterator++) {
int OrganeId =_VoxelizedPhantomStruc[Iterator].ORGAN_ID;
G4Box*  Voxel = new G4Box("Voxel_"+OrganeName(OrganeId), VOXEL_X_DIM/2.0, VOXEL_Y_DIM/2.0, VOXEL_Z_DIM/2.0);
tmp[Iterator]= new G4LogicalVolume(Voxel, MaterialName(OrganeId),OrganeName(OrganeId), 0, 0, 0);
G4VisAttributes * _attribut=  new G4VisAttributes(   this->OrganeColor(OrganeId)); 
tmp[Iterator]->SetVisAttributes(_attribut); 
if ( OrganeName(OrganeId)==_SourceOrganeName) 
{
_attribut->SetForceSolid(true);  
_attribut->SetForceAuxEdgeVisible(true);  
tmp[Iterator]->SetVisAttributes(_attribut);
 }}} 
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::SetMaxNumberOfPointsInOrgan( int _MaxNumberOfPointsInOrgan){
this->MaxNumberOfPointsInOrgan=_MaxNumberOfPointsInOrgan;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::SetSourceOrganeName( G4String _SourceOrganeName){
this->SourceOrganeName=_SourceOrganeName;
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::Construct_Partial_Phantom( G4ThreeVector* center_position, int slice_id) 
{
ConstructLogicalVolumes(this->SourceOrganeName);
int val_x, val_y, val_z;
int ix, iy, iz;
int i_z=0;
if ( this->Projection=="PlanYZ") 
{
ix=slice_id; val_y=this->Number_Of_Voxels_Along_y ; val_z= this->Number_Of_Voxels_Along_z;
for ( iy=0; iy< val_y; iy++)
{
for ( iz=0; iz< val_z; iz++)
{
if (Voxels[ix][iy][iz].organe!=to_string(this->BackgroundID) )
{
new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz), tmp[OrganIDtoIterator(stoi(Voxels[ix][iy][iz].organe))]
,this->physWorld,false,ix*iy*iz);
}}}};
if ( this->Projection=="PlanXZ")
{
iy=slice_id; val_x=this->Number_Of_Voxels_Along_x ; val_z= this->Number_Of_Voxels_Along_z;
for ( ix=0; ix< val_x; ix++)
{
for ( iz=0; iz< val_z; iz++)
{
if (Voxels[ix][iy][iz].organe!=to_string(this->BackgroundID) )
{
 new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz), tmp[OrganIDtoIterator(stoi(Voxels[ix][iy][iz].organe))]
,this->physWorld,false,ix*iy*iz);
}}}};
if ( this->Projection=="PlanXY") 
{
 cout <<" PlanXY  "   << endl;
iz=slice_id; val_y=this->Number_Of_Voxels_Along_y ; val_x= this->Number_Of_Voxels_Along_x;
for ( ix=0; ix< val_x; ix++)
{
for ( iy=0; iy< val_y; iy++)
{
 
if (Voxels[ix][iy][iz].organe!=to_string(this->BackgroundID) )
{

 new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz), tmp[OrganIDtoIterator(stoi(Voxels[ix][iy][iz].organe))]
,this->physWorld,false,ix*iy*iz);
}}}};
if ( this->Projection=="CutZView") 
{
iz=slice_id; val_y=this->Number_Of_Voxels_Along_y ; val_x= this->Number_Of_Voxels_Along_x;
for (i_z=iz; i_z< this->Number_Of_Voxels_Along_z; i_z++){
for ( ix=0; ix< val_x; ix++)
{
for ( iy=0; iy< val_y; iy++)
{
if (Voxels[ix][iy][i_z].organe!=to_string(this->BackgroundID) )
{
new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((i_z+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(i_z), tmp[stoi(Voxels[ix][iy][i_z].organe)]
,this->physWorld,false,ix*iy*i_z);
}}}}};
delete [] Voxels;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::Construct_Phantom( G4ThreeVector* center_position) 
{
int  NumberOfConstructedVoxels=0;
ConstructLogicalVolumes(this->SourceOrganeName);
for (int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
for (int iz=0; iz< this->Number_Of_Voxels_Along_z; iz++)
{
if (Voxels[ix][iy][iz].organe!=to_string(this->BackgroundID) ){
NumberOfConstructedVoxels++;
if ( OrganeName(stoi(Voxels[ix][iy][iz].organe) ) == this->SourceOrganeName)
{
PhysicsVolPosList.push_back(G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM));
}
new G4PVPlacement(0,G4ThreeVector(center_position->x()+((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM,center_position->y()+((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM, center_position->z()+((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),to_string(ix)+" "+to_string(iy)+" "+to_string(iz)+" "+Voxels[ix][iy][iz].organe, tmp[OrganIDtoIterator(stoi(Voxels[ix][iy][iz].organe))]
,this->physWorld,false,ix*iy*iz); 
}}}}
cout << " Number of Constructed Voxels  "<< NumberOfConstructedVoxels  << endl;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ReadAndSetupVoxelizedPhantomParameters(){
int incrementor=0;
ifstream PhantomDescriptorFile;
PhantomDescriptorFile.open(this->PhantomDescriptorFileFullPath);
string str,cp_str;
string key="";
list<string> MaterialsList;
vector<string> data;
while (getline(PhantomDescriptorFile,str))
{
cp_str= str;
vector<string> result;
istringstream iss(str);
while (getline(iss,str,'\t'))
{
result.push_back(str);
}
string key=result[0];
if (key=="@VoxelizedPhantomName") {this->PhantomName=result[1];  };
if (key=="@VoxelizedPhantomFileDir") {this->PhantomFileDir=result[1];  };
if (key=="@Voxelizedimensions")
{ 
this->PHANTOM_X_DIM=atof(result[1].c_str());
this->PHANTOM_Y_DIM=stod(result[2]);
this->PHANTOM_Z_DIM=stod(result[3]);
};
if (key=="@NumberOfVoxels")
{ 
this->Number_Of_Voxels_Along_x=stoi(result[1]);
this->Number_Of_Voxels_Along_y=stoi(result[2]);
this->Number_Of_Voxels_Along_z=stoi(result[3]);
};
if (key=="@NumberOfPhantomOrgans") {
this->NumberOfPhantomOrgans=stoi(result[1])-1;
_VoxelizedPhantomStruc = new VoxelizedPhantomStruc[this->NumberOfPhantomOrgans];}
if (key=="@BackgroundID") 
{
this->BackgroundID=stoi(result[1]);
}
if (key=="@PhantomOrganItem") {
if (stoi(result[1])  != this->BackgroundID){
_VoxelizedPhantomStruc[incrementor].ORGAN_ID       = stoi(result[1]);
_VoxelizedPhantomStruc[incrementor].ORGAN_NAME     = result[2];
_VoxelizedPhantomStruc[incrementor].ORGAN_MATERIAL = result[3];
_VoxelizedPhantomStruc[incrementor].ORGAN_COLOR_R    = stoi(result[4]);
_VoxelizedPhantomStruc[incrementor].ORGAN_COLOR_G    = stoi(result[5]);
_VoxelizedPhantomStruc[incrementor].ORGAN_COLOR_B    = stoi(result[6]);
cout << "InterDosi-> ORGAN_ID : "  <<   stoi(result[1]) <<"  Read Material: "  <<  result[3] << endl;
MaterialsList.push_back(result[3]);
incrementor++;
}};
if (key=="@AnatomicalRegion") {
 
this->AnatomicalRegion = cp_str; 
};
}
this->VOXEL_X_DIM=PHANTOM_X_DIM/(G4double)this->Number_Of_Voxels_Along_x; 
this->VOXEL_Y_DIM=PHANTOM_Y_DIM/(G4double)this->Number_Of_Voxels_Along_y; 
this->VOXEL_Z_DIM=PHANTOM_Z_DIM/(G4double)this->Number_Of_Voxels_Along_z; 
cout<< "InterDosi-> Voxelized phantom name: " << this->PhantomName <<'\n'
    << "InterDosi-> Number of voxels along X: "<< this->Number_Of_Voxels_Along_x << '\n' 
    << "InterDosi-> Number of voxels along Y: "<< this->Number_Of_Voxels_Along_y << '\n'   
    << "InterDosi-> Number of voxels along Z: "<< this->Number_Of_Voxels_Along_z << '\n'         
    << "InterDosi-> Voxel dimensions (x,y,z) (mm mm mm):"<< this->VOXEL_X_DIM<<";" << this->VOXEL_Y_DIM <<";" << this->VOXEL_Z_DIM <<'\n'     
    << "InterDosi-> Total number of voxels: "<< this->Number_Of_Voxels_Along_y *this->Number_Of_Voxels_Along_x*this->Number_Of_Voxels_Along_z <<endl;  
PhantomDescriptorFile.close();
Voxels=new vx**[this->Number_Of_Voxels_Along_x];
for (int ix=0; ix<this->Number_Of_Voxels_Along_x; ix++)
{
Voxels[ix]=new vx*[ this->Number_Of_Voxels_Along_y];
for (int iy=0; iy<  this->Number_Of_Voxels_Along_y; iy++)
{
Voxels[ix][iy]=new vx[ this->Number_Of_Voxels_Along_z];
for (int iz=0; iz<  this->Number_Of_Voxels_Along_z; iz++)
{
Voxels[ix][iy][iz].organe=to_string(this->BackgroundID);
}}}
ifstream inFile_IJKID_FILE;
inFile_IJKID_FILE.open(this->PhantomFileDir.c_str());
string STR;
static int total_number_of_voxels=0;
while (getline(inFile_IJKID_FILE,STR))
{
vector<string> IJKID_result;
istringstream IJKID_iss(STR);
for(string IJKID_s_data; IJKID_iss >> IJKID_s_data; )
{
IJKID_result.push_back(IJKID_s_data);
}
int ix=0;
int iy=0;
int iz=0;
string  organ_id="-1";
ix=stoi( IJKID_result[0]);
iy=stoi( IJKID_result[1]);
iz=stoi( IJKID_result[2]);
organ_id= IJKID_result[3];
{
 
Voxels[ix][iy][iz].organe=organ_id;
}
total_number_of_voxels++;
} 
inFile_IJKID_FILE.close();
MaterialsList.sort();
MaterialsList.unique();
for (list<string>::iterator it=MaterialsList.begin(); it!=MaterialsList.end(); ++it)
{ 
ArrayMat.push_back(CreateMaterial(*it));    ;
cout<<  "InterDosi-> Material Name: "<< "<"<<ArrayMat[NuMbeRoFmAtErIaL]->GetName()<<">. "   <<    endl;
NuMbeRoFmAtErIaL++;
}}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

