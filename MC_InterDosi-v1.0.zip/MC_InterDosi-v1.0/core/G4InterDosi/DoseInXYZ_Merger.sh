
g++ -std=c++11 -g -Wall  Merge_DoseInXYZFilesFrom_Threads.cc  -o Merge_DoseInXYZFilesFrom_Threads
./Merge_DoseInXYZFilesFrom_Threads
