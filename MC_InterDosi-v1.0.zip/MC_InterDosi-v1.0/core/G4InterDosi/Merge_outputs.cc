/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "InterDosiDt.hh"
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <ctime>
#include <string>
#include <cstring> 
#include <sstream>
using namespace std;
string               file                         = "" ,
                     inputfile                    = "" ,
                     PhantomName                  = "" ,
                     str                          = "" ,
                     cputime                      = "" ;
int                  NumberOfThread               = 0  ,
                     i                            = -1 ,
                     NumberOforgans                    ;
unsigned  int        Total_Events_To_Be_Processed = 0  ,
                     NumberOfSameParticle         = 0  , 
                     nthread                      = 0  ;
unsigned  long int   Total_Events                      ;
double               kinetic_energy                    ;
InterDosiData        tmp_InterDosiData                 ;
InterDosiData *      RAM_InterDosiData                 ;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_TXT()
{
ifstream inFile;
inFile.open(inputfile.c_str() );
while (getline(inFile,str))
{
i++;
if (i==0)     file=str; 
if (i==1)     cputime=str;
if (i==2)     NumberOfThread=stoi(str);
if (i==3)     Total_Events_To_Be_Processed=stoi(str);
if (i==4)     NumberOfSameParticle=stoi(str);
if (i==5)     kinetic_energy=strtof((str).c_str(),0);
if (i==6)     NumberOforgans=stoi(str);
if (i==7)     PhantomName =str ;
}
inFile.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void WRITE_MERGED_DOSIMETRIC_TXT()
{

Total_Events=( unsigned long int ) NumberOfSameParticle*Total_Events_To_Be_Processed;
std::ofstream  SAFS_File;
SAFS_File.open(file+"_afs.xls", std::ios::out);
std::ofstream  TextFile;
TextFile.open(PhantomName+".info", std::ios::out);


SAFS_File 
         <<"\nCPU  TIME (S) " << '\t' <<cputime 
         <<"\nSOURCE_EMITTED_ENERGY (MeV)" <<'\t' <<kinetic_energy     
         <<"\nPARTICLE RECYCLING FACTOR " <<'\t' << NumberOfSameParticle   
         <<"\nNUMBER OF SIMULATED EVENTS  "  <<'\t' <<     Total_Events_To_Be_Processed  
         <<"\nTOT NUMBER OF SIMULATED EVENTS  "<< '\t' <<Total_Events
         <<"\nORGAN NAME  "<< '\t' <<" AF " << '\t'  <<" SAF(g^-1) "<<'\t' <<" RELATIVE ERROR (%) "<< endl;


for (int i= 0;i<NumberOforgans; i++) 
{//2

{
SAFS_File <<std::scientific<< RAM_InterDosiData[i].ORGANE_NAME << '\t' <<   (RAM_InterDosiData[i].ABSORBED_ENERGY/Total_Events)/kinetic_energy  << '\t'  << ((RAM_InterDosiData[i].ABSORBED_ENERGY/Total_Events)/RAM_InterDosiData[i].ORGANE_MASSE)/kinetic_energy  <<'\t' << RAM_InterDosiData[i].STD_DEV  << endl;

TextFile <<"===============================================================" 
         <<"\nORGANE_NAME: " 
         <<std::scientific
         <<RAM_InterDosiData[i].ORGANE_NAME     
         <<"\nORGANE_MASSE (  g): " 
         <<std::scientific<<RAM_InterDosiData[i].ORGANE_MASSE 
         <<"\nORGANE_VOLUME ( CM_3 ): "
         <<RAM_InterDosiData[i].ORGANE_VOLUME<< endl;
}        
}//2
SAFS_File.close();
TextFile.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_DOSIMETRIC_DATA_FROM_BINARY_FILE(std::string _DosimetricDataFileName)
{
fstream binary_file;
binary_file.open("./"+_DosimetricDataFileName,std::ios::binary|std::ios::in| std::ios::ate );
for (unsigned short int i=0;i<NumberOforgans;i++) 
{
binary_file.seekg(i*sizeof(InterDosiData));
binary_file.read(reinterpret_cast<char *>(&tmp_InterDosiData),sizeof(InterDosiData));
RAM_InterDosiData[i].ORGANE_ID=tmp_InterDosiData.ORGANE_ID;
RAM_InterDosiData[i].NEVENT+=tmp_InterDosiData.NEVENT;
std::strcpy (RAM_InterDosiData[i].ORGANE_NAME, tmp_InterDosiData.ORGANE_NAME);
RAM_InterDosiData[i].ABSORBED_ENERGY+=tmp_InterDosiData.ABSORBED_ENERGY;
RAM_InterDosiData[i].ABSORBED_ENERGY2+=tmp_InterDosiData.ABSORBED_ENERGY2;
RAM_InterDosiData[i].ORGANE_VOLUME  = tmp_InterDosiData.ORGANE_VOLUME;
RAM_InterDosiData[i].ORGANE_MASSE   = tmp_InterDosiData.ORGANE_MASSE;
if (RAM_InterDosiData[i].NEVENT > 1)
{
double ABSORBED_ENERGY_MEAN         = RAM_InterDosiData[i].ABSORBED_ENERGY/RAM_InterDosiData[i].NEVENT;
double ABSORBED_ENERGY2_MEAN        = RAM_InterDosiData[i].ABSORBED_ENERGY2/RAM_InterDosiData[i].NEVENT;
double SIGMA                        = sqrt((ABSORBED_ENERGY2_MEAN-ABSORBED_ENERGY_MEAN*ABSORBED_ENERGY_MEAN)/(RAM_InterDosiData[i].NEVENT-1));
RAM_InterDosiData[i].STD_DEV        = 100*SIGMA/ABSORBED_ENERGY_MEAN ;
}
}
binary_file.close();
remove(_DosimetricDataFileName.c_str());
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int main(int argc,char** argv)
{
inputfile=  argv[1] ;
READ_TXT();
RAM_InterDosiData= new InterDosiData[NumberOforgans];
for (unsigned short int i=0;i<NumberOforgans;i++) 
{
RAM_InterDosiData[i].ORGANE_ID         = 0;
RAM_InterDosiData[i].STD_DEV           = 0;
RAM_InterDosiData[i].NEVENT            = 0;
RAM_InterDosiData[i].ABSORBED_ENERGY   = 0.0;
RAM_InterDosiData[i].ABSORBED_ENERGY2  = 0.0;
RAM_InterDosiData[i].KINETIC_ENERGY    = 0.0;
RAM_InterDosiData[i].ORGANE_VOLUME     = 0.0;
RAM_InterDosiData[i].ORGANE_MASSE      = 0.0;
}
for (int i=0;i<NumberOfThread;i++) 
{
 
cout <<file+"_"+std::to_string(i) +".dat" <<endl;
READ_DOSIMETRIC_DATA_FROM_BINARY_FILE(file+"_"+std::to_string(i) +".dat" );
}
WRITE_MERGED_DOSIMETRIC_TXT();
cout <<argv[0]<<"Merging of dosimetric data from threads have been successfully terminated !" <<endl;
delete [] RAM_InterDosiData;
exit(0) ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
