/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DoseInXYZ_Header.hh"
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <ctime>
#include <string>
#include <sstream>
using namespace std;
string file="";
string str="";
int NumberOfThread=0;
int i=-1;
doseIn3dVoxel ***DVoxels;
int Number_Of_Voxels_Along_x=0;
int Number_Of_Voxels_Along_y=0;
int Number_Of_Voxels_Along_z=0;
string PhantomDescriptorFileFullPath="" ;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_TXT()
{
ifstream inFile;
inFile.open("./DoseInXYZ.info");
while (getline(inFile,str))
{
i++;
if (i==0){ file=str;}
if (i==1) NumberOfThread=stoi(str);
if (i==2) Number_Of_Voxels_Along_x=stoi(str);
if (i==3) Number_Of_Voxels_Along_y=stoi(str);
if (i==4) Number_Of_Voxels_Along_z=stoi(str);
if (i==5) PhantomDescriptorFileFullPath =str ;
}
inFile.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void WRITE_MERGED_DOSIMETRIC_TXT()
{
std::ofstream   _File;
_File.open(file+".DoseInXYZ", std::ios::app);
_File << PhantomDescriptorFileFullPath<<endl;
for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++)
{
for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++)
{
for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++)
{
if ( DVoxels[ix][iy][iz].absorbed_dose!=0.0) _File <<  ix << "\t"<< iy<< "\t"<< iz<< "\t"<< DVoxels[ix][iy][iz].absorbed_dose<<endl;
}}}
_File.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_DOSIMETRIC_DATA_FROM_BINARY_FILE(std::string _DoseInXYZFileName)
{
ifstream inFile;
inFile.open(_DoseInXYZFileName);
std::string str;
vector<string> data;
while (std::getline(inFile,str))
{
std::vector<std::string> result;
std::istringstream iss(str);
for(std::string s_data; iss >> s_data; )
{
result.push_back(s_data);
}
int ix=0;
int iy=0;
int iz=0;
double dose=0.0;
ix     = std::stoi( result[0]);
iy     = std::stoi( result[1]);
iz     = std::stoi( result[2]);
dose   = std::stod(result[3]);
DVoxels[ix][iy][iz].absorbed_dose  += dose;
}
 remove(_DoseInXYZFileName.c_str());
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int main(int argc,char** argv)
{
READ_TXT();
DVoxels=new doseIn3dVoxel**[Number_Of_Voxels_Along_x];
for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++)
{
DVoxels[ix]=new doseIn3dVoxel*[Number_Of_Voxels_Along_y];
for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++)
{
DVoxels[ix][iy]=new doseIn3dVoxel[Number_Of_Voxels_Along_z];
for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++)
{
DVoxels[ix][iy][iz].absorbed_dose  = 0.;
}
}
}
for (int i=0;i<NumberOfThread;i++) 
{
READ_DOSIMETRIC_DATA_FROM_BINARY_FILE(file+"_"+std::to_string(i) +".txt");
}
WRITE_MERGED_DOSIMETRIC_TXT();
return 0;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
