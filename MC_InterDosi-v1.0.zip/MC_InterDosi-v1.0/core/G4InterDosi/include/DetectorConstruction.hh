/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DetectorConstruction_h
#define DetectorConstruction_h 1
#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"
#include "G4ThreeVector.hh"
#include <vector> 
class G4VPhysicalVolume;
class DetectorMessenger;
class G4LogicalVolume;
class G4Material;
class PhantomSD;
class G4tgrMessenger;
class G4RunManager;
class G4Colour;
class G4Timer;
using namespace std;
class DetectorConstruction : public G4VUserDetectorConstruction
{
public:
G4LogicalVolume              * tmp[150];
std::vector<G4Material*>       ArrayMat;
                               DetectorConstruction();
virtual                       ~DetectorConstruction();
virtual void                   ConstructSDandField();
G4Material                   * MaterialName(const G4int materialId);
G4Material                   * CreateMaterial(const G4String);
int                            GetMaterialIdOfOrganId(const G4String);
int                            OrganIDtoIterator(int);
int                            OrganeID(const string );
int                            NumberOfPhantomOrgans,
                               MaxNumberOfPointsInOrgan,
                               Total_Events_To_Be_Processed,
                               SliceId,
                               Number_Of_Voxels_Along_x,
                               Number_Of_Voxels_Along_y,
                               Number_Of_Voxels_Along_z,
                               NumberOfEventsEnoughToBeProcessed,
                               BackgroundID, 
                               number_of_elements_in_material;
void                           set_kinetic_energy(G4double);
void                           setApplyStdThreshold(bool);
void                           SetBackgroundID( int);
void                           SetPhantomDescriptorFileFullPath(string );
void                           SetProjection(string  ); 
void                           Set_MAX_STD_DEV(G4double);
void                           ConstructEncapsulatingOrganSourceVolume(G4ThreeVector* );
void                           Construct_Phantom(G4ThreeVector* ) ;
void                           Construct_Partial_Phantom(G4ThreeVector*, int );
void                           SetSliceId(int);
void                           ConstructLogicalVolumes(G4String  );
void                           ReadAndSetupVoxelizedPhantomParameters();
void                           SetMaxNumberOfPointsInOrgan(int );
void                           ReadMaterialDataFromFile(const G4String );
void                           SetSourceOrganeName( G4String );
void                           SetNumberOfThreads(int);
void                           SetParticleRecyclingFactor(int);
void                           set_particle_name(string  ) ;
G4double                       GetOrganTotalVoxelizedVolume(string );
G4double                       GetOrganeDensity(int);
G4double                       MAX_STD_DEV,
                               material_density,
                               VOXEL_X_DIM,
                               VOXEL_Y_DIM,
                               VOXEL_Z_DIM,
                               PHANTOM_X_DIM,
                               PHANTOM_Y_DIM,
                               PHANTOM_Z_DIM;
virtual                        G4VPhysicalVolume* Construct();
string                         OrganeName(const G4int );

string                         Projection,
                               particle_name,
                               material_name,
                               AnatomicalRegion,
                               PhantomName,
                               PhantomFileDir, 
                               PhantomDescriptorFileFullPath;
G4String                       sensitiveDetectorName, 
                               SourceOrganeName;
G4Colour                       OrganeColor(const G4int OrganeId);
G4ThreeVector                  GetReadOutGeometryCenterPosition() ;
int                            NUMBER_OF_THREADS,
                               ParticleRecyclingFactor,
                               NumberOfThread;
G4double                       kinetic_energy;
PhantomSD*                     mPhantomSD;
static G4ThreadLocal G4bool    fConstructedSDandField;
bool                           ApplyStdThreshold;
G4Timer                     *  myTimer;
DetectorMessenger           *  pDetectorMessenger;
G4tgrMessenger              *  messenger; 
G4LogicalVolume             *  Phantom_Logical;
G4RunManager                *  runManager;
G4VPhysicalVolume           *  Phantom_Physical ;
G4VPhysicalVolume           *  physWorld ;
std::vector<G4ThreeVector>     PhysicsVolPosList;
std::vector<string>           LogicalVolList;
typedef struct
{
string                         ORGAN_NAME,
                               ORGAN_MATERIAL;
int                            ORGAN_COLOR_R,
                               ORGAN_COLOR_G,
                               ORGAN_COLOR_B;
int                            ORGAN_ID;
}                              VoxelizedPhantomStruc;
VoxelizedPhantomStruc       *  _VoxelizedPhantomStruc;
typedef struct
{
string                          ELEMENT;
G4double                        FRACTION;
}                               ELEMENT_DATA;
ELEMENT_DATA                *   _ELEMENT_DATA;
};
#endif
