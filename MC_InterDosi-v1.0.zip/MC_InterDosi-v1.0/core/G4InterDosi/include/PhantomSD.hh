/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi

 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef PhantomSD_h
#define PhantomSD_h 1
#include "G4ThreeVector.hh"
#include "G4VSensitiveDetector.hh"
#include "G4VTouchable.hh"
#include <vector>
#include "G4ios.hh"
#include <stdio.h>
#include "G4Threading.hh"
#include "DVoxel.hh"
using namespace std;
class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;
class DetectorConstruction;
class G4RunManager;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
class  PhantomSD : public G4VSensitiveDetector
{
public:
PhantomSD(
G4String name);
~PhantomSD();
dvxl ***DVoxels;
G4bool ProcessHits(G4Step*aStep,G4TouchableHistory*);
void EndOfEvent(G4HCofThisEvent*HCE);
void SaveDosimetricDataInTextFile();
void clear();
void DrawAll();
void PrintAll();
void SaveDataInBinaryFile(); 
void SaveDataInBinaryFileP(); 
void SaveSimData();
int *GetIdsVoxelXYZ(std::string _physical_volume_name) ;
bool IsAllStdValuesAreLessThanUnit();
void  SaveDataInASCIITextFile(int);
string                         StrWithoutDigits(string );
typedef struct
{
char ORGANE_NAME[100000];
G4double 
ORGANE_MASSE,
ORGANE_VOLUME,
KINETIC_ENERGY,
ABSORBED_ENERGY,
ABSORBED_ENERGY2;
long double STD_DEV;
unsigned  int NEVENT ;
G4int ORGANE_ID;
}InterDosiData;

private:
G4double x;
G4double y;
G4double z;
int Total_Events,Total_Events_To_Be_Processed,NumberOfThreads;

G4String NameOfPhantomPhysicalVolume;
G4String DOSIMETRIC_DATA_FileName;

G4ThreeVector HalfSize;
G4ThreeVector pos;
G4double HalfVoxelDimensionAlongX, HalfVoxelDimensionAlongY, HalfVoxelDimensionAlongZ;
G4int NumberTotalEvents, NumberOfVoxelsAlongX, NumberOfVoxelsAlongY, NumberOfVoxelsAlongZ;
G4double VoxelMass, density, VoxelVolume;
DetectorConstruction* pDetectorConstruction;  
G4ThreadLocal  static int INCREMENTOR;
G4double BODY_MASSE=0;
G4double ORGANE_MASSE=0;
G4double TOTAL_EMITTED_ENERGY_FROM_SOURCE_ORGANE=0;
InterDosiData *_InterDosiData;
G4float SAF,PHOT_COUNT,CMPT_COUNT,TOTAL_EMITTED_ENERGY_FROM_SOURCE_AND_RECEIVED_BY_TARGET,ABSORBED_ENERGY,OrganTotalVoxelizedVolume;
G4int NEVENT;
G4RunManager* runManager;
float cpu_time;
};
#endif
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
