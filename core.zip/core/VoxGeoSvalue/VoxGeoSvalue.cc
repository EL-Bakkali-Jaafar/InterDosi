/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h> 
#include <iterator>
#include <sstream>
#include <vector>
#include <iostream>
#include <string>
#include <iostream>
#include <set>
#include <math.h> 
#include <algorithm>
#include <ctime>
using std::set;
using std::cout;
using std::endl;
using namespace std;
const double Gy_per_Bq_per_s_To_mGy_per_MBq_per_s=1000000000.0;//10**9
const double MeV_to_eV=1000000.000;
const double eV_to_Joule = 1.602e-19;
bool file_exist;
double yield, energy ;
int Iterator=0,Number_Of_Elements=0;
string output_file_name, dosimetric_file_name;
vector<double> array_svalues,array_svalues_err,array_cputime;
string  s,line,inputfile,rad_config_file,source_organ,physics_skip_interdosi,radioisotope,Simplificated="";
std::vector<string> organ_region_names,array_configurations_safs_for_svalues,array_configurations_rad;
/*-------------------------------------------------------------------------------------*/
void Message(std::string text1, std::string text2, std::string text3)
{
cout<<text1<<text2<<text3<<endl;
}
/*-------------------------------------------------------------------------------------*/
void WriteSvalueFile(int & nevents, int & nthreads,string & radioisotope,string & source_organ,string & physics_list)
{
std::ofstream  SvalueFile;
double total_cpu_time=0.0;
time_t theTime= time(NULL);
struct std::tm* aTime = localtime(&theTime);
for (int index=0; index< array_cputime.size(); index++) { total_cpu_time +=array_cputime[index];     }
SvalueFile.open( output_file_name,std::ios::out );
SvalueFile    <<"CREATION DATE " << '\t' << asctime(aTime) <<"CPU  TIME (S) " <<'\t' << total_cpu_time <<endl;
SvalueFile    <<"NUMBER_THREADS " << '\t' << nthreads <<endl;
SvalueFile    <<"NUMBER_EVENTS " << '\t' << nevents <<endl;
SvalueFile    <<"RADIOISOTOPE " << '\t' << radioisotope <<endl;
SvalueFile    <<"SOURCE_NAME " << '\t' << source_organ <<endl;
SvalueFile    <<"PHYSICS_LIST " << '\t' << physics_list <<endl;
SvalueFile      <<"Organ/Region Name" <<'\t' << "S-Value(mGy/MBq/s)"<<'\t' <<" STD(mGy/MBq/s)" <<endl;
for (int j=0; j < organ_region_names.size(); j++){SvalueFile<<organ_region_names[j] <<'\t'<<Gy_per_Bq_per_s_To_mGy_per_MBq_per_s*array_svalues[j] << '\t' <<  Gy_per_Bq_per_s_To_mGy_per_MBq_per_s*sqrt(array_svalues_err[j])<< endl;}
SvalueFile.close();
}
/*-------------------------------------------------------------------------------------*/
void split(const std::string &s, char delim, std::vector<std::string> &elems) 
{
std::stringstream ss;
ss.str(s);
std::string item;
while (std::getline(ss, item, delim)) 
{
elems.push_back(item);
}
}
/*-------------------------------------------------------------------------------------*/
void ReadData()
{
int i=0;
std::ifstream infile_saf;
infile_saf.open(dosimetric_file_name.c_str() );
bool file_exist = infile_saf.good();
if (file_exist==false) 
{  
Message("===VoxGeoSvalue    The file named: ",dosimetric_file_name.c_str()," does not exist ");
Message("===VoxGeoSvalue    The Extractor was crached.","","");
exit(0);  
}
std::string line;
vector<double> saf_values;
while (std::getline(infile_saf, line)) 
{
i++;
if (i > 8)
{
vector<string> row_values;
split(line, '\t', row_values);
if (Iterator==0) {
organ_region_names.push_back(row_values[0]); }
double saf=stod(row_values[2]);
double err_saf=stod(row_values[3]);
double energy_joule= energy*eV_to_Joule;
saf_values.push_back(saf);
array_svalues_err[i-9]+=pow(yield*err_saf*energy_joule,2);
array_svalues[i-9]+= yield*energy_joule*saf;
}
}
Iterator=1;
infile_saf.close();
}
/*-------------------------------------------------------------------------------------*/
void ReadCPUTime(int & nevents, int & nthreads)
{
int i=0;
std::ifstream infile_cpu;
infile_cpu.open(dosimetric_file_name.c_str() );
std::string line;
while (std::getline(infile_cpu, line)) 
{
i++;
if (i ==2)
{
vector<string> row_values;
split(line, '\t', row_values);
double _cputime=stod(row_values[1]);
array_cputime.push_back(_cputime);
nevents=stoi(row_values[1]);
}
if (i ==5)
{
vector<string> row_values;
split(line, '\t', row_values);
nthreads=stoi(row_values[1]);
}

if (i ==7)
{
vector<string> row_values;
split(line, '\t', row_values);
nevents=stoi(row_values[1]);
}

}
infile_cpu.close();
}
/*-------------------------------------------------------------------------------------*/
int main(int argc,char** argv) 
{
Message("===InterDosi Calling VoxGeoSvalue tool.","","");
ifstream inradFile;
int nevents=0, nthreads=0;
inputfile               =  argv[1] ;
string      part_type="";
vector<string> row_values;
split(inputfile, '-', row_values);
radioisotope                     = row_values[4]+"-"+row_values[5];
source_organ                     =  row_values[0] ;
physics_skip_interdosi = row_values[1]+"-"+row_values[2]+"-"+row_values[3];
string  physics_list= row_values[1];
Number_Of_Elements  =  stoi( row_values[6]) ;
if (row_values.size() >7) Simplificated=row_values[7];
if (row_values.size() >8) part_type=row_values[8];
rad_config_file               = radioisotope+"_"+Simplificated+"_"+part_type  +".rad";
Message("===VoxGeoSvalue extracting S-values .....","","");
inradFile.open(rad_config_file.c_str() );
file_exist = inradFile.good();
if (file_exist==false) {  
Message("======VoxGeoSvalue    The file named  ",rad_config_file.c_str(),"  does not exist !");
Message("===VoxGeoSvalue    The Extractor was crached.","","");
exit(0); 
 }
for (int l=0; l < Number_Of_Elements; l++) {array_svalues.push_back(0.0);array_svalues_err.push_back(0.0);}
while (getline(inradFile,line))
{
vector<string> row_values;
array_configurations_rad.push_back(s);
split(line, ',', row_values);
yield = stod(row_values[1]);
energy =MeV_to_eV*stod(row_values[2]);
 dosimetric_file_name= source_organ+"-"+row_values[2]+"-"+row_values[0]+"-"+physics_skip_interdosi+".saf";
Message("===VoxGeoSvalue Reading the SAF file callled: ",dosimetric_file_name,"");
ReadData();
Message("===VoxGeoSvalue Reading of ",dosimetric_file_name, " was done successfully.");
ReadCPUTime(nevents, nthreads);}
 output_file_name=source_organ+"-"+radioisotope+"-"+physics_skip_interdosi+"-"+Simplificated
+"-"+part_type+".svalue";
WriteSvalueFile(nevents,nthreads,radioisotope,source_organ,physics_list);
Message("===VoxGeoSvalue The file named:  " ,output_file_name ," has been successfully created.");
Message("===VoxGeoSvalue Goodbye !","","");
inradFile.close();
//renitialze value
file_exist=false;
yield=0.0;
energy=0.0 ;
Iterator=0;
Number_Of_Elements=0;
output_file_name="";
dosimetric_file_name="";
array_svalues.clear();
array_svalues_err.clear();
array_cputime.clear();
s="";
line="";
inputfile="";
rad_config_file="";
source_organ="";
physics_skip_interdosi="";
radioisotope="";
organ_region_names.clear();
array_configurations_safs_for_svalues.clear();
array_configurations_rad.clear();
return 0;
}
/*-------------------------------------------------------------------------------------*/
