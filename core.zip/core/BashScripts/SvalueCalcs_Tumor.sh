#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
ulimit unlimited
g4InterDosi_installation=$1
geant4_installation=$2
VoxelizedPhantomName=$3
RadioIsotopeName=$4
SourceOrRegionName=$5
echo $RadioIsotopeName
source $geant4_installation/bin/geant4.sh
cd $g4InterDosi_installation
cd bin
cd G4TumorSvauleCalcs.bin
./start_tumor_svalue_calculations.sh
exit
