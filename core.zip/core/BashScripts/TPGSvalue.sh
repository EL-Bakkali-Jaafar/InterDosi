#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
number_of_cores=$(nproc)
InterDosi_installation=$1
geant4_installation=$2
cmake_installation=$3
tumor_name=$4
source $geant4_installation/bin/geant4.sh
mkdir -p $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name
cd $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name
mkdir -p SAFs
mkdir -p Svalues
mkdir -p SimFiles
cd $InterDosi_installation/bin/PriGeoTumorSAFs.bin/
./PGTSAFs  TumorPG.mac
./PriGeoTumorSvalue $tumor_name
mv  *.saf $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SAFs/ 2>/dev/null
mv  *.svalue $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/Svalues/ 2>/dev/null
mv  *.mac $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.spc $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.rad $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.alpha $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.electron $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.gamma $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.positron $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
mv  *.neutron $InterDosi_installation/outputs/TPGOutputFiles/$tumor_name/SimFiles  2>/dev/null
exit
