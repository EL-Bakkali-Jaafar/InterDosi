#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
number_of_cores=$(nproc)
g4InterDosi_installation=$1
geant4_installation=$2
cmake_installation=$3
tumor_name=$4
source $geant4_installation/bin/geant4.sh
mkdir -p $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name
cd $g4InterDosi_installation/bin/PriGeoTumorSAFs.bin/
./PGTSAFs  TumorPG.mac
./OptNEvents
./PGTSAFs  TumorPG.mac
./PriGeoTumorSvalue $tumor_name
mv  *.saf $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name 2>/dev/null
mv  *.svalue $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name 2>/dev/null
mv  *.mac $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.spc $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.rad $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.alpha $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.electron $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.gamma $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.positron $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
mv  *.neutron $g4InterDosi_installation/outputs/TPGOutputFiles/$tumor_name  2>/dev/null
exit
