#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
number_of_cores=$(nproc)
InterDosi_installation=$1
geant4_installation=$2
cmake_installation=$3
hdf5_installation=$4
export HDF5_ROOT=$hdf5_installation
source $geant4_installation/bin/geant4.sh
cd $InterDosi_installation/bin
rm -R *  2>/dev/null
# .......................................VoxGeoSAFs TOOL...................................
mkdir -p VoxGeoSAFs.bin
cd VoxGeoSAFs.bin
$cmake_installation/cmake  -DCMAKE_BUILD_TYPE=Debug -DGeant4_DIR=$geant4_installation $InterDosi_installation/core/VoxGeoSAFs
make -j$number_of_cores
# .......................................VoxGeoSAFs TOOL......................................

# .......................................VoxGeoSvalue TOOL...................................
cd $InterDosi_installation/bin
mkdir -p VoxGeoSvalue.bin
cd VoxGeoSvalue.bin
$cmake_installation/cmake -DCMAKE_BUILD_TYPE=Debug $InterDosi_installation/core/VoxGeoSvalue
make -j$number_of_cores
cp -v ./VoxGeoSvalue  $InterDosi_installation/bin/VoxGeoSAFs.bin/
# .......................................VoxGeoSvalue TOOL...................................

# .......................................DoseVoxMerger TOOL...................................
cd $InterDosi_installation/bin
mkdir -p DoseVoxMerger.bin
cd  DoseVoxMerger.bin
$cmake_installation/cmake -DCMAKE_BUILD_TYPE=Debug $InterDosi_installation/core/DoseVoxMerger
make -j$number_of_cores
cp -v ./DoseVoxMerger  $InterDosi_installation/bin/VoxGeoSAFs.bin/
# .......................................DoseVoxMerger TOOL...................................


# .......................................DoseOrgMerger TOOL...................................
cd $InterDosi_installation/bin
mkdir -p DoseOrgMerger.bin
cd DoseOrgMerger.bin
$cmake_installation/cmake -DCMAKE_BUILD_TYPE=Debug $InterDosi_installation/core/DoseOrgMerger
make -j$number_of_cores
cp -v ./DoseOrgMerger  $InterDosi_installation/bin/VoxGeoSAFs.bin/
# .......................................DoseOrgMerger TOOL...................................


# .......................................PRIGEOTUMORSAFS TOOL...................................
cd $InterDosi_installation/bin
mkdir -p PriGeoTumorSAFs.bin
cd PriGeoTumorSAFs.bin
$cmake_installation/cmake -DCMAKE_BUILD_TYPE=Debug $InterDosi_installation/core/PriGeoTumorSAFs
make -j$number_of_cores

# .......................................PRIGEOTUMORSAFS TOOL...................................


# .......................................PriGeoTumorSvalue TOOL...................................
cd $InterDosi_installation/bin
mkdir -p PriGeoTumorSvalue.bin
cd PriGeoTumorSvalue.bin
$cmake_installation/cmake -DCMAKE_BUILD_TYPE=Debug $InterDosi_installation/core/PriGeoTumorSvalue
make -j$number_of_cores
cp -v ./PriGeoTumorSvalue  $InterDosi_installation/bin/PriGeoTumorSAFs.bin/
# .......................................PriGeoTumorSvalue TOOL...................................
# .......................................OPTNEVENTS TOOL...................................
cd $InterDosi_installation/bin
mkdir -p OptNEvents.bin
cd OptNEvents.bin
$cmake_installation/cmake -DCMAKE_BUILD_TYPE=Debug $InterDosi_installation/core/OptNEvents
make -j$number_of_cores
cp -v ./OptNEvents  $InterDosi_installation/bin/PriGeoTumorSAFs.bin/

# .......................................OPTNEVENTS TOOL...................................





exit
