#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in primitive and voxelized phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics
#Associate member to the Radiations and Nuclear Systems Laboratory, University
#Abdelmalek Essaadi, Faculty of Sciences of Tetuan, Morocco
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#08/12/2020: public version 1.0
#27/08/2023: last public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#

ulimit unlimited
InterDosi_installation=$1
geant4_installation=$2
organ_source_name=$3
source $geant4_installation/bin/geant4.sh
cd $InterDosi_installation
cd bin
cd VoxGeoSAFs.bin
 ./VoxGeoSAFs
mv  *.irvox $InterDosi_installation/inputs/IRVOXPhantom_files  2>/dev/null
mv  *.irvox_info $InterDosi_installation/inputs/IRVOXPhantom_files  2>/dev/null
exit