#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
ulimit unlimited
InterDosi_installation=$1
geant4_installation=$2
VoxelizedPhantomName=$3
RadioIsotopeName=$4
SourceOrRegionName=$5
echo $RadioIsotopeName
source $geant4_installation/bin/geant4.sh
cd $InterDosi_installation/bin/VoxGeoSAFs.bin
./start_svalue_calculations.sh
cd $InterDosi_installation/outputs/DosiFiles/Svalues
svalue_dir=$(pwd)
mkdir -p $VoxelizedPhantomName
cd $InterDosi_installation/outputs/DosiFiles/SAFs
saf_dir=$(pwd)
mkdir -p $VoxelizedPhantomName
cd $VoxelizedPhantomName
cd $InterDosi_installation/bin/VoxGeoSAFs.bin
mv  *.svalue $svalue_dir/$VoxelizedPhantomName
mv  *.saf $saf_dir/$VoxelizedPhantomName  2>/dev/null
mv  *.dvox $InterDosi_installation/outputs/DvoxFiles/$VoxelizedPhantomNam 2>/dev/null
mv  *.phinfo $InterDosi_installation/outputs/PhinfoFiles/$VoxelizedPhantomNam 2>/dev/null
mv  *.mac $InterDosi_installation/outputs/SAFMacroFiles/$VoxelizedPhantomName 2>/dev/null
rm  *.svalue 2>/dev/null
rm  *.saf 2>/dev/null
exit
