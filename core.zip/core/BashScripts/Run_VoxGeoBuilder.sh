#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
number_of_cores=$(nproc)
geant4_installation=$2
g4InterDosi_installation=$1
gdml_project_full_path=$3
source $geant4_installation/bin/geant4.sh
cd $g4InterDosi_installation/bin
mkdir -p VoxGeoBuilder.bin
cd VoxGeoBuilder.bin
cp   $gdml_project_full_path/*.gdml  ./
./VoxGeoBuilder run.mac
cp *.ijkid $g4InterDosi_installation/inputs/IJKIDPhantom_files/
cp *.info $g4InterDosi_installation/inputs/IJKIDPhantom_files/
exit
