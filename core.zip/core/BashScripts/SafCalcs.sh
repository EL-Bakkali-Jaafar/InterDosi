#!/bin/bash 
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
#InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized  and primitive phantoms.
#Author: Pr. Jaafar EL Bakkali, Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco.
#E-mail: jaafar.elbakkali.pro@gmail.com
#For documentation see :https://github.com/EL-Bakkali-Jaafar/InterDosi
#01/09/2023: current public version 1.3
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
ulimit unlimited
InterDosi_installation=$1
geant4_installation=$2
VoxelizedPhantomName=$3
SourceOrRegionName=$4
source $geant4_installation/bin/geant4.sh
cd $InterDosi_installation/bin/VoxGeoSAFs.bin
./start_calculations.sh
cd $InterDosi_installation/outputs/DosiFiles/SAFs
mkdir -p $VoxelizedPhantomName
cd $VoxelizedPhantomName
cd $InterDosi_installation/bin/VoxGeoSAFs.bin
mv  *.saf $InterDosi_installation/outputs/DosiFiles/SAFs/$VoxelizedPhantomName 2>/dev/null
mkdir -p $InterDosi_installation/outputs/DvoxFiles/$VoxelizedPhantomName
mkdir -p $InterDosi_installation/outputs/SAFMacroFiles/$VoxelizedPhantomName
mv  *.dvox $InterDosi_installation/outputs/DvoxFiles/$VoxelizedPhantomName  2>/dev/null
mv  *.phinfo $InterDosi_installation/outputs/PhinfoFiles/$VoxelizedPhantomName 2>/dev/null
mv  *.mac $InterDosi_installation/outputs/SAFMacroFiles/$VoxelizedPhantomName  2>/dev/null
rm  *.saf 2>/dev/null
exit
