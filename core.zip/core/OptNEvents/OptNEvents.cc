/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h> 
#include <iterator>
#include <sstream>
#include <vector>
#include <iostream>
#include <string>
#include <iostream>
#include <set>
#include <math.h> 
#include <algorithm>
#include <ctime>
using std::set;
using std::cout;
using std::endl;
using namespace std;
/*-------------------------------------------------------------------------------------*/
void Message(std::string text1)
{
cout<<text1<<endl;
}
/*-------------------------------------------------------------------------------------*/
void split(const std::string &s, char delim, std::vector<std::string> &elems) 
{
std::stringstream ss;
ss.str(s);
std::string item;
while (std::getline(ss, item, delim)) 
{
elems.push_back(item);
}
}
/*-------------------------------------------------------------------------------------*/
int GoodEvent (std::string saffile)
{
int _goodEvent=0;
ifstream inFile;
inFile.open(saffile.c_str() );
bool file_exist = inFile.good();
string line;
int i=0;
if (file_exist==false) {  
Message("====InterDosi OptNEvents tool  The file named  "+saffile +"  does not exist !");
Message("===InterDosi OptNEvents tool  was crached.");
exit(0); 
 }
while (std::getline(inFile, line)) 
{
i++;
if (i==2) {
vector<string> row_values;
split(line, ' ;', row_values);
_goodEvent =stoi( row_values[6]);
if ( _goodEvent > 50000000) { _goodEvent=50000000;}
if ( _goodEvent < 10000) { _goodEvent=10000;}

}
}
inFile.close();
return _goodEvent;
}
/*-------------------------------------------------------------------------------------*/
int ThreadNumber (vector<string>& ContentArray){
string key2="/run/numberOfThreads";
int _nthread=0;
for ( int i=0; i < ContentArray.size(); i++)
{
if (ContentArray[i].find(key2) != std::string::npos) {
vector<string> row_values;
split(ContentArray[i], ' ', row_values);
_nthread=stoi(row_values[1]);
break;
}
}
return _nthread;
}
/*-------------------------------------------------------------------------------------*/
void PrintData(vector<string>& ContentArray ) {
 ofstream myfile;
Message("===OptNEvents  open existing TumorPG.mac file.");
  myfile.open ("TumorPG.mac");
for (int k=0; k < ContentArray.size(); k++) myfile << ContentArray [k]<< endl;
  myfile.close();
}
/*---------------------------------------------------*/
void fillData(vector<string>& ContentArray ) {
string inputfile               =  "./TumorPG.mac" ;
ifstream inFile;
inFile.open(inputfile.c_str() );
std::string line1, line;
while (std::getline(inFile, line)) 
{
ContentArray.push_back(line);
}
}
/*-------------------------------------------------------------------------------------*/
int main(int argc,char** argv) 
{
vector<string> ContentArray;
Message("==InterDosi strating OptNEvents tool.");
string key1="/InterDosi/TPGMacroFileName";
string key3="/run/eventModulo";
string key4="/run/beamOn";
string inputfile               =  "./TumorPG.mac" ;
ifstream inFile;
inFile.open(inputfile.c_str() );
bool file_exist = inFile.good();
std::string line1, line;
if (file_exist==false) {  
Message("===OptNEvents tool  The file named  TumorPG.mac  does not exist !");
Message("===OptNEvents tool  was crached.");
exit(0); 
 }
int j=-1;
fillData(ContentArray);
int nthread = ThreadNumber(ContentArray);
while (std::getline(inFile, line)) 
{
j++;
if (line.find(key1) != std::string::npos) {
vector<string> row_values;
split(line, ' ', row_values);
string saf_filename=  row_values[1]+".saf";
int goodevents= GoodEvent (saf_filename);
int nevents_perthread = int (goodevents/(double)nthread);
int tot_events = nthread*nevents_perthread;
for (int l=j; l< ContentArray.size(); l++)
{
if (ContentArray[l].find(key3) != std::string::npos) {
vector<string> row_values;
split(ContentArray[l], ' ', row_values);
string new_value_eventmodulo=key3+" " +to_string(nevents_perthread);
string new_value_beamon=key4+" " +to_string(tot_events);
ContentArray[l] =new_value_eventmodulo;
ContentArray[l+1] =new_value_beamon;
break;
}
}
}
}
PrintData(ContentArray);
Message("===OptNEvents TumorPG.mac file has been rewritten!");
return 0;
}
/*-------------------------------------------------------------------------------------*/
