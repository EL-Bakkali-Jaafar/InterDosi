/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <sstream>
#include <string>
#include <stdio.h> 
#include <iterator>
#include <vector>
#include "G4PVReplica.hh"
#include "G4tgbGeometryDumper.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
#include "DetectorMessenger.hh"
#include "G4TransportationManager.hh"
#include "G4UserLimits.hh"
#include "G4tgrMessenger.hh"
#include "G4LogicalVolumeStore.hh"
#include <iostream>        
#include <cstddef>  
#include "G4VisAttributes.hh"       
using namespace std;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::DetectorConstruction(): G4VUserDetectorConstruction()
{
pDetectorMessenger= new DetectorMessenger(this); 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::~DetectorConstruction()
{ 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction:: GetWorldDimensions( ){
G4Box* myWorldBox     = dynamic_cast<G4Box*> (this->physWorld->GetLogicalVolume()->GetSolid());
G4VisAttributes * _attribut=  new G4VisAttributes(   G4Colour(255/255.,10/255.,10/255.)); 
this->physWorld->GetLogicalVolume() ->SetVisAttributes(_attribut);   
cout << myWorldBox->GetXHalfLength()<< endl;
this->WorldDimensionX = 2*myWorldBox->GetXHalfLength();
this->WorldDimensionY = 2*myWorldBox->GetYHalfLength();
this->WorldDimensionZ = 2*myWorldBox->GetZHalfLength();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4VPhysicalVolume* DetectorConstruction::Construct()
{  
Construct_IJKID_Phantom(this->physWorld); 
return this->physWorld;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfVoxelsAlongZ(int _NumberOfVoxelsAlongZ)
{
this ->NumberOfVoxelsAlongZ=_NumberOfVoxelsAlongZ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfVoxelsAlongY(int _NumberOfVoxelsAlongY)
{
this ->NumberOfVoxelsAlongY=_NumberOfVoxelsAlongY;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfVoxelsAlongX(int _NumberOfVoxelsAlongX)
{
this ->NumberOfVoxelsAlongX=_NumberOfVoxelsAlongX;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction:: SetGDMLFilePath(std::string _GDMLFilePath)
{
 this -> gdml_Phantom_File = _GDMLFilePath;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::Construct_IJKID_Phantom( G4VPhysicalVolume* fWorldPhysVol) 
{
fParser.SetOverlapCheck(false);
fParser.Read(this -> gdml_Phantom_File,false);
const G4LogicalVolumeStore* lvs = G4LogicalVolumeStore::GetInstance();
std::vector<G4LogicalVolume*>::const_iterator lvciter;
this -> dim = 0;
int i=-1;
for( lvciter = lvs->begin(); lvciter != lvs->end(); lvciter++ )
{ 
dim++;
}

_ORGANDATA = new  ORGANDATA[ this ->dim];
for( lvciter = lvs->begin(); lvciter != lvs->end(); lvciter++ )
{
_ORGANDATA[i+1].ORGAN_ID=  i;
_ORGANDATA[i+1].ORGAN_NAME= (*lvciter)->GetName();
i++;
}
this->physWorld = fParser.GetWorldVolume(); 
GetWorldDimensions( );
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
