/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "PrimaryGeneratorAction.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4RunManager.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4Navigator.hh"
#include "G4TransportationManager.hh"
#include "G4ThreeVector.hh"
#include <iostream>
#include <math.h>
#include <fstream>
#include "G4EventManager.hh"
#include "DetectorConstruction.hh"
using namespace std;
G4ThreadLocal int INCR_NUMBER_OF_POINTS_IN_CURRENT_ORGANE =0;
G4ThreadLocal unsigned int max_points=0;
const unsigned long infinity=1000000000000000;
const unsigned int NUMBER_OF_POINTS_PER_CM3_UNIT=15000000;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::PrimaryGeneratorAction()
: G4VUserPrimaryGeneratorAction(),fParticleGun(0)
{
G4int n_particle = 1;
fParticleGun  = new G4ParticleGun(n_particle);
G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
G4String particleName;
G4ParticleDefinition* particle
= particleTable->FindParticle(particleName="gamma");
fParticleGun->SetParticleDefinition(particle);
fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0.,0.,1.));
fParticleGun->SetParticleEnergy(1.*MeV);
this->runManager = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(this->runManager->GetUserDetectorConstruction()); 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::BuildVoxelizedPhantomIJKID()
{//1
list<string> OrganList;
std::ofstream  TextFile;
TextFile.open(this->pDetectorConstruction->VoxelizedPhantomName+".ijkid",  std::ios::out | std::ios::app );
G4Navigator* aNavigator = G4TransportationManager::GetTransportationManager()->GetNavigatorForTracking();
G4double phantomx_dim= this->pDetectorConstruction-> WorldDimensionX ;
G4double phantomy_dim=this->pDetectorConstruction-> WorldDimensionY  ;
G4double phantomz_dim= this->pDetectorConstruction-> WorldDimensionZ ;
G4double HalfVoxelDimensionAlongX=0.5*( phantomx_dim/(double) this->pDetectorConstruction->NumberOfVoxelsAlongX);
G4double HalfVoxelDimensionAlongY=0.5*( phantomy_dim/(double)  this->pDetectorConstruction->NumberOfVoxelsAlongY);
G4double HalfVoxelDimensionAlongZ=0.5*( phantomz_dim/ (double) this->pDetectorConstruction->NumberOfVoxelsAlongZ);
int ix,iy,iz,orang_id=0;
 cout << "===InterDosi    Phantom X Dimension (mm): " << phantomx_dim << endl;
 cout << "===InterDosi    Phantom Y Dimension (mm): " << phantomy_dim << endl;
 cout << "===InterDosi    Phantom Z Dimension (mm): " << phantomz_dim << endl;
 cout << "===InterDosi    Number Of Voxels Along X " << this->pDetectorConstruction->NumberOfVoxelsAlongX << endl;
 cout << "===InterDosi    Number Of Voxels Along Y " << this->pDetectorConstruction->NumberOfVoxelsAlongY << endl;
 cout << "===InterDosi    Number Of Voxels Along Z " << this->pDetectorConstruction->NumberOfVoxelsAlongZ<< endl;  
 cout << "===InterDosi    Voxel X Dimension (mm): " << 2*HalfVoxelDimensionAlongX/mm << endl;
 cout << "===InterDosi    Voxel Y Dimension (mm): " << 2*HalfVoxelDimensionAlongY/mm << endl;
 cout << "===InterDosi    Voxel Z Dimension (mm): " << 2*HalfVoxelDimensionAlongZ/mm << endl;
for(ix=0; ix< this->pDetectorConstruction->NumberOfVoxelsAlongX; ix++){//2
for(iy=0; iy< this->pDetectorConstruction->NumberOfVoxelsAlongY; iy++){//3
for(iz=0; iz< this->pDetectorConstruction->NumberOfVoxelsAlongZ; iz++){//4
G4double x= ( -  this->pDetectorConstruction->NumberOfVoxelsAlongX + 1+ 2*ix )*HalfVoxelDimensionAlongX;
G4double y= ( -  this->pDetectorConstruction->NumberOfVoxelsAlongY+ 1+ 2*iy )* HalfVoxelDimensionAlongY;
G4double z = ( -  this->pDetectorConstruction->NumberOfVoxelsAlongZ+ 1+ 2*iz)*HalfVoxelDimensionAlongZ;
G4VPhysicalVolume* aVolume = aNavigator->LocateGlobalPointAndSetup(G4ThreeVector( x,y,z));
 //

std::string organ_name = aVolume->GetLogicalVolume()->GetName() ;

for (int i=0; i<this->pDetectorConstruction->dim; i++){//5
if (this->pDetectorConstruction->_ORGANDATA[i].ORGAN_NAME==organ_name )
{//

orang_id= this->pDetectorConstruction->_ORGANDATA[i].ORGAN_ID;
if(orang_id!=-1){//7

 OrganList.push_back(to_string(orang_id));
TextFile << ix<< "\t"<< iy << "\t"<<  iz<< "\t"<<orang_id<<endl;
}//7
}//6
}//5
 
}}}// 2 3 4
 
TextFile.close();
std::ofstream  InfoFile;
InfoFile.open(this->pDetectorConstruction->VoxelizedPhantomName+".info", std::ios::out);
InfoFile <<"Phantom dimension along X,Y and Z axis (mm): "<<"\t" <<this->pDetectorConstruction-> WorldDimensionX <<"\t"<<this->pDetectorConstruction-> WorldDimensionY<< "\t"<<this->pDetectorConstruction-> WorldDimensionZ <<G4endl;
InfoFile <<"Number of voxels along X,Y and Z axis : "<<"\t" << this->pDetectorConstruction->NumberOfVoxelsAlongX <<"\t"<< this->pDetectorConstruction->NumberOfVoxelsAlongY<< "\t"<< this->pDetectorConstruction->NumberOfVoxelsAlongZ<<G4endl;
InfoFile <<"Voxel dimensions along X,Y and Z axis (mm): "<<"\t" <<2*HalfVoxelDimensionAlongX <<"\t"<<2*HalfVoxelDimensionAlongY<< "\t"<<2*HalfVoxelDimensionAlongZ<<G4endl;
InfoFile <<"ORGAN_NAME "<<"\t" << "ORGAN_ID "<<G4endl;
for (int i=0; i<this->pDetectorConstruction->dim; i++){ 
InfoFile << this ->pDetectorConstruction->_ORGANDATA[i].ORGAN_NAME<<"\t" <<this ->pDetectorConstruction->_ORGANDATA[i].ORGAN_ID<<G4endl;
}
OrganList.sort();
OrganList.unique();
G4cout <<"Number of organs "<<"\t" << OrganList.size() <<G4endl;
InfoFile.close();
 cout << "===InterDosi    Conversion From GDML To IJKID Has Been Finished."<< endl;
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
BuildVoxelizedPhantomIJKID();
this->runManager->TerminateEventLoop(); 
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

