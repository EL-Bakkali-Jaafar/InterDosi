/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h> 
#include <iterator>
#include <sstream>
#include <vector>
#include <iostream>
#include <string>
#include <iostream>
#include <set>
#include <math.h> 
#include <algorithm>
#include <ctime>
using std::set;
using std::cout;
using std::endl;
using namespace std;
const double Gy_per_Bq_per_s_To_mGy_per_MBq_per_s=1000000000.0;//10**9
const double MeV_to_eV=1000000.000;
const double eV_to_Joule = 1.602e-19;
bool file_exist;
double yield, energy ;
int Iterator=0,Number_Of_Elements=0;
string output_file_name, dosimetric_file_name;
vector<double> array_svalues,array_svalues_err,array_cputime;
string  s,line,inputfile,rad_config_file,source_organ,physics_skip_interdosi,radioisotope,Simplificated="";
std::vector<string> organ_region_names,array_configurations_safs_for_svalues,array_configurations_rad;
/*==============================*/
void Message(std::string text1, std::string text2, std::string text3)
{
cout<<text1<<text2<<text3<<endl;
}
/*==============================*/
void WriteSvalueFile(vector<float> &SvalueData, string svalue_filename,string tumor_radious_str, string tumor_soft_ratio_str, string tumor_bone_ratio_str, float tumor_mass, int histories)
{
std::ofstream  SvalueFile;
double total_cpu_time=0.0;
time_t theTime= time(NULL);
struct std::tm* aTime = localtime(&theTime);
SvalueFile.open( svalue_filename,std::ios::out );
SvalueFile    <<"CREATION DATE " << '\t' << asctime(aTime) <<"CPU  TIME (S) " <<'\t' << SvalueData[2]  <<endl;
SvalueFile    <<"TUMOR_MASS(g) " << '\t' << tumor_mass <<endl;
SvalueFile    <<"EQUIVALENT_SPHERICAL_TUMOR_RADIOUS(mm) " << '\t' << tumor_radious_str <<endl;
SvalueFile    <<"TUMOR_SOFT_BONE_RATIOS" << '\t' << tumor_soft_ratio_str << "--" <<tumor_bone_ratio_str <<endl;
SvalueFile    << "S-Value(Gy/Bq/s)"<<  '\t'<< "S-Value(mGy/MBq/s)"<<'\t' <<" STD(Gy/Bq/s)"<<'\t' <<" STD(mGy/MBq/s)" <<endl;
SvalueFile    <<  SvalueData[0] <<  '\t' <<Gy_per_Bq_per_s_To_mGy_per_MBq_per_s* SvalueData[0]  <<'\t' << SvalueData[1]   <<'\t' << Gy_per_Bq_per_s_To_mGy_per_MBq_per_s*SvalueData[1]   <<endl;
SvalueFile.close();
}
/*==============================*/
void split(const std::string &s, char delim, std::vector<std::string> &elems) 
{
std::stringstream ss;
ss.str(s);
std::string item;
while (std::getline(ss, item, delim)) 
{
elems.push_back(item);
}
}
/*==============================*/
string GetSAFMacroFileName (string tumor_name,string tumor_radious, string tumor_soft_ratio, string tumor_bone_ratio, string energy, string particle_name) {
string result= tumor_name+ "_"+ tumor_radious+ "_"+tumor_soft_ratio+ "_"+ tumor_bone_ratio+ "_"+ energy+ "_"+particle_name;
return result;
}
/*==============================*/
vector<float> GetSAFData (string filename)
{
    int i=-1;
    vector<float> result;
    float saf=0.0, saf_err=0.0,saf_time=0.0,tumor_mass=0.0;
    std::ifstream infile;
    infile.open(filename.c_str() );
    std::string line;
    while (std::getline(infile, line))
    {
    i++;
    if (i==1) {
    vector<string> row_values;
    split(line, ';', row_values);
    saf= stof(row_values[1]);
    saf_err=stof( row_values[2]);
    saf_time= stof(row_values[7]);
    tumor_mass= stof(row_values[8]);
int histories= stof(row_values[5]);
    result.push_back(saf);
    result.push_back(saf_err);
    result.push_back(saf_time);
    result.push_back(tumor_mass);//g
    result.push_back(histories);//g
    }
    }
    infile.close();
    return result;
}
/*==============================*/
vector<float> GetSvalue(vector<float> saf_vector,vector<float> saf_std_vector, vector<float> energy_vector, vector<float> energy_yield_vector,vector<float> saf_time_vector )
{
vector<float> result;
float svalue=0.0, svalue_err=0.0,svalue_time=0.0;
for (int i=0; i< saf_vector.size();i++)
{
float energy_joule= MeV_to_eV*energy_vector[i]*eV_to_Joule;
float saf= saf_vector[i];
float yield=energy_yield_vector[i];
float cpu_time=saf_time_vector[i];
svalue_err+=pow(yield*saf_std_vector[i]*energy_joule,2);
svalue+= yield*energy_joule*saf;

}

for (int i=0; i< saf_time_vector.size();i++) svalue_time+=saf_time_vector[i];
svalue_err=sqrt(svalue_err);
result.push_back(svalue);
result.push_back(svalue_err);
result.push_back(svalue_time);
return   result;
}
/*==============================*/
vector<string> TumorSPC (string file) 
{
    vector<string> result;
    std::ifstream infile;
    infile.open(file.c_str() );
    std::string line;
    while (std::getline(infile, line)) 
    {
    result.push_back (line);
    }
    infile.close();    
    return   result;
}
/*==============================*/

vector<string> RAD_DATA(string file) 
{
vector<string> data;
std::ifstream infile;
infile.open(file.c_str() );
std::string line;
while (std::getline(infile, line)) { data.push_back (line);}
infile.close();  
return data; 
}
/*==============================*/

int numberOfEnergies ( vector<string>  data, int _vec_radionuclide_index) {
int n=0;
for ( int i=_vec_radionuclide_index+1 ; i <data.size(); i++) 
{
vector<string> row_values;
split(data[i], '\t', row_values);
if (row_values.size()>1) {n++;} else {


break;


}

}


return n;



}
/*==============================*/
void GET_ENERGY_YIELD_PARTICLE( 
vector<string>  data,
string _vec_radionuclide_name,
int _vec_radionuclide_index,
int nbrE,
vector<float>& vec_energy,
vector<string>& vec_str_energy,
vector<float> &vec_yield, 
vector<string> &vec_particle
)
{

for ( int i=_vec_radionuclide_index+1 ; i <_vec_radionuclide_index+1+nbrE; i++)  
{
vector<string> row_values;
split(data[i], '\t', row_values);
vec_energy.push_back (stof(row_values[2]));
vec_str_energy.push_back (row_values[2]);
vec_yield.push_back (stof(row_values[1]));
vec_particle.push_back (row_values[0]);


}



      
}
/*==============================*/
void READ_SLCTDRISTPS( string file, vector<string>& _vec_radionuclide_names,vector<int>& _vec_radionuclide_indexes)
{
int i=-1;
std::ifstream infile;
infile.open(file.c_str() );
std::string line;
while (std::getline(infile, line)) 
{
i++;
{
vector<string> row_values;
split(line, '\t', row_values);
if  (row_values.size()==1) { 
_vec_radionuclide_names.push_back (row_values[0]);
_vec_radionuclide_indexes.push_back (i);
}
}
}
infile.close();
}
/*==============================*/
int main(int argc,char** argv) 
{
string  tumor_name               =  argv[1] ;
Message("===InterDosi  #Calling PriGeoTumorSvalue tool.","","");
Message("===PriGeoTumorSvalue  #Tumor name: ",tumor_name,"");
ifstream inradFile;
string SLCTDRISTPS_FILE               =  "SLCTDRISTPS.rad" ;
string TPSG_SPC_FILE                  =  "TPG.spc" ;
vector<string> vec_radionuclide_names;
vector<int> vec_radionuclide_indexes;
 float tumor_mass= 0.0;
int  histories=0;
vector<string> TumorSPCVec= TumorSPC (TPSG_SPC_FILE);

vector<string> rad_data=  RAD_DATA(SLCTDRISTPS_FILE) ;

READ_SLCTDRISTPS( SLCTDRISTPS_FILE,vec_radionuclide_names,vec_radionuclide_indexes);

for (int l=0; l< TumorSPCVec.size(); l++)
{//l
//- First tumor geomaterial
vector<string> row_values;
split(TumorSPCVec[l], '\t', row_values);
string tumor_radious_str=row_values[0];
string tumor_soft_ratio_str=row_values[1];
string tumor_bone_ratio_str=row_values[2];
cout<< "===PriGeoTumorSvalue  #Selected tumor spherical radious (mm): " << tumor_radious_str << endl;
cout<< "===PriGeoTumorSvalue  #Selected tumor soft ratio: " << tumor_soft_ratio_str << endl;
cout<< "===PriGeoTumorSvalue  #Selected tumor bone ratio: " << tumor_bone_ratio_str << endl;




for (int m=0; m < vec_radionuclide_names.size(); m++) 
{//m
//- First radionulcide
string vec_radionuclide_name=vec_radionuclide_names[m];
cout<< "===PriGeoTumorSvalue  #Selected radionuclide: " << vec_radionuclide_name << endl;
int vec_radionuclide_index=vec_radionuclide_indexes[m];
int nn=  numberOfEnergies (rad_data, vec_radionuclide_index);
vector<float> vec_energy;
vector<string> vec_str_energy;
vector<float> vec_yield;
vector<string> vec_particle;
GET_ENERGY_YIELD_PARTICLE( 
rad_data,
vec_radionuclide_name,
vec_radionuclide_index,
nn, 
vec_energy,
vec_str_energy, 
vec_yield, 
vec_particle
);

Message("==================================","","");

vector<float> saf_vector,saf_std_vector, saf_time_vector;


//  get saf  data
for (int j=0; j< vec_energy.size(); j++)
{//1
string part_name=vec_particle[j];
string  energy_str=(vec_str_energy[j]);
if  (part_name=="electron")  part_name="e-";
if  (part_name=="positron")  part_name="e+";
string saf_filename=tumor_name+"_"+tumor_radious_str+"_" +tumor_soft_ratio_str+"_"+tumor_bone_ratio_str+"_"+ energy_str+"_"+part_name+".saf";
std::ifstream infile_saf;
infile_saf.open(saf_filename.c_str() );
bool file_exist = infile_saf.good();
if (file_exist==false) 
{  //2
Message("===PriGeoTumorSvalue    #The Extractor was crached.","","");
Message("===PriGeoTumorSvalue    #The file:",saf_filename," doesnt exist.");
exit(0);  
}//2
vector<float>SAFData =GetSAFData(saf_filename);
float saf= SAFData[0];
float saf_error= SAFData[1];
float saf_cpu_time= SAFData[2];
histories=SAFData[4];
tumor_mass= SAFData[3];
saf_vector.push_back(saf);
saf_std_vector.push_back(saf_error);
if (j==0)    { 
saf_time_vector.push_back(saf_cpu_time);  }
if (vec_energy[j]!=vec_energy[j-1] && j> 0)    { 
saf_time_vector.push_back(saf_cpu_time);  }
}//1
//- Get Svalue
vector<float>SvalueData= GetSvalue( saf_vector, saf_std_vector, vec_energy, vec_yield,saf_time_vector) ;
string svalue_filename= tumor_name+"_"+tumor_radious_str+"_"+tumor_soft_ratio_str+"_"+tumor_bone_ratio_str+"_"+vec_radionuclide_name+".svalue";
WriteSvalueFile(SvalueData,  svalue_filename,tumor_radious_str,tumor_soft_ratio_str, tumor_bone_ratio_str,tumor_mass,histories);
Message("===PriGeoTumorSvalue  #Svalue computing has been finished successfully.","","");
}//m
}//l
return 0;
}
/*==============================*/
