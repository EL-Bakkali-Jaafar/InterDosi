/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef PhantomSD_h
#define PhantomSD_h 1

#include "G4ThreeVector.hh"
#include "G4VSensitiveDetector.hh"
#include "G4VTouchable.hh"
#include <vector>
#include "G4ios.hh"
#include <stdio.h>
#include "G4Threading.hh"
#include <thread>
using namespace std;
class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;
class DetectorConstruction;
class G4RunManager;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
class  PhantomSD : public G4VSensitiveDetector
{
public:
PhantomSD(
G4String name);
~PhantomSD();

G4bool ProcessHits(G4Step*aStep,G4TouchableHistory*);
void EndOfRun();
void BeginOfRun();
void SaveDosimetricDataInTextFile(std::string);
std::string G4PartToPart(std::string g4_particle_name);
string                         StrWithoutDigits(string );
std::string Abrev_ListPhysics(std::string );
std::string Abrev_SourcePartDistType(string ) ;

private:
 G4double ACC_DOSE,ACC_ABE,ACC_ABE2,
ACC_DOSE2;
int NEVENTS,Total_Events_To_Be_Processed;
G4double TOTAL_EMITTED_ENERGY_FROM_SOURCE_ORGANE=0;
G4RunManager* runManager;
DetectorConstruction* pDetectorConstruction;

};
#endif
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
