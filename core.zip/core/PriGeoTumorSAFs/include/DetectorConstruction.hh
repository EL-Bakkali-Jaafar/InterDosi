/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef DetectorConstruction_h
#define DetectorConstruction_h 1

#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
#include <iostream>       
#include <cstddef>  
#include <list>  
#include <map>
class G4VPhysicalVolume;
class DetectorMessenger;
class G4LogicalVolume;
class G4Material;
class PhantomSD;
class G4tgrMessenger;
class G4RunManager;
class G4Colour;
class G4Timer;
class G4Box;
class G4PVPlacement;
class G4Ellipsoid;

using namespace std;

class DetectorConstruction : public G4VUserDetectorConstruction
{
  public:
    DetectorConstruction();
    virtual ~DetectorConstruction();

  virtual G4VPhysicalVolume* Construct();
    G4Material                   * world_mat ;
void                           UpdateGeoMat();
void                           SetPhysicsPackage(G4String);
void                           SetCutForElectron(G4double);
void                           SetCutForGamma(G4double);
void                           SetCutForPositron(G4double);
void                           set_kinetic_energy(G4double);
void                           SetBackgroundID(  int);
void                           set_particle_name(string  ) ;
void                           SetSphericalTumorRadious(G4double);
void                           SetBoneRatio(G4double);
void                           SetTPGMacroFileName(G4String _TPGMacroFileName);
void                           SetSoftRatio(G4double);
void                           SetSourceOrganeName(string  ) ;
void                           SetParticleRecyclingFactor(   int  _ParticleRecyclingFactor);
void                           SetSelectedTumorGeom(G4String  _SelectedTumorGeom);
G4Material*             GetSphericalTumorMaterial(G4double,G4double);
G4LogicalVolume* spherical_tumor_logical;
G4Ellipsoid * ellipsoid_tumor_solid ;
G4Material*             tumMat;
 void                         SetNumberOfThreads(   int  _NumberOfThread);
virtual void              ConstructSDandField();
G4VPhysicalVolume           *  physWorld ;
string                       InterDosiDirectory();
G4String TPGMacroFileName;
G4String  SelectedTumorGeom;
G4double spherical_tumor_radious;
G4double tumor_mass;
string                         OrganeName(const   int  );
G4double                       kinetic_energy, CutForGamma,CutForElectron, CutForPositron ;
PhantomSD*                     mPhantomSD;
static G4ThreadLocal G4bool    fConstructedSDandField;
double soft_ratio, bone_ratio;
int ParticleRecyclingFactor;
int NumberOfThread;
string PhysicsPackage,particle_name,SourceOrganeName,PhantomName;
DetectorMessenger           *  pDetectorMessenger;




};



#endif

