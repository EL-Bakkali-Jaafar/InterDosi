/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "Physics.hh"
#include "globals.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include "G4ParticleDefinition.hh"
#include "G4DecayPhysics.hh"
#include "G4EmStandardPhysics.hh"
#include "G4EmStandardPhysics_option1.hh"
#include "G4EmStandardPhysics_option2.hh"
#include "G4EmStandardPhysics_option3.hh"
#include "G4EmStandardPhysics_option4.hh"
#include "G4EmPenelopePhysics.hh"
#include "G4EmLivermorePhysics.hh"
#include "G4EmExtraPhysics.hh"
#include "G4StoppingPhysics.hh"
#include "G4IonBinaryCascadePhysics.hh"
#include "G4HadronInelasticQBBC.hh"
#include "G4HadronElasticPhysics.hh"
#include "G4IonPhysics.hh"
#include "G4StepLimiter.hh"
#include "G4ProcessManager.hh"
#include "G4EmLowEPPhysics.hh"
#include "PhysicsListMessenger.hh"
#include <stdio.h>
#include "G4RunManager.hh"
#include "DetectorConstruction.hh"
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
Physics::Physics()
{
G4DecayPhysics * myG4DecayPhysics = new G4DecayPhysics(0);
G4IonBinaryCascadePhysics * myG4IonBinaryCascadePhysics= new G4IonBinaryCascadePhysics(0);
G4HadronInelasticQBBC * myG4HadronInelasticQBBC = new G4HadronInelasticQBBC(0);
G4HadronElasticPhysics * myG4HadronElasticPhysics = new G4HadronElasticPhysics(0);
std::cout << " initialization of PhysicsListMessenger." << std::endl;
pMessenger     = new PhysicsListMessenger(this);

RegisterPhysics(myG4IonBinaryCascadePhysics);
RegisterPhysics(myG4HadronInelasticQBBC );
RegisterPhysics(myG4HadronElasticPhysics );
RegisterPhysics(myG4DecayPhysics);
SetCutValue(0.001 *mm , "e-");
SetCutValue(0.001*mm, "e+");
SetCutValue(0.1 *mm, "gamma");

//AddStepMax();
}		 
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
Physics::~Physics() 
{}

/*#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void Physics::SetCutForPositron(G4double _CutForPositron)
{
  SetCutValue(_CutForPositron, "e+");


}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/



/*#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void Physics::RegisterEMPhysics(std::string pacakge)
{
if (pacakge=="G4EmStandardPhysics_option1") { RegisterPhysics( new G4EmStandardPhysics_option1(0) ); }
if (pacakge=="G4EmStandardPhysics_option2") { RegisterPhysics( new G4EmStandardPhysics_option2(0) ); }
if (pacakge=="G4EmStandardPhysics_option3") { RegisterPhysics( new G4EmStandardPhysics_option3(0) ); }
if (pacakge=="G4EmStandardPhysics_option4") { RegisterPhysics( new G4EmStandardPhysics_option4(0) ); }
if (pacakge=="G4EmPenelopePhysics") { RegisterPhysics( new G4EmPenelopePhysics(0) ); }
if (pacakge=="G4EmLivermorePhysics") { RegisterPhysics( new G4EmLivermorePhysics(0) ); }
std::cout << pacakge << " was selected." << std::endl;

G4RunManager* runManager                    = G4RunManager::GetRunManager();
DetectorConstruction* pDetectorConstruction         = (DetectorConstruction*)(runManager->GetUserDetectorConstruction());
pDetectorConstruction ->SetPhysicsPackage( pacakge);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/




void Physics::SetCutForGamma(G4double _CutForGamma)
{
  SetCutValue(_CutForGamma, "gamma");
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void Physics::SetCutForElectron(G4double _CutForElectron)
{
  SetCutValue(_CutForElectron, "e-");
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=*/
void Physics::AddStepMax()
{
auto particleIterator=GetParticleIterator();

particleIterator->reset();
while ((*particleIterator)())
{
G4ParticleDefinition* particle = particleIterator->value();
G4ProcessManager* pmanager = particle->GetProcessManager();
pmanager -> AddProcess(new G4StepLimiter(),  -1,-1,3);
}}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
