/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "G4Event.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4RunManager.hh"
#include "G4SDManager.hh"
#include "G4UnitsTable.hh"
#include "G4ThreeVector.hh"
#include "G4ios.hh"
#include <stdio.h>
#include "PhantomSD.hh"
#include "DetectorConstruction.hh"
#include <vector>
#include "G4SystemOfUnits.hh"
#include "G4Threading.hh"
#include "G4EventManager.hh"
#include "G4Threading.hh"
#include "G4AutoLock.hh"
#include <math.h>
#include <fstream>
#include <math.h>

#include <iostream>
#include "G4Timer.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4PVParameterised.hh"
#include <iomanip>
 using namespace std;
 namespace {G4Mutex _Mutex = G4MUTEX_INITIALIZER;}  



/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD::PhantomSD(G4String name )
: G4VSensitiveDetector(name)
{ 

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string PhantomSD::Abrev_SourcePartDistType(string _val) {
string result="";
if (_val=="Uniform_dist") {result="unidist";}
if (_val=="StndRayleigh_dist") {result="rylghdist";}
if (_val=="EvenVoxIDs_dist") {result="evoxidsdist";}
return result;
}
/*#=#PriGeoTumorSvalues=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string  PhantomSD::G4PartToPart(std::string g4_particle_name) 
{
std::string part=g4_particle_name;
if (g4_particle_name=="e-") { part="electron";}
if (g4_particle_name=="e+") { part="positron";}
return part;
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD::~PhantomSD()
{//1

}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
string PhantomSD::StrWithoutDigits(string source)
{
string target;
for  (char& _char: source) 
{
if (std::isdigit(_char)==false){target+=_char;}
}
return target;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4bool PhantomSD::ProcessHits(G4Step* aStep,G4TouchableHistory*)
{//1
G4double ENERGY_DEPOSIT=0.0 ;
ENERGY_DEPOSIT*=MeV;
ENERGY_DEPOSIT = aStep -> GetTotalEnergyDeposit();
static const G4String det = "spherical_tumor_logical";

if (aStep->GetPreStepPoint()->GetPhysicalVolume()->GetLogicalVolume()->GetName()!=det ) {return false;}
if (ENERGY_DEPOSIT == 0.) {return false;}
else 
{//2
//cout <<  "===>  Scoring Volume "<< aStep->GetPreStepPoint()->GetPhysicalVolume()->GetLogicalVolume()->GetName()  <<  endl;
G4double density=aStep->GetPreStepPoint()->GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetDensity();
G4double r=this->pDetectorConstruction->spherical_tumor_radious;
//cout <<  "===> Spherical Tumor radious (cm)= "<<r /cm<<  endl;
G4double volume = (4.0/3.0)*CLHEP::pi*(r*r*r);
//cout <<  "===> Spherical Tumor volume (mm3)= "<<volume/(mm3)<<  endl;
//cout <<  "===> Spherical Tumor volume (cm3)= "<<volume/(cm3)<<  endl;
//cout <<  "===> Spherical Tumor density (g/cm3)= "<<density/(g/cm3)<<  endl;
G4double spherical_tumor_mass=0.0;
spherical_tumor_mass*=g;
spherical_tumor_mass= density*volume;
//cout <<  "===> Spherical Tumor masse (g)= "<<spherical_tumor_mass/g<<  endl;
G4double spherical_tumor_dose=0.0,spherical_tumor_dose2=0.0;
spherical_tumor_dose*=MeV/g;
ACC_ABE+=ENERGY_DEPOSIT/MeV;
ACC_ABE2+=(ENERGY_DEPOSIT/MeV) *(ENERGY_DEPOSIT/MeV) ;
spherical_tumor_dose= ENERGY_DEPOSIT/spherical_tumor_mass;
spherical_tumor_dose2=  (ENERGY_DEPOSIT/spherical_tumor_mass) * (ENERGY_DEPOSIT/spherical_tumor_mass);
ACC_DOSE+=spherical_tumor_dose / (MeV/g);
ACC_DOSE2+=spherical_tumor_dose2/ ( (MeV/g) * (MeV/g) );
NEVENTS++;
return true;
}//2
}//1


/*#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::SaveDosimetricDataInTextFile(std::string output_file)
{//1
G4ThreadLocal fstream _file;
_file.open(output_file, ios::out );

_file <<ACC_ABE<<";"<< ACC_ABE2<<";" <<ACC_DOSE<<";" << ACC_DOSE2<< ";" << NEVENTS << endl;
_file.close();


}

/*#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string PhantomSD::Abrev_ListPhysics(string _val) {
string result="";
if (_val=="G4EmStandardPhysics_option1") {result="EMSP1";}
if (_val=="G4EmStandardPhysics_option2") {result="EMSP2";}
if (_val=="G4EmStandardPhysics_option3") {result="EMSP3";}
if (_val=="G4EmStandardPhysics_option4") {result="EMSP4";}
if (_val=="G4EmPenelopePhysics"        ) {result="EMPP";}
if (_val=="G4EmLivermorePhysics"       ) {result="EMLVP";}


return result;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/


void PhantomSD::BeginOfRun(){
ACC_DOSE=0.0;
ACC_DOSE2=0.0;
ACC_ABE2=0.0;
ACC_ABE=0.0;
ACC_ABE2=0.0;
NEVENTS=0;
this->runManager = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(this->runManager->GetUserDetectorConstruction()); 
this->Total_Events_To_Be_Processed               = this->runManager ->GetNumberOfEventsToBeProcessed();
;


}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD::EndOfRun(){
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
string file_name= "SphericalTumor_"+str_thread;
if (str_thread!="-1") {SaveDosimetricDataInTextFile (file_name);
ACC_DOSE=0.0;
ACC_DOSE2=0.0;
ACC_ABE2=0.0;
ACC_ABE=0.0;
ACC_ABE2=0.0;
NEVENTS=0;
}
}

