/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "RunAction.hh"
#include <ctime>
#include <fstream>
#include <iostream>
#include "G4ios.hh"
#include <stdio.h>
#include <math.h>
#include "G4RunManager.hh"
#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"
#include "G4Timer.hh"
#include "G4Threading.hh"
#include "PhantomSD.hh"
#include "G4VSensitiveDetector.hh"
#include "G4SDManager.hh"
#include <iomanip>
#include <iostream>
#include <fstream>
#include "G4Threading.hh"
#include "G4AutoLock.hh"
G4Timer                                                  * myTimer;
/**************************************************/
RunAction::RunAction()
: G4UserRunAction()
{ 
if( IsMaster() ) {myTimer                                     = new G4Timer();}
}


/**************************************************/
RunAction::~RunAction()
{}

/**************************************************/
string RunAction::ReadData(string filename) 
{
string str,
result;

ifstream _ReadFile(filename);
while (getline (_ReadFile, str)) {
  result = str;

}
_ReadFile.close(); 

return result;
}
/**************************************************/
void RunAction::BeginOfRunAction(const G4Run*)
{ 
if( IsMaster() )
{ 
myTimer= new G4Timer();
 myTimer->Start();
G4RunManager* runManager= G4RunManager::GetRunManager();
DetectorConstruction*pDetectorConstruction = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
cout << "==== PGTSvalues #Strating the calculation of SAF parameter for the following configuration:" << endl;
cout << "==== PGTSvalues #Particle name:" << pDetectorConstruction->particle_name<< endl;
cout << "==== PGTSvalues #Energy(MeV):" << pDetectorConstruction->kinetic_energy<< endl;
cout << "==== PGTSvalues #Spherical tumor radious(mm):" << pDetectorConstruction->spherical_tumor_radious<< endl;
cout << "==== PGTSvalues #Spherical tumor compositions(soft in %, bone in %):" << pDetectorConstruction->soft_ratio*100 << "," << pDetectorConstruction->bone_ratio *100 << endl;
}
  else  {
G4RunManager* runManager= G4RunManager::GetRunManager();
DetectorConstruction*pDetectorConstruction = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
 G4SDManager* pSDManager = G4SDManager::GetSDMpointerIfExist();
pSDManager->SetVerboseLevel(2);
G4VSensitiveDetector* sd = pSDManager->FindSensitiveDetector("/"+pDetectorConstruction->PhantomName+str_thread,true);
G4ThreadLocal PhantomSD*myPhantomSD = dynamic_cast<PhantomSD*>(sd);
myPhantomSD->BeginOfRun();
}
}
/**************************************************/
void RunAction::split(const std::string &s, char delim, std::vector<std::string> &elems) 
{
std::stringstream ss;
ss.str(s);
std::string item;
while (std::getline(ss, item, delim)) 
{
elems.push_back(item);
}
}
/**************************************************/
void RunAction::EndOfRunAction(const G4Run* )
{
float elapsed_time=0.0;
 if( IsMaster() )
{ 
myTimer->Stop();

cout << "CPU_TIME:" <<myTimer->GetRealElapsed()<<" seconds."<< endl;
elapsed_time=myTimer->GetRealElapsed();
double dose=0.0, dose2=0.0, saf=0.0, af=0.0,acc_absorbed_energy=0.0,acc_absorbed_energy2=0.0;
int nvts=0;
G4double kinetic_energy=0.0;
cout << " the simulation has been finished." << endl;
G4RunManager* runManager= G4RunManager::GetRunManager();
DetectorConstruction*pDetectorConstruction = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
int nevents=runManager->GetNumberOfEventsToBeProcessed() *pDetectorConstruction-> ParticleRecyclingFactor;
kinetic_energy= pDetectorConstruction->kinetic_energy;//MeV
int nthreads=pDetectorConstruction->NumberOfThread;
for ( int i=0; i < nthreads;i++) 
{
string filename= "SphericalTumor_"+to_string(i);
string data= ReadData(filename);
vector<string> row_values;
split(data, ';', row_values);
acc_absorbed_energy+=stof(row_values[0]);
acc_absorbed_energy2+=stof(row_values[1]);
 dose += stof(row_values[2]);
 dose2 += stof(row_values[3]);
 nvts += stoi(row_values[4]);
remove(filename .c_str());
 }
saf= 1000*dose/(nevents)/kinetic_energy;
 af=acc_absorbed_energy /(nevents)/kinetic_energy;
double tumor_masse=af/saf;//Kg
double alpha=1/kinetic_energy/tumor_masse;
double AE_MEAN         = acc_absorbed_energy/nvts;
double AE2_MEAN        = acc_absorbed_energy2/nvts;
double beta = (alpha*alpha*AE2_MEAN)- (AE_MEAN*alpha*alpha*AE_MEAN);
double std=0.0;
double statiscal_error=0.0;
string str_std= to_string(sqrt((beta)/ (nvts-1)));
if  (str_std=="-nan") {cout <<  "============ Error:  -NAN ========" << endl;
std=saf/(sqrt(nevents));
} else  {

std=sqrt((beta)/ (nvts-1));

}
string output_file=pDetectorConstruction->TPGMacroFileName+".saf";
statiscal_error=100*std/saf;


double lambda     = sqrt(nevents)*statiscal_error;
//
int good_nevents= int(sqrt(2.0)*lambda*lambda) ; // to achieve a statistical uncertainly less than 1%.
//int good_nevents= int (sqrt(int(nevents/(double)(statiscal_error*statiscal_error)))) ; // to achieve a statistical uncertainly less than 1%.
 fstream _file;
_file.open(output_file, ios::out );
_file << "AF; SAF(Kg-1); STD (kg-1); STATIC_ERROR(%);NEVENTS_PHANTOM; TOT_SIMULATED_EVENTS; GOOD_EVENTS;SIMULATION_TIME(s);Mass(g)"<<endl;
_file 
<< af
<<";"
<< saf
<<";" 
 <<std
 <<  ";"
<< statiscal_error
 <<";"
<< nvts 
<<";"
<< nevents  
<<";"
<<  good_nevents
 <<";"
 << elapsed_time
<<";"
<< 1000*tumor_masse
<< endl;
_file.close();
}
  else  {
G4RunManager* runManager= G4RunManager::GetRunManager();
DetectorConstruction*pDetectorConstruction = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
cout << "==== PGTSvalues #The simulation has been finished in thread:" << str_thread<< endl;
 G4SDManager* pSDManager = G4SDManager::GetSDMpointerIfExist();
pSDManager->SetVerboseLevel(2);
G4VSensitiveDetector* sd = pSDManager->FindSensitiveDetector("/"+pDetectorConstruction->PhantomName+str_thread,true);
G4ThreadLocal PhantomSD*myPhantomSD = dynamic_cast<PhantomSD*>(sd);
myPhantomSD->EndOfRun();
}
}
