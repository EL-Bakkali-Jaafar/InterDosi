/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorMessenger.hh"
#include "DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
#include <iomanip>
#include "G4Threading.hh"
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::DetectorMessenger(DetectorConstruction* pDetectorConstruction)
: G4UImessenger(),fDetectorConstruction(pDetectorConstruction)
{
 DetectorDir           = new G4UIdirectory("/InterDosi/");
 DetectorDir           -> SetGuidance("............................");
 PrimaryParticleKineticEnergyCmd = new G4UIcmdWithADoubleAndUnit("/InterDosi/PrimaryParticleKineticEnergy",this);  
 PrimaryParticleKineticEnergyCmd->SetGuidance("PrimaryParticleKineticEnergy.");
 PrimaryParticleKineticEnergyCmd->SetParameterName("PrimaryParticleKineticEnergy",false);
 PrimaryParticleKineticEnergyCmd->SetUnitCategory("Energy");
 PrimaryParticleKineticEnergyCmd->SetRange("PrimaryParticleKineticEnergy>0.0");
 PrimaryParticleNameCmd = new G4UIcmdWithAString("/InterDosi/PrimaryParticleName",this);  
 PrimaryParticleNameCmd->SetGuidance("PrimaryParticleName");
 PrimaryParticleNameCmd->SetParameterName("PrimaryParticleName",false);

 NumberOfSameParticle_Cmd = new G4UIcmdWithAnInteger("/InterDosi/ParticleRecyclingFactor",this);  
 NumberOfSameParticle_Cmd->SetGuidance("Set ParticleRecyclingFactor.");
 NumberOfSameParticle_Cmd ->SetParameterName("ParticleRecyclingFactor",false);
 NumberOfSameParticle_Cmd ->SetRange("ParticleRecyclingFactor>=0");
 NumberOfSameParticle_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


 NumberOfThreads_Cmd = new G4UIcmdWithAnInteger("/InterDosi/NumberOfThreads",this);  
 NumberOfThreads_Cmd->SetGuidance("Set  Number Of Threads.");
 NumberOfThreads_Cmd ->SetParameterName("NumberOfThreads",false);
 NumberOfThreads_Cmd ->SetRange("NumberOfThreads>=0");
 NumberOfThreads_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);

 SourceOrganeNameCmd  = new G4UIcmdWithAString("/InterDosi/SourceName",this);
 SourceOrganeNameCmd  ->SetGuidance("");
 SourceOrganeNameCmd  ->SetParameterName("SourceName",false);
 SourceOrganeNameCmd  ->SetDefaultValue("");
 SourceOrganeNameCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 
 PhysicsPackageCmd            = new G4UIcmdWithAString("/InterDosi/PhysicsPackage",this);
 PhysicsPackageCmd            ->SetGuidance("");
 PhysicsPackageCmd            ->SetParameterName("PhysicsPackage",false);
 PhysicsPackageCmd            ->SetDefaultValue("");

 TPGMacroFileNameCmd            = new G4UIcmdWithAString("/InterDosi/TPGMacroFileName",this);
 TPGMacroFileNameCmd            ->SetGuidance("");
 TPGMacroFileNameCmd            ->SetParameterName(" TPGMacroFileName",false);
 TPGMacroFileNameCmd            ->SetDefaultValue("");

SelectedTumorGeomCmd            = new G4UIcmdWithAString("/InterDosi/SelectedTumorGeom",this);
 SelectedTumorGeomCmd            ->SetGuidance("");
 SelectedTumorGeomCmd            ->SetParameterName(" SelectedTumorGeom",false);
SelectedTumorGeomCmd            ->SetDefaultValue("");




 CutForElectronCmd = new G4UIcmdWithADouble("/InterDosi/CutForElectron",this);  
 CutForElectronCmd->SetGuidance("CutForElectron.");
 CutForElectronCmd->SetParameterName("CutForElectron",false);
 CutForElectronCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);

 CutForGammaCmd = new G4UIcmdWithADouble("/InterDosi/CutForGamma",this);  
 CutForGammaCmd->SetGuidance("CutForGamma.");
 CutForGammaCmd->SetParameterName("CutForGamma",false);
 CutForGammaCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


 CutForPositronCmd = new G4UIcmdWithADouble("/InterDosi/CutForPositron",this);  
 CutForPositronCmd->SetGuidance("CutForPositron.");
 CutForPositronCmd->SetParameterName("CutForPositron",false);
 CutForPositronCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


 SoftRatioCmd = new G4UIcmdWithADouble("/InterDosi/SoftRatio",this);  
 SoftRatioCmd->SetGuidance("SoftRatio.");
 SoftRatioCmd->SetParameterName("SoftRatio",false);
 SoftRatioCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);

 BoneRatioCmd = new G4UIcmdWithADouble("/InterDosi/BoneRatio",this);  
 BoneRatioCmd->SetGuidance("BoneRatio.");
 BoneRatioCmd->SetParameterName("BoneRatio",false);
 BoneRatioCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


SphericalTumorRadiousCmd = new G4UIcmdWithADouble("/InterDosi/SphericalTumorRadious",this);  
SphericalTumorRadiousCmd->SetGuidance("SphericalTumorRadious.");
SphericalTumorRadiousCmd->SetParameterName("SphericalTumorRadious",false);
SphericalTumorRadiousCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);



}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::~DetectorMessenger()
{
  delete PrimaryParticleNameCmd;
  delete PrimaryParticleKineticEnergyCmd;
  delete DetectorDir;    
  delete NumberOfSameParticle_Cmd;
  delete SourceOrganeNameCmd;
  delete PhysicsPackageCmd;
  delete CutForPositronCmd;
  delete CutForGammaCmd;
  delete CutForElectronCmd;
  delete SoftRatioCmd;
  delete BoneRatioCmd;
  delete SphericalTumorRadiousCmd;
delete NumberOfThreads_Cmd;
delete TPGMacroFileNameCmd;
delete SelectedTumorGeomCmd;


}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{       
      if(command==NumberOfSameParticle_Cmd ){fDetectorConstruction->SetParticleRecyclingFactor(NumberOfSameParticle_Cmd->GetNewIntValue(newValue));}  
else  if( command == NumberOfThreads_Cmd ){fDetectorConstruction-> SetNumberOfThreads(NumberOfThreads_Cmd->GetNewIntValue(newValue));}  
else  if( command == PrimaryParticleKineticEnergyCmd ){ fDetectorConstruction->set_kinetic_energy(PrimaryParticleKineticEnergyCmd->GetNewDoubleValue(newValue));}
else  if( command == PrimaryParticleNameCmd ){ fDetectorConstruction->set_particle_name(newValue);}
else  if(command==SourceOrganeNameCmd ){fDetectorConstruction->SetSourceOrganeName(newValue);}   
else  if(command==TPGMacroFileNameCmd ){fDetectorConstruction->SetTPGMacroFileName(newValue);}   
else  if(command==SelectedTumorGeomCmd ){fDetectorConstruction->SetSelectedTumorGeom(newValue);}   
else  if(command==CutForPositronCmd ){ fDetectorConstruction->SetCutForPositron(CutForPositronCmd->GetNewDoubleValue(newValue));}
else  if(command==CutForGammaCmd ){ fDetectorConstruction->SetCutForGamma(CutForGammaCmd->GetNewDoubleValue(newValue));}
else  if(command==CutForElectronCmd ){ fDetectorConstruction->SetCutForElectron(CutForElectronCmd->GetNewDoubleValue(newValue));}
else  if(command==SphericalTumorRadiousCmd ){ fDetectorConstruction->SetSphericalTumorRadious(SphericalTumorRadiousCmd->GetNewDoubleValue(newValue));}
else  if(command==BoneRatioCmd ){ fDetectorConstruction->SetBoneRatio(BoneRatioCmd->GetNewDoubleValue(newValue));}
else  if(command==SoftRatioCmd ){ fDetectorConstruction->SetSoftRatio(SoftRatioCmd->GetNewDoubleValue(newValue));}
else  if(command==PhysicsPackageCmd ){fDetectorConstruction->SetPhysicsPackage(newValue);}



}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
