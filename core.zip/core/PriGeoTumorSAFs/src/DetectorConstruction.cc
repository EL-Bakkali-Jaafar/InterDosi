/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#include "PhantomSD.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "DetectorMessenger.hh"
#include "G4SystemOfUnits.hh"
#include "G4RunManager.hh"
#include "G4Box.hh"
#include "G4Sphere.hh"
#include "G4Ellipsoid.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
#include "G4tgbGeometryDumper.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
#include "DetectorMessenger.hh"
#include "G4TransportationManager.hh"
#include "G4tgbVolumeMgr.hh"
#include "G4UserLimits.hh"
#include "G4tgrMessenger.hh"
#include "G4tgbMaterialMgr.hh"
#include "G4LogicalVolumeStore.hh"
#include <iostream>       
#include <cstddef>
#include <unistd.h>
static const double     pi  = 3.14159265358979323846;
DetectorConstruction::DetectorConstruction()
: G4VUserDetectorConstruction()
{ pDetectorMessenger= new DetectorMessenger(this); }



DetectorConstruction::~DetectorConstruction()
{ }



G4VPhysicalVolume* DetectorConstruction::Construct()

{  
cout << "Update geometry " << endl;
this->world_mat = GetSphericalTumorMaterial (1.0,0);
G4double world_sizeXY = 3*m;
G4double world_sizeZ  = 3*m;
G4Box* solidWorld = new G4Box("World",  0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);    
      
  G4LogicalVolume* logicWorld = new G4LogicalVolume(solidWorld, this->world_mat,  "World");           
                                   
 this->physWorld=new G4PVPlacement(0, G4ThreeVector(), logicWorld,  "World", 0, false,0, false);        
  float r = this->spherical_tumor_radious/mm;
 // G4Sphere* spherical_tumor_solid=  new G4Sphere("spherical_tumor_solid",  0.0 * cm, r*mm,  0.0 * deg, 360.0 *deg, 0.0 * deg, 360.0 *deg);

 ellipsoid_tumor_solid ;



cout << "SelectedTumorGeom= "  << this->SelectedTumorGeom<< endl;

if (this->SelectedTumorGeom=="Sphere")

 {     
cout << "Tumor selected geometry: Sphere."  << endl;
  ellipsoid_tumor_solid  = new G4Ellipsoid  ("ellipsoid_tumor_solid",r*mm,r*mm,r*mm);
cout << "R(mm) = "  << r<< endl;

  }

if (this->SelectedTumorGeom=="Abalate_spheroid") 
{    
cout << "Tumor selected geometry: Abalate_spheroid."  << endl;
 float r1 = this->spherical_tumor_radious/mm;
float a,b,c;
a = pow(2.0, 1/3.0)*r1;
b=a;
c=a/2.0;
cout << "a(mm) = "  <<a<< endl;
cout << "b(mm) = "  <<b<< endl;
cout << "c(mm) = "  <<c<< endl;
ellipsoid_tumor_solid  = new G4Ellipsoid  ("ellipsoid_tumor_solid",a*mm,b*mm,c*mm);         

  }

if (this->SelectedTumorGeom=="Prolate_spheroid")
 {     
cout << "Tumor selected geometry: Prolate_spheroid."  << endl;
 float r2 = this->spherical_tumor_radious/mm;
float a,b,c;
a = pow(0.5, 1/3.0)*r2;
b=a;
c=a*2.0;
ellipsoid_tumor_solid  = new G4Ellipsoid  ("ellipsoid_tumor_solid",a*mm,b*mm,c*mm);  
cout << "a(mm) = "  <<a<< endl;
cout << "b(mm) = "  <<b<< endl;
cout << "c(mm) = "  <<c<< endl;
     }

tumMat = GetSphericalTumorMaterial(this->soft_ratio, this->bone_ratio);
 spherical_tumor_logical = new G4LogicalVolume( ellipsoid_tumor_solid,tumMat,  "spherical_tumor_logical",0, 0, 0 );
 new G4PVPlacement( 0,G4ThreeVector(0.0, 0.0, 0.0) ,"spherical_tumor_physical", spherical_tumor_logical,this->physWorld, false, 1); 
                





return this->physWorld;
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_kinetic_energy(G4double _kinetic_energy)
{ 
this->kinetic_energy=_kinetic_energy;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfThreads(   int  _NumberOfThread)
{
this->NumberOfThread=_NumberOfThread;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetParticleRecyclingFactor(   int  _ParticleRecyclingFactor)
{
this->ParticleRecyclingFactor=_ParticleRecyclingFactor;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

G4Material *  DetectorConstruction::GetSphericalTumorMaterial(G4double _soft_ratio, G4double _bone_ratio) 
{
G4double soft_density= 1* g/cm3;
G4double bone_density= 1.92* g/cm3;
int number_of_elements_in_material=14;
// ICRP 110 MALE  bone and soft tissues.
G4double material_density= (_soft_ratio*soft_density)+(_bone_ratio*bone_density);
G4double H_Frac= (_bone_ratio*0.036)+ (_soft_ratio* 0.104472);
G4double C_Frac= (_bone_ratio*0.159)+ (_soft_ratio* 0.23219);
G4double N_Frac= (_bone_ratio*0.042)+ (_soft_ratio* 0.02488);
G4double O_Frac= (_bone_ratio*0.448)+ (_soft_ratio* 0.630238);
G4double Na_Frac= (_bone_ratio*0.003)+ (_soft_ratio* 0.00113);
G4double Mg_Frac= (_bone_ratio*0.002)+ (_soft_ratio* 0.00013);
G4double P_Frac= (_bone_ratio*0.094)+ (_soft_ratio* 0.00133);
G4double S_Frac= (_bone_ratio*0.003)+ (_soft_ratio* 0.00199);
G4double Cl_Frac= (_bone_ratio*0.0)+ (_soft_ratio* 0.00134);
G4double K_Frac= (_bone_ratio*0.0)+ (_soft_ratio* 0.00199);
G4double Ca_Frac= (_bone_ratio*0.213)+ (_soft_ratio* 0.00023);
G4double Fe_Frac= (_bone_ratio*0.0)+ (_soft_ratio* 5e-05);
G4double Zn_Frac= (_bone_ratio*0.0)+ (_soft_ratio* 3e-05);
G4double I_Frac= (_bone_ratio*0.0)+ (_soft_ratio* 0.0);
G4String _MaterialName="soft_"+to_string(_soft_ratio) +"_ bone"+to_string(_bone_ratio);
G4Material * myMaterial = new G4Material(_MaterialName,(material_density/(g/cm3) )*g/cm3,  number_of_elements_in_material );
 tumor_mass = material_density/(g/cm3)*4/3.0*pi*0.1*0.1*0.1*this->spherical_tumor_radious*this->spherical_tumor_radious*this->spherical_tumor_radious;

cout <<"tumor_mass"  <<tumor_mass  << endl;
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("H"),  H_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("C"),  C_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("N"),  N_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("O"),  O_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("Na"),  Na_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("Mg"),  Mg_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("P"),  P_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("S"),  S_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("Cl"),  Cl_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("K"),  K_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("Ca"),  Ca_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("Fe"),  Fe_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("Zn"),  Zn_Frac);
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement("I"),  I_Frac);
return myMaterial ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
//*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetBoneRatio(G4double _bone_ratio) { 
this->bone_ratio=_bone_ratio;
}
//*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetSoftRatio(G4double _soft_ratio) {
this->soft_ratio=_soft_ratio;


}
//*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void DetectorConstruction::SetSphericalTumorRadious(G4double _spherical_tumor_radious) {
this->spherical_tumor_radious=_spherical_tumor_radious;

}
//*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructSDandField()
{

G4ThreadLocal PhantomSD *mSD;
G4SDManager* pSDManager ;
pSDManager = G4SDManager::GetSDMpointer();
pSDManager->SetVerboseLevel(3);
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
mSD = new PhantomSD(this->PhantomName+str_thread);
mSD->SetVerboseLevel(3);
pSDManager-> AddNewDetector(mSD);
SetSensitiveDetector("spherical_tumor_logical",mSD);

}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_particle_name(string  _particle_name) {
this->particle_name = _particle_name;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string DetectorConstruction::InterDosiDirectory()
{
std::string _InterDosiDir="Unresolved";
char buffer[256];
char *val = getcwd(buffer, sizeof(buffer));
if (val) 
{
_InterDosiDir = buffer;

 string toErase= "/bin/G4InterDosi.bin";
size_t pos = _InterDosiDir.find(toErase);
_InterDosiDir.erase(pos, toErase.length());
    std::cout <<"===InterDosi    Current directory: "<< _InterDosiDir << std::endl;
}
return _InterDosiDir;
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::SetSourceOrganeName( string _SourceOrganeName)
{
this->SourceOrganeName=_SourceOrganeName;
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetCutForElectron(G4double _CutForElectron){
this->CutForElectron=_CutForElectron;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetCutForGamma(G4double _CutForGamma){
this->CutForGamma=_CutForGamma;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetCutForPositron(G4double _CutForPositron){
this->CutForPositron=_CutForPositron;
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::UpdateGeoMat()
{
if(spherical_tumor_logical)
{
G4cout << "this->soft_ratio " << this->soft_ratio << G4endl;
G4cout << "this->bone_ratio " << this->bone_ratio << G4endl;
tumMat = GetSphericalTumorMaterial(this->soft_ratio, this->bone_ratio);
spherical_tumor_logical->SetMaterial(tumMat);
float r = this->spherical_tumor_radious/mm;
cout << "SelectedTumorGeom= "  << this->SelectedTumorGeom<< endl;
if (this->SelectedTumorGeom=="Sphere")
{     
cout << "Tumor selected geometry: Sphere."  << endl;
ellipsoid_tumor_solid  = new G4Ellipsoid  ("ellipsoid_tumor_solid",r*mm,r*mm,r*mm);
cout << "R(mm) = "  << r<< endl;
}
if (this->SelectedTumorGeom=="Abalate_spheroid") 
{    
cout << "Tumor selected geometry: Abalate_spheroid."  << endl;
 float r1 = this->spherical_tumor_radious/mm;
float a,b,c;
a = pow(2.0, 1/3.0)*r1;
b=a;
c=a/2.0;
cout << "a(mm) = "  <<a<< endl;
cout << "b(mm) = "  <<b<< endl;
cout << "c(mm) = "  <<c<< endl;
ellipsoid_tumor_solid  = new G4Ellipsoid  ("ellipsoid_tumor_solid",a*mm,b*mm,c*mm);         
}

if (this->SelectedTumorGeom=="Prolate_spheroid")
{     
cout << "Tumor selected geometry: Prolate_spheroid."  << endl;
 float r2 = this->spherical_tumor_radious/mm;
float a,b,c;
a = pow(0.5, 1/3.0)*r2;
b=a;
c=a*2.0;
ellipsoid_tumor_solid  = new G4Ellipsoid  ("ellipsoid_tumor_solid",a*mm,b*mm,c*mm);  
cout << "a(mm) = "  <<a<< endl;
cout << "b(mm) = "  <<b<< endl;
cout << "c(mm) = "  <<c<< endl;
}
spherical_tumor_logical->SetSolid(ellipsoid_tumor_solid);

}
G4RunManager::GetRunManager()->PhysicsHasBeenModified();
//G4cout << "spherical_tumor_logical material set to " << spherical_tumor_logical->GetName() << G4endl;

}


/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetTPGMacroFileName(G4String _TPGMacroFileName){
this->TPGMacroFileName=_TPGMacroFileName;
 UpdateGeoMat();

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetPhysicsPackage(G4String _PhysicsPackage){
this->PhysicsPackage=_PhysicsPackage;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetSelectedTumorGeom(G4String _SelectedTumorGeom){
this->SelectedTumorGeom=_SelectedTumorGeom;
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

