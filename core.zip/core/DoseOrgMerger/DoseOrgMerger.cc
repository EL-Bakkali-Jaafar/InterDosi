/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DoseOrgMerger.hh"
#include <iomanip>
#include <limits>
#include <chrono>
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <ctime>
#include <string>
#include <cstring> 
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
using namespace std;
#ifndef H5_NO_NAMESPACE
#ifndef H5_NO_STD
using std::cout;
using std::endl;
#endif  // H5_NO_STD
#endif
#define  MAX_ORGANE_NAME_LENGTH 10000
#include "H5Cpp.h"
#ifndef H5_NO_NAMESPACE
using namespace H5;
#endif
/*  DECLARATION  OF ELEMENTS OF H5_PHASE_SPACE DATA */
 const std::string 
 DatasetName                 ("InternalDosimetricData"),
 MEMBER_ORGANE_NAME          ("_ORGANE_NAME"          ),
 MEMBER_ORGANE_MATERIAL      ("_ORGANE_MATERIAL"      ),
 MEMBER_ORGANE_MASSE         ("_ORGANE_MASSE"         ),
 MEMBER_ORGANE_VOLUME        ("_ORGANE_VOLUME"        ),
 MEMBER_KINETIC_ENERGY       ("_KINETIC_ENERGY"       ),
 MEMBER_ABSORBED_ENERGY      ("_ABSORBED_ENERGY"      ),
 MEMBER_ABSORBED_ENERGY2     ("_ABSORBED_ENERGY2"     ),
 MEMBER_NEVENT               ("_NEVENT"               ),
 MEMBER_ORGANE_ID            ("_ORGANE_ID"            ),
 MEMBER_ORGANE_NVOXELS       ("_ORGANE_NVOXELS"       ),
 DatasetName_region              ("InternalDosimetricRegionData"),
 MEMBER_REGION_NAME      ("_REGION_NAME"         ),
 MEMBER_REGION_MASSE      ("_REGION_MASSE"         ),
 MEMBER_REGION_VOLUME     ("_REGION_VOLUME"        ),
 MEMBER_REGION_NEVENT            ("_REGION_NEVENT"               ),
 MEMBER_REGION_KINETIC_ENERGY    ("_REGION_KINETIC_ENERGY"       ),
 MEMBER_REGION_ABSORBED_ENERGY   ("_REGION_ABSORBED_ENERGY"      ),
 MEMBER_REGION_ABSORBED_ENERGY2  ("_REGION_ABSORBED_ENERGY2"     ),
 MEMBER_REGION_NVOXELS         ("_REGION_NVOXELS"            );
string               file                             = "",SourcePartDistType,
                     inputfile                        = "" ,
                     PhantomName                      = "" ,
                     NVOXELS_X                        = "" ,
                     NVOXELS_Y                        = "" ,
                     NVOXELS_Z                        = "" ,
                     DIM_X                            = "" ,
                     DIM_Y                            = "" ,
                     DIM_Z                            = "" ,
                     PhantomConfigurationFileFullPath = "" ,
                     str                              = "" ,
                     cputime                          = "" ,
                     PhysicsPackage="", skip_equal_materials_flag="";
int                  NumberOfThread                   = 0  ,
                     i                                = -1 ,
                     NumberOforgans  ,NumberOfregions                      ;
unsigned  int        Total_Events_To_Be_Processed     = 0  ,
                     NumberOfSameParticle             = 0  , 
                     nthread                          = 0  ;
unsigned  long int   Total_Events                          ;
double               kinetic_energy                        ;
InterDosiData *      tmp_InterDosiData                     ;
RegStruc *           tmp_RegStruc                          ;
InterDosiDataMerger *      RAM_InterDosiData                     ;
RegStrucMerger *           RAM_RegStruc                          ;
std::ofstream        SAFS_File                             ;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_TXT()
{
ifstream inFile;
inFile.open(inputfile.c_str() );
while (getline(inFile,str))
{
i++;
if (i==0)     file=str; 
if (i==1)     cputime=str;
if (i==2)     NumberOfThread=stoi(str);
if (i==3)     Total_Events_To_Be_Processed=stoi(str);
if (i==4)     NumberOfSameParticle=stoi(str);
if (i==5)     kinetic_energy=strtof((str).c_str(),0);
if (i==6)     NumberOforgans=stoi(str);
if (i==7)     PhantomName =str ;
if (i==8)     PhantomConfigurationFileFullPath =str ;
if (i==9)     PhysicsPackage =str ;
if (i==10)    NumberOfregions=stoi(str);
if (i==11)    skip_equal_materials_flag=stoi(str);
if (i==12)    NVOXELS_X=str;
if (i==13)    NVOXELS_Y=str;
if (i==14)    NVOXELS_Z=str;
if (i==15)    DIM_X=str;
if (i==16)    DIM_Y=str;
if (i==17)    DIM_Z=str;
if (i==18)    SourcePartDistType=str;
}
inFile.close();
Total_Events=( unsigned long int ) NumberOfSameParticle*Total_Events_To_Be_Processed;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void WRITE_MERGED_DOSIMETRIC_TXT()
{
SAFS_File.open(file+".saf", std::ios::out);
std::ofstream  TextFile;
TextFile.open(PhantomName+".phinfo", std::ios::out);
time_t theTime= time(NULL);
double BodyMass=0.0, tvolume=0.0;
int tvoxels=0;
struct std::tm* aTime = localtime(&theTime);
SAFS_File
         <<"CREATION DATE " << '\t' << asctime(aTime)
         <<"CPU  TIME (S) " << '\t' <<cputime 
         <<"\nSOURCE_EMITTED_ENERGY (MeV)" <<'\t' <<kinetic_energy     
         <<"\nPARTICLE NUMBER OF TIMES OF USE " <<'\t' << NumberOfSameParticle   
         <<"\nNUMBER OF THREADS" << '\t' << NumberOfThread
         <<"\nNUMBER OF SIMULATED EVENTS  "  <<'\t' <<     Total_Events_To_Be_Processed  
         <<"\nTOT NUMBER OF SIMULATED EVENTS  "<< '\t' <<Total_Events
         <<"\nORGAN NAME  "<< '\t' <<" AF " << '\t'  <<" SAF(kg^-1) "<<'\t' <<" STD_DEV(kg^-1) "<<'\t' <<" N_EVENTS " <<'\t' <<" STATISTICAL_ERROR(%) " <<endl;

TextFile <<"\nORGAN_NAME\tORGAN_ID\tORGAN_MATERIAL\tORGAN_MASSE(g)\tORGAN_VOLUME(CM_3)\tORGAN_NVOXELS\tORGAN_DENSITY(g/CM_3)"<< endl;
for (int i= 0;i<NumberOforgans; i++) 
{//2
{
double af =  RAM_InterDosiData[i].ABSORBED_ENERGY/Total_Events/kinetic_energy;
double  saf =  af/RAM_InterDosiData[i].ORGANE_MASSE;
if (RAM_InterDosiData[i].NEVENT >0)  RAM_InterDosiData[i].STAT_ERROR =100* RAM_InterDosiData[i].STD_DEV /saf ;
//saf expressed in 1/kg.
SAFS_File <<std::scientific<< RAM_InterDosiData[i].ORGANE_NAME << '\t' <<  af  << '\t'  <<std::setprecision(6) <<  saf <<'\t' << RAM_InterDosiData[i].STD_DEV  << '\t' << RAM_InterDosiData[i].NEVENT <<  '\t' << RAM_InterDosiData[i].STAT_ERROR<<endl;
if (RAM_InterDosiData[i].ORGANE_NAME !=" ") { BodyMass+=RAM_InterDosiData[i].ORGANE_MASSE; tvoxels+=RAM_InterDosiData[i].ORGANE_NVOXELS;tvolume+= RAM_InterDosiData[i].ORGANE_VOLUME;
    TextFile << std::setprecision(6)<<RAM_InterDosiData[i].ORGANE_NAME <<"\t"
         <<RAM_InterDosiData[i].ORGANE_ID <<"\t" 
         <<RAM_InterDosiData[i].ORGANE_MATERIAL <<"\t" 
         <<RAM_InterDosiData[i].ORGANE_MASSE*1000<<"\t"
         <<RAM_InterDosiData[i].ORGANE_VOLUME<<"\t"
         <<RAM_InterDosiData[i].ORGANE_NVOXELS<<"\t"
         <<1000*RAM_InterDosiData[i].ORGANE_MASSE/RAM_InterDosiData[i].ORGANE_VOLUME<< endl;
}      
}
}//2
if (NumberOfregions>0) {
TextFile <<"\nREGION_NAME\tREGION_NVOXELS\tREGION_MASSE(g)\tREGION_VOLUME(CM3)" <<endl;
for (int j= 0;j<NumberOfregions; j++) {

double af_reg =  RAM_RegStruc[j].ABSORBED_ENERGY/Total_Events/kinetic_energy;
double  saf_reg =  af_reg/RAM_RegStruc[j].REGION_MASSE;

if (RAM_RegStruc[j].REGION_NEVENT >0)  RAM_RegStruc[j].STAT_ERROR =100* RAM_RegStruc[j].STD_DEV /saf_reg ;

SAFS_File <<std::scientific<< RAM_RegStruc[j].REGION_NAME << '\t' << std::setprecision(6)<<  af_reg  << '\t'  << saf_reg  <<'\t' << RAM_RegStruc[j].STD_DEV   << '\t' << RAM_RegStruc[j].REGION_NEVENT <<  '\t' << RAM_RegStruc[j].STAT_ERROR<<endl;



TextFile << std::scientific<< RAM_RegStruc[j].REGION_NAME <<  '\t' <<   RAM_RegStruc[j].REGION_NVOXELS<< '\t' <<  RAM_RegStruc[j].REGION_MASSE*1000 << '\t'<<RAM_RegStruc[j].REGION_VOLUME << endl; 

}


}
TextFile <<"\nBODY MASSE (g)" << '\t' << BodyMass*1000<< "\nTOTAL NUMBER OF VOXELS"<<  '\t'<< tvoxels<<"\nBODY VOLUME(CM_3)"<< '\t' << tvolume<<endl;
TextFile <<"NVOXELS_X" << '\t' << NVOXELS_X<<'\n' << "NVOXELS_Y"<<  '\t'<< NVOXELS_Y<<'\n' <<"NVOXELS_Z"<< '\t' << NVOXELS_Z<<endl;
TextFile <<"DIM_X" << '\t' << DIM_X<<'\n' << "DIM_Y"<<  '\t'<< DIM_Y<<'\n' <<"DIM_Z"<< '\t' << DIM_Z<<endl;


SAFS_File.close();
TextFile.close();
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void FillRegData()
{
int tot_event=0;
for (unsigned short int i=0;i<NumberOfregions;i++) 
{
RAM_RegStruc[i].REGION_NVOXELS=tmp_RegStruc[i].REGION_NVOXELS;
RAM_RegStruc[i].REGION_NEVENT+=tmp_RegStruc[i].REGION_NEVENT;
std::strcpy (RAM_RegStruc[i].REGION_NAME, tmp_RegStruc[i].REGION_NAME);
RAM_RegStruc[i].ABSORBED_ENERGY+=tmp_RegStruc[i].ABSORBED_ENERGY;
RAM_RegStruc[i].ABSORBED_ENERGY2+=tmp_RegStruc[i].ABSORBED_ENERGY2;
RAM_RegStruc[i].REGION_VOLUME  = tmp_RegStruc[i].REGION_VOLUME;
RAM_RegStruc[i].REGION_MASSE   = tmp_RegStruc[i].REGION_MASSE;
tot_event=RAM_RegStruc[i].REGION_NEVENT;
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void RegCalculateSTD() 
{
int tot_event=0;
for (unsigned short int i=0;i<NumberOfregions;i++) 
{
if (RAM_RegStruc[i].REGION_NEVENT > 1)
{
tot_event=RAM_RegStruc[i].REGION_NEVENT;
double AE_MEAN         = RAM_RegStruc[i].ABSORBED_ENERGY/tot_event;
double  AE2_MEAN        = RAM_RegStruc[i].ABSORBED_ENERGY2/tot_event;
double alpha=1/kinetic_energy/RAM_RegStruc[i].REGION_MASSE;
double beta = (alpha*alpha*AE2_MEAN)- (AE_MEAN*alpha*alpha*AE_MEAN);
string str_std= to_string(sqrt((beta)/ (tot_event-1)));
if  (str_std=="-nan") {cout <<  "============ Error:  -NAN ========" << endl;

double af =  RAM_RegStruc[i].ABSORBED_ENERGY/Total_Events/kinetic_energy;
double  saf =  af/RAM_RegStruc[i].REGION_MASSE;
RAM_RegStruc[i].STD_DEV=saf/(sqrt(Total_Events));

} else  {

RAM_RegStruc[i].STD_DEV=sqrt((beta)/ (tot_event-1));

}


}
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void CalculateSTD() 
{
int tot_event=0;
for (unsigned short int i=0;i<NumberOforgans;i++) 
{
if (RAM_InterDosiData[i].NEVENT > 1)
{
tot_event=RAM_InterDosiData[i].NEVENT;
double AE_MEAN         = RAM_InterDosiData[i].ABSORBED_ENERGY/tot_event;
double AE2_MEAN        = RAM_InterDosiData[i].ABSORBED_ENERGY2/tot_event;
double alpha=1/kinetic_energy/RAM_InterDosiData[i].ORGANE_MASSE;
double beta = (alpha*alpha*AE2_MEAN)- (AE_MEAN*alpha*alpha*AE_MEAN);

double SAF_MEAN         = RAM_InterDosiData[i].ABSORBED_ENERGY/Total_Events/tot_event;
double SAF2_MEAN        = RAM_InterDosiData[i].ABSORBED_ENERGY2/Total_Events/tot_event;
string str_std= to_string(sqrt((beta)/ (tot_event-1)));
if  (str_std=="-nan") {cout <<  "============ Error:  -NAN ========" << endl;

double af =  RAM_InterDosiData[i].ABSORBED_ENERGY/Total_Events/kinetic_energy;
double  saf =  af/RAM_InterDosiData[i].ORGANE_MASSE;
RAM_InterDosiData[i].STD_DEV=saf/(sqrt(Total_Events));

} else  {

RAM_InterDosiData[i].STD_DEV=sqrt((beta)/ (tot_event-1));

}

}
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void FillData()
{
int tot_event=0;
for (unsigned short int i=0;i<NumberOforgans;i++) 
{
RAM_InterDosiData[i].ORGANE_ID=tmp_InterDosiData[i].ORGANE_ID;
RAM_InterDosiData[i].ORGANE_NVOXELS=tmp_InterDosiData[i].ORGANE_NVOXELS;
RAM_InterDosiData[i].NEVENT+=tmp_InterDosiData[i].NEVENT;
std::strcpy (RAM_InterDosiData[i].ORGANE_NAME, tmp_InterDosiData[i].ORGANE_NAME);
std::strcpy (RAM_InterDosiData[i].ORGANE_MATERIAL, tmp_InterDosiData[i].ORGANE_MATERIAL);
RAM_InterDosiData[i].ABSORBED_ENERGY+=tmp_InterDosiData[i].ABSORBED_ENERGY;
RAM_InterDosiData[i].ABSORBED_ENERGY2+=tmp_InterDosiData[i].ABSORBED_ENERGY2;
RAM_InterDosiData[i].ORGANE_VOLUME  = tmp_InterDosiData[i].ORGANE_VOLUME;
RAM_InterDosiData[i].ORGANE_MASSE   = tmp_InterDosiData[i].ORGANE_MASSE;

}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_InterDosiData( std::string _InterDosiDataFileName)
{
try{
H5File file( _InterDosiDataFileName, H5F_ACC_RDONLY );
DataSet dataset = file.openDataSet( DatasetName );
H5::CompType mtype( sizeof(InterDosiData) );
int data_size  = dataset.getSpace().getSimpleExtentNpoints();
tmp_InterDosiData    = new InterDosiData[data_size];
mtype.insertMember(MEMBER_ORGANE_NAME,              HOFFSET(InterDosiData, ORGANE_NAME),  H5::StrType(H5::PredType::C_S1, MAX_ORGANE_NAME_LENGTH));
mtype.insertMember(MEMBER_ORGANE_MATERIAL,          HOFFSET(InterDosiData, ORGANE_MATERIAL),  H5::StrType(H5::PredType::C_S1, MAX_ORGANE_NAME_LENGTH));
mtype.insertMember(MEMBER_ORGANE_MASSE,             HOFFSET(InterDosiData, ORGANE_MASSE),   H5::PredType::NATIVE_DOUBLE);
mtype.insertMember(MEMBER_ORGANE_VOLUME,            HOFFSET(InterDosiData, ORGANE_VOLUME),    H5::PredType::NATIVE_DOUBLE);
mtype.insertMember(MEMBER_KINETIC_ENERGY,           HOFFSET(InterDosiData, KINETIC_ENERGY),    H5::PredType::NATIVE_DOUBLE);
mtype.insertMember(MEMBER_ABSORBED_ENERGY,          HOFFSET(InterDosiData, ABSORBED_ENERGY),    H5::PredType::NATIVE_DOUBLE );
mtype.insertMember(MEMBER_ABSORBED_ENERGY2,         HOFFSET(InterDosiData, ABSORBED_ENERGY2),    H5::PredType::NATIVE_DOUBLE );
mtype.insertMember(MEMBER_NEVENT,                   HOFFSET(InterDosiData, NEVENT),    H5::PredType::NATIVE_INT );
mtype.insertMember(MEMBER_ORGANE_ID,                HOFFSET(InterDosiData , ORGANE_ID),  H5::PredType::NATIVE_INT );
mtype.insertMember(MEMBER_ORGANE_NVOXELS,           HOFFSET(InterDosiData , ORGANE_NVOXELS),  H5::PredType::NATIVE_INT );
dataset.read( tmp_InterDosiData, mtype );
FillData();

}
catch( FileIException error )
{
}
catch( DataSetIException error ){
}
catch( DataSpaceIException error )
{
}
catch( DataTypeIException error )
{
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void READ_InterDosiRegData( std::string _InterDosiDataFileName)
{
try{
H5File file( _InterDosiDataFileName, H5F_ACC_RDONLY );
DataSet dataset_region = file.openDataSet( DatasetName_region );
H5::CompType mtype_region( sizeof(RegStruc) );
int data_size  = dataset_region.getSpace().getSimpleExtentNpoints();
tmp_RegStruc    = new RegStruc[data_size];
mtype_region.insertMember(MEMBER_REGION_NAME,         HOFFSET(RegStruc, REGION_NAME),  H5::StrType(H5::PredType::C_S1, MAX_ORGANE_NAME_LENGTH));
mtype_region.insertMember(MEMBER_REGION_MASSE,        HOFFSET(RegStruc, REGION_MASSE),   H5::PredType::NATIVE_DOUBLE);
mtype_region.insertMember(MEMBER_REGION_VOLUME,       HOFFSET(RegStruc, REGION_VOLUME),    H5::PredType::NATIVE_DOUBLE);
mtype_region.insertMember(MEMBER_REGION_KINETIC_ENERGY,      HOFFSET(RegStruc, KINETIC_ENERGY),    H5::PredType::NATIVE_DOUBLE);
mtype_region.insertMember(MEMBER_REGION_ABSORBED_ENERGY,     HOFFSET(RegStruc, ABSORBED_ENERGY),    H5::PredType::NATIVE_DOUBLE );
mtype_region.insertMember(MEMBER_REGION_ABSORBED_ENERGY2,    HOFFSET(RegStruc, ABSORBED_ENERGY2),    H5::PredType::NATIVE_DOUBLE );
mtype_region.insertMember(MEMBER_REGION_NVOXELS,      HOFFSET(RegStruc, REGION_NVOXELS),    H5::PredType::NATIVE_INT );
mtype_region.insertMember(MEMBER_REGION_NEVENT,        HOFFSET(RegStruc , REGION_NEVENT),  H5::PredType::NATIVE_INT );
dataset_region.read( tmp_RegStruc, mtype_region );
FillRegData();

}
catch( FileIException error )
{
}
catch( DataSetIException error ){
}
catch( DataSpaceIException error )
{
}
catch( DataTypeIException error )
{
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int main(int argc,char** argv)
{
std::string _FileName;
inputfile=  argv[1] ;
ifstream File;
bool _exit;
File.open(inputfile.c_str());
_exit = File.good();
if (_exit==false) {

cout <<"===DoseOrgMerger    Error: Simulation has not been started !" <<endl;
cout <<"===DoseOrgMerger    " << inputfile.c_str() << " doesn't exist."<<endl;

cout <<"===DoseOrgMerger    Goodbye !" <<endl;
} else {
READ_TXT();
RAM_InterDosiData= new InterDosiDataMerger[NumberOforgans];

for (unsigned short int i=0;i<NumberOforgans;i++) 
{
RAM_InterDosiData[i].ORGANE_ID         = 0;
RAM_InterDosiData[i].NEVENT            = 0;
RAM_InterDosiData[i].ABSORBED_ENERGY   = 0.0;
RAM_InterDosiData[i].ABSORBED_ENERGY2  = 0.0;
RAM_InterDosiData[i].KINETIC_ENERGY      = 0.0;
RAM_InterDosiData[i].ORGANE_VOLUME      = 0.0;
RAM_InterDosiData[i].ORGANE_NVOXELS     = 0;
RAM_InterDosiData[i].ORGANE_MASSE       = 0.0;
RAM_InterDosiData[i].STD_DEV            = 0.0;
RAM_InterDosiData[i].STAT_ERROR         = 0.0;
}
if (NumberOfregions>0) {
RAM_RegStruc= new RegStrucMerger[NumberOfregions];
for (unsigned short int i=0;i<NumberOfregions;i++) 
{
RAM_RegStruc[i].REGION_NEVENT            = 0;
RAM_RegStruc[i].ABSORBED_ENERGY   = 0.0;
RAM_RegStruc[i].ABSORBED_ENERGY2  = 0.0;
RAM_RegStruc[i].KINETIC_ENERGY    = 0.0;
RAM_RegStruc[i].REGION_VOLUME     = 0.0;
RAM_RegStruc[i].REGION_NVOXELS     = 0;
RAM_RegStruc[i].REGION_MASSE      = 0.0;
RAM_RegStruc[i].STD_DEV            = 0.0;
RAM_RegStruc[i].STAT_ERROR         = 0.0;
}
}
cout << "===InterDosi    Calling DoseOrgMerger tool." <<endl;
for (int i=0;i<NumberOfThread;i++) 
{
 _FileName= file+"-"+std::to_string(i) +".h5" ;
cout << "===DoseOrgMerger    Read file: "<<file+"-"+std::to_string(i) +".h5" <<endl;
ifstream inFile;
bool file_exit;
inFile.open(_FileName.c_str());
file_exit = inFile.good();
if (file_exit==false)
{cout << "===DoseOrgMerger    The file named << "<<_FileName.c_str()<<">> does not exist !"<< endl;
cout <<"===DoseOrgMerger    Error: Merging data has been not performed !" <<endl;
cout <<"===DoseOrgMerger    Goodbye !" <<endl;
 std::ofstream      file         ;
file.open ("DoseOrgMerger_Error.txt");
  file << "===DoseOrgMerger    The file named << "<<_FileName.c_str()<<">> does not exist !"<<endl;
  file.close();
exit(0);}
READ_InterDosiData(file+"-"+std::to_string(i) +".h5");
if (NumberOfregions>0) { READ_InterDosiRegData(file+"-"+std::to_string(i) +".h5");}
}
CalculateSTD() ;
 RegCalculateSTD();
WRITE_MERGED_DOSIMETRIC_TXT();

for (int i=0;i<NumberOfThread;i++) {_FileName= file+"-"+std::to_string(i) +".h5";
//
remove(_FileName .c_str());
}
cout <<"===DoseOrgMerger    Merging data has been successfully performed !" <<endl;
cout <<"===DoseOrgMerger    Goodbye !" <<endl;
delete [] RAM_InterDosiData;
exit(0) ;
}
}
