/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DoseVoxMerger.hh"
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <ctime>
#include <string>
#include <sstream>
using namespace std;
string file="";
string str="";
int NumberOfThread=0;
int i=-1;
doseIn3dVoxel ***DVoxels;
int Number_Of_Voxels_Along_x=0;
int Number_Of_Voxels_Along_y=0;
int Number_Of_Voxels_Along_z=0;
string PhantomDescriptorFileFullPath="" ;
/*#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void GetNumberOfVoxels(std::string _PhantomDescriptorFileFullPath)
{//1
ifstream PhantomDescriptorFile;
PhantomDescriptorFile.open(_PhantomDescriptorFileFullPath);
string str;
string key="";
while (getline(PhantomDescriptorFile,str))
{//2
vector<string> result;
istringstream iss(str);
while (getline(iss,str,'\t'))
{//3
result.push_back(str);
}//3
key=result[0];
if (key=="@NumberOfVoxels") 
{//4
Number_Of_Voxels_Along_x=stoi(result[1]);
Number_Of_Voxels_Along_y=stoi(result[2]);
Number_Of_Voxels_Along_z=stoi(result[3]);

cout<<"===DoseVoxMerger   Number of voxels along x,y and z axis:" << Number_Of_Voxels_Along_x <<","<<Number_Of_Voxels_Along_y <<","<<Number_Of_Voxels_Along_z<< endl;
}//4
}//2
PhantomDescriptorFile.close();
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void ReadDoseInXYZinfoFile()
{
ifstream inFile;
inFile.open("./sim.data");
while (getline(inFile,str))
{
i++;
if (i==0){ file=str;}
if (i==2) NumberOfThread=stoi(str);
if (i==8) PhantomDescriptorFileFullPath =str ;
}
inFile.close();
GetNumberOfVoxels(PhantomDescriptorFileFullPath);

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void CreateDoseInXYZfile()
{
std::ofstream   _File;
_File.open(file+".dvox", std::ios::app);
_File << PhantomDescriptorFileFullPath<<endl;
for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++)
{
for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++)
{
for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++)
{
if ( DVoxels[ix][iy][iz].absorbed_dose!=0.0) _File <<  ix << "\t"<< iy<< "\t"<< iz<< "\t"<< DVoxels[ix][iy][iz].absorbed_dose<<endl;
}}}
_File.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void ReadDoseInXYZFile(std::string _DoseInXYZFileName)
{
ifstream inFile;
inFile.open(_DoseInXYZFileName);
std::string str;
vector<string> data;
while (std::getline(inFile,str))
{
std::vector<std::string> result;
std::istringstream iss(str);
for(std::string s_data; iss >> s_data; )
{
result.push_back(s_data);
}
int ix=0;
int iy=0;
int iz=0;
int nevents=0;
double dose=0.0, dose2=0.0;
ix     = std::stoi( result[0]);
iy     = std::stoi( result[1]);
iz     = std::stoi( result[2]);
dose   = std::stod(result[3]);
DVoxels[ix][iy][iz].absorbed_dose  += dose;
}
 remove(_DoseInXYZFileName.c_str());
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int main(int argc,char** argv)
{

cout << "===InterDosi    Calling DoseVoxMerger tool." <<endl;
ReadDoseInXYZinfoFile();
DVoxels=new doseIn3dVoxel**[Number_Of_Voxels_Along_x];
for (int ix=0; ix< Number_Of_Voxels_Along_x; ix++)
{
DVoxels[ix]=new doseIn3dVoxel*[Number_Of_Voxels_Along_y];
for (int iy=0; iy< Number_Of_Voxels_Along_y; iy++)
{
DVoxels[ix][iy]=new doseIn3dVoxel[Number_Of_Voxels_Along_z];
for (int iz=0; iz< Number_Of_Voxels_Along_z; iz++)
{
DVoxels[ix][iy][iz].absorbed_dose  = 0.;
}
}
}
for (int i=0;i<NumberOfThread;i++) 
{
cout << "===DoseVoxMerger    Read file: "<<file+"-"+std::to_string(i) +".txt" <<endl;
ReadDoseInXYZFile(file+"-"+std::to_string(i) +".txt");
}
CreateDoseInXYZfile();
cout <<"===DoseVoxMerger    Merging Dvox data has been successfully performed !" <<endl;
cout <<"===DoseVoxMerger    Goodbye !" <<endl;
return 0;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
