/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef VoxIsle_h
#define VoxIsle_h 1
#include "globals.hh"
#include "G4ThreeVector.hh"
#include "G4Box.hh"
#include "G4VPhysicalVolume.hh"
#include "G4PVPlacement.hh"
#include "globals.hh"
#include "G4ThreeVector.hh"
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
#include <iostream>       
#include <cstddef>  
#include <list>  
#include <map>   
using namespace std;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=*/
class                            G4Timer;
class                            G4Box;
class                            G4LogicalVolume;
class                            G4VPhysicalVolume;
class                           
VoxIsle
{
private:
static VoxIsle *                 theInstance;
                                                       VoxIsle();
public:                                       ~VoxIsle();
static VoxIsle *                         GetInstance();
int                                                        GetLogicalVolIndexInArray(std::string );
int *                                              LowerHeigherZID( int organ_id, int ***& Voxels);
void  ApplyParallelVoxelIslandMethod
(  int ***&,  int  , int , int , int , int , int , float , float , float ,float , float , float, vector<vector<std::string>>&, int   );
int *                                                 LowerHeigherXID( int organ_id, int ***& Voxels);
int *                                                  LowerHeigherYID( int organ_id, int ***& Voxels);
int                                                       Number_Of_Voxels_Along_x,NumberOfPhantomOrgans,BackgroundID, backgroudID,SliceZ,NumberofElements,OrganeID,NumberMergedVoxels,
                                                             Number_Of_Voxels_Along_y,
                                                             Number_Of_Voxels_Along_z;


std::string                                     GetIrVoxData();
std::string                                   IrVoxLogicalVolData,IrVoxSolidVolData ;
std::string                                    OrganeName, IrVoxVolumeSize;
list<string>                                   ArraySolidVolumeName, ArrayLogicalVolumeName;
void                                                 Clear( ) ;
void                                                  SetArrayOrgansIds(vector<int> _data);
void                                                  split(const std::string &s, char delim, std::vector<std::string> &elems) ;
G4double                                           GetOrganTotalVoxels(const   int   organ_id, int ***&Voxels) ;
void                                                     SetBackgroudID(int backgroudID);
void                                                     SetNumberOfVoxels(const G4ThreeVector& ) ;
void                                                     SetVoxelDimensions(const G4ThreeVector& );
void                                                     SetPhantomDimensions(const G4ThreeVector& );
void                                                  SetNumberOfPhantomOrgans (int ) ;
void                                                   Apply(int ***&);
void                                                  SetPhantomName(std::string );
G4VPhysicalVolume *              physWorld ;
void                                                   SetWorldVolume(G4VPhysicalVolume*);
double                                               VOXEL_X_DIM, VOXEL_Y_DIM, VOXEL_Z_DIM, PHANTOM_X_DIM, PHANTOM_Y_DIM,  PHANTOM_Z_DIM;

 vector<int>ArrayOrgansIds;
string optimization_axis;
int     Total_Number_Of_Merged_Voxels;
string  PhantomName;
};
#endif
