/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef DetectorConstruction_h
#define DetectorConstruction_h 1
#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"
#include "G4ThreeVector.hh"
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
#include <iostream>       
#include <cstddef>  
#include <list>  
#include <map>  
class G4VPhysicalVolume;
class DetectorMessenger;
class G4LogicalVolume;
class G4Material;
class PhantomSD;
class G4tgrMessenger;
class G4RunManager;
class G4Colour;
class G4Timer;
class G4Box;
class G4PVPlacement;
class G4VoxelizedPhantomParameterisation;

using namespace std;
class DetectorConstruction : public G4VUserDetectorConstruction
{
public:
string                         InterDosiDirectory();
std::vector<G4LogicalVolume*>  tmp;
G4Box* solidWorld;
G4LogicalVolume* logicWorld;
std::vector<G4Material*>       ArrayMat;
std::vector<G4Colour>       ArrayClr;
std::vector<   int>       ArrayNSegment;
std::vector<G4LogicalVolume*> ArrayLogicalVolume;
std::vector<G4LogicalVolume*>  ArrayLogicalVoxIslesVolume;
std::vector<G4VPhysicalVolume*>  ArrayPhysicalVolume;
std::vector<G4Box*>              ArraySolidVolume;
std::vector<G4Box*>              ArraySolidVoxIslesVolume;
std::vector<G4Box*>              ArrayIrVoxSolidVolume;
std::vector<G4LogicalVolume*>    ArrayIrVoxLogicalVolume;
std::vector<std::string>         ArrayIrVoxLogicalVolumeName;

 G4String voxphantomtype;
vector<   int>                ArrayOrgansIds;
double*            ArrayOrgansVolumes;
double*           ArrayOrgansMasses;
double*            ArrayOrgansDensities;
  int   *                ArrayOrgansVoxels;
  int   *                 ArrayRegionsVoxels;
  int   *               ArrayRegionsIds;
std::map<string, int> MapOrganNameIds;
std::map<int, int> MapOrganIdsIterators;
std::map<int, int> MapCopyNumbersToIterators;
std::map<int, int> MapOrganIdsToMaterialIds;
std::map<int, G4ThreeVector> MapCopyNumbersToIJK;

double*           ArrayRegionsVolumes;
   int Nvoxel_OutideBodyAir ;
double Volume_OutideBody;
   int  ***Voxels; 
   int  ***CopyNumberArray; 
size_t* mateIDs ;
bool  USE_REGULAR_NAVIGATION;
                               DetectorConstruction();
virtual                       ~DetectorConstruction();
virtual void                   ConstructSDandField();
G4Material                   * MaterialName(const    int);
G4Material                   * CreateMaterial(const G4String);
G4Material                   * world_mat ;
  int             GetMaterialIdOfOrganId(const G4String);
G4VoxelizedPhantomParameterisation* param ;
int MinZID,MaxZID;
  int             FindIteratorFromOrganIds(vector<   int>,   int );
  int             OrganIDtoIterator(   int);
  int             OrganeID(const string );
int              ID_SolidVol(std::string, std::string);
  int             NumberOfPhantomOrgans, 
                               Number_Of_Voxels_Along_x,
                               Number_Of_Voxels_Along_y,
                               Number_Of_Voxels_Along_z,
                               NumberOfPhantomAnatomicalRegions,
                               SliceId,
                               BackgroundID, 
                               number_of_elements_in_material,
                               NUMBER_OF_THREADS,
                               ParticleRecyclingFactor,
                               NumberOfThread;
void                           SetPhysicsPackage(G4String);
int                            OrganIDtoMaterialID(int organid);
G4double                       GetOrganTotalVoxelizedVolumeFromId(const    int  ) ;
void                           Construct_Phantom_With_Regular_Navigation( );
void                           SET_USE_REGULAR_NAVIGATION_FLAG(bool);
G4ThreeVector                  GetVoxelIndices(int );
void                           SetCutForElectron(G4double);
int                              GetMax_MinZID(int );
void                           SetCutForGamma(G4double);
G4ThreeVector   Calcualte3DposSegment(int , int , int , int , int , float , float ,float ,float , float ,float );
void                           SetCutForPositron(G4double);
void                           set_kinetic_energy(G4double);
void                           setScoreDosePerVoxel(bool);
void                           setSkipEqualMaterials(bool );
void                           SetBackgroundID(  int);
void                           SetPhantomDescriptorFileFullPath(string );
void                           ProcessIrregularVoxDataZAxis( std::string  , int  , int);
void                           SetOrganToVis3D(std::string );
void                           SetProjection(string  ); 
std::vector<float>  ArrayIrVoxOrganeVolume;
std::vector <float>   GetMergedVoxelsIndicesX( int , float );
std::vector <float>   GetMergedVoxelsIndicesY( int , float );
std::vector <float>   GetMergedVoxelsIndicesZ( int , float );
void                          split(const std::string &, char , std::vector<std::string> &) ;
void                           Construct_Partial_Phantom(   int );
void                           SetSliceId(  int);
void                          ConstArraySolidVoxIslesVolumesZAXIS( int ,  int , float , float , float );
void                          ConstArraySolidVoxIslesVolumesXAXIS( int ,  int , float , float , float );
void                          ConstArraySolidVoxIslesVolumesYAXIS( int ,  int , float , float , float );
G4Box*                    ConstructSolidVolume(int , int ) ;
void                          ConstructIrVoxPhysicalVolumeXAXIS(G4LogicalVolume*, G4ThreeVector , int , int ,  int iz, std::string );
void                          ConstructIrVoxPhysicalVolumeYAXIS(G4LogicalVolume*, G4ThreeVector , int , int ,  int iz, std::string );
void                          ConstructIrVoxPhysicalVolumeZAXIS(G4LogicalVolume*, G4ThreeVector , int , int ,  int iz, std::string );
void                           SetVoxGeomMacroFileName(G4String );
G4LogicalVolume* ConstructIrVoxLogicalVolume(int , int  ,std::string);
int                            GetIrVoxLogicalVolIndexInArray(std::string );
int                             GetSolidVolIndexInArray(std::string );
void                           ConstructLogicalVolumes(G4String  );
void                           ReadVoxelizedPhantomParameters();
void                           SetupVoxelizedPhantomParametersForIrVoxFormat();
void                           ReadMaterialDataFromFile(const G4String );
void                           SetSourceOrganeName( G4String );
void                          ReadIrVoxData(std::string  );
void                           SetNumberOfThreads(  int);
void                           SetParticleRecyclingFactor(  int);
std::string             VoxelizedPhantomType( std:: string );
void                           SetupVoxelizedPhantomParametersForIjkidFormat();
void                           set_particle_name(string  ) ;
void                           Calcualte3DposSegment(int ix1, int ix2, int iy1, int iy2, int iz);
void                           setSelectRegion (bool  );
void                           CheckTheValidityOfOrganRegionName(std::string );
void                           SetPartDistType(std::string );
void                           ConstArrayLogicalVoxIslesVolumes( int organ_id, int solid_id);
void                          CreateIrvoxPhantom( int low_iz, int high_iz);
int *                            LowerHeigherZID( int organ_id);
string                         GetMaterialName(const int OrganeId);
G4double                       GetOrganTotalVoxelizedVolume(string );
G4double                       GetOrganTotalVoxels( const    int);
G4double                       GetOrganeDensity(  int);
G4double                       
                               material_density,
                               VOXEL_X_DIM,
                               VOXEL_Y_DIM,
                               VOXEL_Z_DIM,
                               PHANTOM_X_DIM,
                               PHANTOM_Y_DIM,
                               PHANTOM_Z_DIM;
virtual                        G4VPhysicalVolume* Construct();
string                         OrganeName(const   int  );
void           FillDataIrVox(std::string  );
void      SetPhantomName (std::string name);
string                         Projection,PartDistType,	OrganToVis3D,
                             
                               material_name,WorldMat,
                               AnatomicalRegion,
                               PhantomName,PhantomFileName,
                               PhantomFileDir, 
                               PhantomDescriptorFileFullPath;
G4String                       sensitiveDetectorName,PhysicsPackage,particle_name,
                               SourceOrganeName;
G4Colour                       OrganeColor(const   int );

G4double                       kinetic_energy, CutForGamma,CutForElectron, CutForPositron ;
PhantomSD*                     mPhantomSD;
static G4ThreadLocal G4bool    fConstructedSDandField;
bool                           ApplyStdThreshold;
bool                           ScoreDosePerVoxel;
bool                           SkipEqualMaterials;
bool                           SelectRegion;
G4Timer                     *  myTimer;
float remaing_word_volume, WorldDimX, WorldDimY, WorldDimZ;
float  WorldMathVolume;
G4String  VoxGeomMacroFileName;
DetectorMessenger           *  pDetectorMessenger;
G4tgrMessenger              *  messenger; 
G4LogicalVolume             *  Phantom_Logical;
G4RunManager                *  runManager;
G4VPhysicalVolume           *  Phantom_Physical ;
G4VPhysicalVolume           *  physWorld ;
std::vector<G4ThreeVector>     PhysicsVolPosList;
std::vector<string>            LogicalVolList;
list<string> MaterialsList;
typedef struct
{
string                         ORGAN_NAME,
                               ORGAN_MATERIAL;
  int             ORGAN_COLOR_R,
                               ORGAN_COLOR_G,
                               ORGAN_COLOR_B,
                               ORGAN_ID;

}                               VoxelizedPhantomStruc;
VoxelizedPhantomStruc       *  _VoxelizedPhantomStruc;
typedef struct
{
string                         REGION_NAME;                           
std::vector<  int>                           ARRAY_ORGAN_IDS;
}                               VoxelizedPhantomRegStruc;
std::vector<VoxelizedPhantomRegStruc>    _VoxelizedPhantomRegStruc;
typedef struct
{
string                          ELEMENT;
G4double                        FRACTION;
}                               ELEMENT_DATA;
ELEMENT_DATA                *   _ELEMENT_DATA;
};
#endif
