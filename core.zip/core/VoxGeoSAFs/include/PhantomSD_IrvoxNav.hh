/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef PhantomSD_IrvoxNav_h
#define PhantomSD_IrvoxNav_h 1

#include "G4ThreeVector.hh"
#include "G4VSensitiveDetector.hh"
#include "G4VTouchable.hh"
#include <vector>
#include "G4ios.hh"
#include <stdio.h>
#include "G4Threading.hh"

#include <thread>
using namespace std;
class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;
class DetectorConstruction;
class G4RunManager;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
class  PhantomSD_IrvoxNav : public G4VSensitiveDetector
{
public:
PhantomSD_IrvoxNav(
G4String name);
~PhantomSD_IrvoxNav();
G4bool ProcessHits(G4Step*aStep,G4TouchableHistory*);
void CreateDosePerVoxelMapFile();
void EndOfRun();
int *GetIdsVoxelXYZ(std::string _physical_volume_name) ;
void FillDataInAnatomicalRegions(int , double );
void InitializeDataInAnatomicalRegions();
void BeginOfRun();
void SaveDosimetricDataInBinaryFile(std::string);
std::string G4PartToPart(std::string g4_particle_name);
void WRITE_INTERNAL_DOSIMETRIC_DATA_FILE(std::string);
string                         StrWithoutDigits(string );
std::string Abrev_ListPhysics(std::string );
std::string Abrev_SourcePartDistType(string ) ;
typedef struct
{
char ORGANE_NAME[100000];
char ORGANE_MATERIAL[100000];
double 
ORGANE_MASSE,
ORGANE_VOLUME,
KINETIC_ENERGY,
ABSORBED_ENERGY,
ABSORBED_ENERGY2;
unsigned  int NEVENT ;
int ORGANE_ID,ORGANE_NVOXELS;
}InterDosiData;
typedef struct
{
char                         REGION_NAME[100000];
 unsigned int REGION_NEVENT;  
int REGION_NVOXELS;  
double ABSORBED_ENERGY,ABSORBED_ENERGY2,KINETIC_ENERGY,REGION_VOLUME,REGION_MASSE;
}  RegStruc;
 std::vector<RegStruc>    pRegStruc;
private:
G4double x;
G4double y;
G4double z;
int Total_Events,Total_Events_To_Be_Processed,NumberOfThreads;
G4String NameOfPhantomPhysicalVolume;
G4String DOSIMETRIC_DATA_FileName;
 std::vector<InterDosiData>    myInterDosiData_vector;
G4ThreeVector HalfSize;
G4ThreeVector pos;
G4double HalfVoxelDimensionAlongX, HalfVoxelDimensionAlongY, HalfVoxelDimensionAlongZ;
G4int NumberTotalEvents, NumberOfVoxelsAlongX, NumberOfVoxelsAlongY, NumberOfVoxelsAlongZ;
G4double VoxelMass, density, VoxelVolume;
DetectorConstruction* pDetectorConstruction;  
G4ThreadLocal  static int INCREMENTOR;
G4double BODY_MASSE=0;
G4double ORGANE_MASSE=0;
G4double TOTAL_EMITTED_ENERGY_FROM_SOURCE_ORGANE=0;
InterDosiData *_InterDosiData;
G4float SAF,PHOT_COUNT,CMPT_COUNT,TOTAL_EMITTED_ENERGY_FROM_SOURCE_AND_RECEIVED_BY_TARGET,ABSORBED_ENERGY,OrganTotalVoxelizedVolume;
G4int NEVENT;
G4RunManager* runManager;
float cpu_time;
};
#endif
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
