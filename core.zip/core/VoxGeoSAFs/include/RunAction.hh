/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef RunAction_h
#define RunAction_h 1
#include <ctime>
#include "G4UserRunAction.hh"
#include "globals.hh"
#include <vector>
#include <fstream>
#include <iostream>
#include "G4ios.hh"
#include <stdio.h>
#include <math.h>
#include "globals.hh"
class DetectorConstruction;
class G4Run;
class G4RunManager;
class RunAction : public G4UserRunAction
{
public:
RunAction();
virtual ~RunAction();
virtual void BeginOfRunAction(const G4Run*);
virtual void EndOfRunAction(const G4Run*);
std::string Abrev_ListPhysics(std::string);
std::string G4PartToPart(std::string) ;
std::string Abrev_SourcePartDistType(std::string ) ;
typedef struct
{
char ORGANE_NAME[100000];
char ORGANE_MATERIAL[100000];
double 
ORGANE_MASSE,
ORGANE_VOLUME,
KINETIC_ENERGY,
ABSORBED_ENERGY,
ABSORBED_ENERGY2;
long double STD_DEV;
unsigned  int NEVENT ;
int ORGANE_ID,ORGANE_NVOXELS;
}InterDosiData;


typedef struct
{
char          PHYSICS_PACKAGE[100000],
              PARTICLE_TYPE[100000],
              ORGAN_SOURCE_NAME[100000];
double        SIMULATION_CPU_TIME,
              PARTICLE_ENERGY,
              ELECTRON_PROCUT, 
              GAMMA_PROCUT, 
              POSITRON_PROCUT;
unsigned  int TOTAL_NUMBER_OF_HISTORIES ;
int           NUMBER_OF_THREADS, 
              PARTICLE_RECYCLING_FACTOR;
}             SimulationStatisticsData;
unsigned  long int      Total_Events;
               int      Total_Events_To_Be_Processed,
                        NEVENT,NumberOfThread;

double                  cpu_time;
G4float                 SAF,
                        PHOT_COUNT,
                        CMPT_COUNT,ABSORBED_ENERGY,
                        OrganTotalVoxelizedVolume;
DetectorConstruction  * pDetectorConstruction;  
G4RunManager          * runManager;
std::vector<InterDosiData>    InterDosiData_Combined;
std::vector<SimulationStatisticsData>   mySimulationStatisticsData;
};
#endif

