/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "VoxIsle.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h> 
#include <iterator>
#include <sstream>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
#include <iostream>       
#include <cstddef> 
#include <list> 
#include <bits/stdc++.h>
#include <iostream> 
#include <vector> 
#include <algorithm>  
#include "G4VisAttributes.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4PVPlacement.hh"
#include "Randomize.hh"
#include <cmath>
#include "G4PhysicalConstants.hh"
#include "Randomize.hh"
#include "G4Timer.hh"
#include <future>
int raw, col;
 int skip= 1;
 int minw=0;
 int incrementor=0;
 int it=0;
 int area=0, previousarea=0;
 int area_max=0;
int First_Point_Y=0;
 int First_Point_X=0;
 int Second_Point_Y=0;
 int Second_Point_X=0;
 int Third_Point_Y=0;
 int Third_Point_X=0;
 int Fourth_Point_Y=0;
 int Fourth_Point_X=0;
 double large_size_x=0.0;
 double large_size_y=0.0;
 bool activate =true;
std::ofstream  TextFile;
 bool detected=false;
int lower_i=0, higher_i=0, lower_j=0, higher_j=0;
int NumberOfVoxelsMerged=0;
int **                                               original_binary_matrix;
 int **                                                binary_matrix;
 int **                                                 w;
 int **                                                 h;
string axis_flag="";
   string IrVoxData;
namespace {G4Mutex _Mutex = G4MUTEX_INITIALIZER;}  
namespace {G4Mutex _M= G4MUTEX_INITIALIZER;}  
namespace {G4Mutex  OPTIM_X_Mutex = G4MUTEX_INITIALIZER;}  
namespace {G4Mutex  OPTIM_Y_Mutex = G4MUTEX_INITIALIZER;}  
namespace {G4Mutex  OPTIM_Z_Mutex = G4MUTEX_INITIALIZER;}  
using namespace std;
 int id=-1, Total_Number_Of_noMerged_Voxels=0;
/*#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#*/
VoxIsle * VoxIsle::theInstance = 0;
VoxIsle * VoxIsle::GetInstance()
{
if (!theInstance) theInstance = new VoxIsle();
return theInstance;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::Clear()
{
NumberofElements=0;
IrVoxData="";
Total_Number_Of_Merged_Voxels=0;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
VoxIsle::VoxIsle()
{
NumberofElements=0;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetBackgroudID(int _backgroudID) {

this->BackgroundID= _backgroudID;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetWorldVolume(G4VPhysicalVolume           *  _physWorld) 
{
this->physWorld =  _physWorld;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetPhantomDimensions(const G4ThreeVector& PhantomDimensions) 
{
this->PHANTOM_X_DIM =  PhantomDimensions.x();
this->PHANTOM_Y_DIM =  PhantomDimensions.y();
this->PHANTOM_Z_DIM =  PhantomDimensions.z();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetVoxelDimensions(const G4ThreeVector& VoxelDimensions) 
{
this->VOXEL_X_DIM =  VoxelDimensions.x();
this->VOXEL_Y_DIM =  VoxelDimensions.y();
this->VOXEL_Z_DIM =  VoxelDimensions.z();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetNumberOfVoxels(const G4ThreeVector& NumberOfVoxelsVector) 
{
this->Number_Of_Voxels_Along_x =  NumberOfVoxelsVector.x();
this->Number_Of_Voxels_Along_y =  NumberOfVoxelsVector.y();
this->Number_Of_Voxels_Along_z =  NumberOfVoxelsVector.z();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
VoxIsle::~VoxIsle(){

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::ApplyParallelVoxelIslandMethod

(  
int ***&Voxels, 
int Organ_ID,
  int min_k, 
int max_k,
 int Number_Of_Voxels_Along_x,
 int Number_Of_Voxels_Along_y,
 int Number_Of_Voxels_Along_z, 
float VOXEL_X_DIM, 
float VOXEL_Y_DIM, 
float VOXEL_Z_DIM,
float PHANTOM_X_DIM, 
float PHANTOM_Y_DIM,
 float PHANTOM_Z_DIM, 
vector<vector<std::string>> &results,
 int incrementor  
)
{
//plan  XY.
//cout<<"ORGAN_ID=" <<  Organ_ID   << "  SELECTED AXIS  Z"  << endl;
vector <string> DataToPass ;  
string  solid_data="", logical_data="";
int k=0, id=-1, lower_i=0,lower_j=0, higher_i=0, higher_j=0 ,  area=0, previousarea=0, skip= 1, minw=0,   it=0,  First_Point_Y=0, First_Point_X=0, Second_Point_Y=0, area_max=0, Second_Point_X=0,Third_Point_Y=0,Third_Point_X=0,Fourth_Point_Y=0, Fourth_Point_X=0;
vector<int> max_area_array;
int **                                                 matrix_Width;
int **                                                matrix_Height;
int **                                                 original_binary_matrix;
int **                                                 binary_matrix;
int                                                       Total_Number_Of_Merged_Voxels=0;

bool detected=false;
bool activate=true;
std::string  PhysicsData="";
for (k=min_k; k < max_k+1; k++)  {
int Length=0;
//----------------CheckIfOrganIsInMatrix
std::vector<int> val_x, val_y;
for (int j = Number_Of_Voxels_Along_y-1; j >-1 ; j--)  
{//1 
for (int i = 0; i < Number_Of_Voxels_Along_x; i++)
{//2
if (Voxels[i][j][k]==Organ_ID)
{
detected=true;
val_x.push_back(i);
val_y.push_back(j);
}}}
int min_x=0,  min_y=0, max_x=Number_Of_Voxels_Along_x-1, max_y=Number_Of_Voxels_Along_y-1;
  if (val_x.size() > 0){   min_x = *min_element(val_x.begin(), val_x.end()); max_x = *max_element(val_x.begin(), val_x.end());} 
  if (val_y.size() > 0){  min_y = *min_element(val_y.begin(), val_y.end()); max_y = *max_element(val_y.begin(), val_y.end());}
lower_i=min_x;
lower_j=min_y;
higher_i=max_x;
higher_j=max_y;
val_y.clear();
val_x.clear();
//----------------------CheckIfOrganIsInMatrix
if (detected==true)
{


PhysicsData+="\n"+std::to_string(k)+'\t';
detected=false;

//----------CreateMatrices

int X_DIM =higher_i+1-lower_i; 
int Y_DIM =higher_j+1-lower_j; 
binary_matrix = new int *[X_DIM];
original_binary_matrix = new int *[X_DIM];
matrix_Height = new int *[X_DIM];
matrix_Width = new int *[X_DIM];
for (int i=0; i< X_DIM ; i++)  
{
original_binary_matrix[i]= new  int [Y_DIM];
matrix_Height[i]= new  int [Y_DIM];
matrix_Width[i]= new  int [Y_DIM];
binary_matrix[i]= new  int [Y_DIM];
}

//----------CreateMatrices
for (int j= higher_j-lower_j; j>  -1 ; j--)  
{
for (int i=0; i<   higher_i-lower_i+1 ; i++)  
{
matrix_Height[i][j]=0; 
matrix_Width[i][j]=0;
if (Voxels[i+lower_i][j+lower_j][k]==Organ_ID){original_binary_matrix[i][j]=0; Length++;
 } else { original_binary_matrix[i][j]=1;}}}
binary_matrix= original_binary_matrix;
if (Length >0) {
while (previousarea>0 or activate==true) {
activate=false;
minw=0;
it=0;
area=0;
area_max=0;
First_Point_Y=0;
First_Point_X=0;
Second_Point_Y=0;
Second_Point_X=0;
Third_Point_Y=0;
Third_Point_X=0;
Fourth_Point_Y=0;
Fourth_Point_X=0;
for (int i=0; i<   higher_i-lower_i+1 ; i++)  
{
for (int j= 0; j<  higher_j-lower_j+1 ; j++)  
{
matrix_Height[i][j]=0; 
matrix_Width[i][j]=0;}}

//BEGIN: CalculateArea
activate=true;
for (int i=0; i<   higher_i+1-lower_i ; i++)  
{
for (int j= 0; j<  higher_j+1-lower_j ; j++)    
{//2
if( binary_matrix[i][j] ==skip) { continue; };
if (i==0) {matrix_Height[i][j]=1;} else {matrix_Height[i][j]=matrix_Height[i-1][j]+1; };
if (j==0) { matrix_Width[i][j]=1;} else {matrix_Width[i][j]=matrix_Width[i][j-1]+1; minw=matrix_Width[i][j];}
for (int it=0; it< matrix_Height[i][j]; it++) 
{//3
minw = min(minw, matrix_Width[i-it][j]);
area = (it+1)*minw;
if (area >area_max)
{//4
 area_max = area; 
 First_Point_X=i-it;
 First_Point_Y=j-minw+1 ;
 Second_Point_X=i;
 Second_Point_Y=j-minw+1;
 Fourth_Point_X=i;
 Fourth_Point_Y=j;
 Third_Point_X=i-it;
 Third_Point_Y=j ;
};}} }
if (area>= 2) 
 {
previousarea= area;
 int width = (Second_Point_X-First_Point_X+1);
 int height = (Third_Point_Y-First_Point_Y+1);
id++;
max_area_array.push_back(width*height);
//----------begin ConstructPhysicalVolume-----------

Total_Number_Of_Merged_Voxels+=width*height;
G4double z_center_pos = ((k+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM;
G4double  P1XOrigin=-0.5*PHANTOM_X_DIM   + (First_Point_X+0.5+lower_i)*VOXEL_X_DIM;
G4double  P2XOrigin=-0.5*PHANTOM_X_DIM+  (Second_Point_X+0.5+lower_i)*VOXEL_X_DIM;
G4double  P1YOrigin= -0.5*PHANTOM_Y_DIM+  (First_Point_Y+0.5+lower_j)*VOXEL_Y_DIM;
G4double  P4YOrigin= -0.5*PHANTOM_Y_DIM+  (Fourth_Point_Y+0.5+lower_j)*VOXEL_Y_DIM;
G4double x_center_pos =0.5*(P1XOrigin+P2XOrigin);
G4double y_center_pos =0.5*(P1YOrigin+P4YOrigin);
NumberOfVoxelsMerged+=width*height;
PhysicsData+=std::to_string(First_Point_X+lower_i)+":"+std::to_string(First_Point_Y+lower_j)+":"+std::to_string(Second_Point_X+lower_i)+":"+std::to_string(Fourth_Point_Y+lower_j)+'\t';
solid_data+=std::to_string(width)+"x"+std::to_string(height)+"\t";
logical_data+=
std::to_string(Organ_ID)+"x"+std::to_string(width)+"x"+std::to_string(height)+"\t";


//--------end ConstructPhysicalVolume-----------------

for (int i = First_Point_X; i < Second_Point_X +1; i++)
{ 
for (int j = First_Point_Y; j < Third_Point_Y+1; j++) 
{
binary_matrix[i][j]=skip ; 
}} }
//END: CalculateArea

if (area<2) {
//BEGIN: ConstructPhysicalVolumeForNoMergedVoxels()
for (int i=0; i<   higher_i+1-lower_i ; i++)  
{
for (int j= 0; j<  higher_j+1-lower_j ; j++)  
{//2
if( binary_matrix[i][j] ==0) {
PhysicsData+=std::to_string(i+lower_i)+"#"+std::to_string(j+lower_j)+'\t';
G4double z_center_pos = -0.5*PHANTOM_Z_DIM+(k+0.5)*VOXEL_Z_DIM;
G4double x_center_pos =-0.5*PHANTOM_X_DIM+ (i+0.5+lower_i)*VOXEL_X_DIM     ;
G4double y_center_pos = -0.5*PHANTOM_Y_DIM+ (j+0.5+lower_j)*VOXEL_Y_DIM   ;
//---bEGIN------------ ConstructLogicalVolume( 1,  1 )
solid_data+="1x1\t";
logical_data+=std::to_string(Organ_ID)+"x1x1\t";
//-----------eND-------------- ConstructLogicalVolume( 1,  1 )
Total_Number_Of_noMerged_Voxels++;
};}}
//END: ConstructPhysicalVolumeForNoMergedVoxels
break; }}}
 binary_matrix=0;
 original_binary_matrix=0;
matrix_Height =0;
 matrix_Width=0 ;}

//PhysicsData+="\n";
}
int max_area_in_organ=0;
  if (max_area_array.size() > 0){ max_area_in_organ = *max_element(max_area_array.begin(),max_area_array.end());} 
DataToPass.push_back(to_string(max_area_in_organ));
DataToPass.push_back(to_string(Total_Number_Of_Merged_Voxels));
DataToPass.push_back(to_string(Total_Number_Of_noMerged_Voxels));
DataToPass.push_back(solid_data.c_str());
DataToPass.push_back(logical_data.c_str());

DataToPass.push_back(PhysicsData);
//cout<<"DataToPass[0]=="  <<  DataToPass[0] << endl;
G4AutoLock _mz(&OPTIM_Z_Mutex);
results.push_back(DataToPass);
_mz.unlock();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetNumberOfPhantomOrgans (int _number) 
{
this->NumberOfPhantomOrgans=_number;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int * VoxIsle::LowerHeigherXID( int organ_id, int ***& Voxels)
{
int*  LowerHeigherXID = new int [2];
vector<int> array_xid;

for (int ix=0; ix<this->Number_Of_Voxels_Along_x; ix++)
{
for (int iz=0; iz< this->Number_Of_Voxels_Along_z; iz++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
if (Voxels[ix][iy][iz]==(organ_id))
{
array_xid.push_back(ix);

}
}}}
LowerHeigherXID[0] =  *min_element(array_xid.begin(), array_xid.end());
LowerHeigherXID[1] =  *max_element(array_xid.begin(), array_xid.end());
return LowerHeigherXID;
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int * VoxIsle::LowerHeigherYID( int organ_id, int ***& Voxels)
{
int*  LowerHeigherYID = new int [2];
vector<int> array_yid;

for (int iz=0; iz<this->Number_Of_Voxels_Along_z; iz++)
{
for (int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
if (Voxels[ix][iy][iz]==(organ_id))
{
array_yid.push_back(iy);

}
}}}
LowerHeigherYID[0] =  *min_element(array_yid.begin(), array_yid.end());
LowerHeigherYID[1] =  *max_element(array_yid.begin(), array_yid.end());
return LowerHeigherYID;
}


/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int * VoxIsle::LowerHeigherZID( int organ_id, int ***& Voxels)
{
int*  LowerHeigherZID = new int [2];
vector<int> array_zid;

for (int iz=0; iz<this->Number_Of_Voxels_Along_z; iz++)
{
for (int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
if (Voxels[ix][iy][iz]==(organ_id))
{
array_zid.push_back(iz);

}
}}}
LowerHeigherZID[0] =  *min_element(array_zid.begin(), array_zid.end());
LowerHeigherZID[1] =  *max_element(array_zid.begin(), array_zid.end());
return LowerHeigherZID;
}
//*---------------------------------------*/
G4double VoxIsle::GetOrganTotalVoxels(const   int   organ_id, int ***&Voxels) {
int NumberOfVoxelsInCurrentOrgan=0;
for ( int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for ( int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
for ( int iz=0; iz< this->Number_Of_Voxels_Along_z; iz++){
{
if (Voxels[ix][iy][iz]==organ_id)
{ NumberOfVoxelsInCurrentOrgan++; }}}};}
return   NumberOfVoxelsInCurrentOrgan;
}
//-----------------------------------------------------------//

void VoxIsle::Apply(int ***&Voxels)
{//0
int TotalNumberOfMergedVoxles=0;
int TotalNumberOfNoMergedVoxles=0;
 NumberOfVoxelsMerged=0;
G4Timer * myTimer= new G4Timer();
myTimer->Start();
cout<<"===InterDosi  VoxIsle technique is activated." << endl;
 std::ofstream IrVoxFile;
IrVoxFile.open(this->PhantomName+".irvox", std::ios::out);
string _val= "VOXEL_DIMENSIONS (mm, mm, mm)\t"+to_string(this->VOXEL_X_DIM)+"|"+to_string(this->VOXEL_Y_DIM)+"|"+to_string(this->VOXEL_Z_DIM)+"\nPHANTOM_DIMENSIONS  (mm, mm, mm)\t"+to_string(this->PHANTOM_X_DIM)+"|"+to_string(this->PHANTOM_Y_DIM)+"|"+to_string(this->PHANTOM_Z_DIM)+"\n";


IrVoxFile<< _val.c_str();
string data_to_irvox="";
long double remaing_word_volume=0.0;
long double whole_body_volume=0.0;
int TotNonUnifromVoxels=0;
int TotUnifromVoxels=0;
 int TotalNumberOfElments=0;
int Organ_ID=-1;
vector<string> axis_flag_array;
int f=-1;
string   data_statistcs="";
int num_threads= this->NumberOfPhantomOrgans-1;
//std::vector<std::thread> threads_x(num_threads);
//std::vector<std::thread> threads_y(num_threads);
std::vector<std::thread> threads_z(num_threads);
string all_physical_data="";
vector<vector<std::string>> results, results_x, results_y,results_z;
//vector<vector<std::string>> results (num_threads,vector<std::string>(3));
incrementor=-1;
G4Timer * myTimer1= new G4Timer();
myTimer1->Start();
for (int i=0; i < this->NumberOfPhantomOrgans; i++) 
{//1
 Organ_ID=this->ArrayOrgansIds[i];
Total_Number_Of_noMerged_Voxels=0;
Total_Number_Of_Merged_Voxels=0;
if (Organ_ID!=this->BackgroundID) {//2
int * data_z= LowerHeigherZID(Organ_ID, Voxels);
int  min_iz=data_z[0] ;
int max_iz=data_z[1]  ;
f++;
incrementor++;

threads_z[incrementor]= std::thread  (&VoxIsle::ApplyParallelVoxelIslandMethod,this,std::ref(Voxels),Organ_ID,  min_iz, max_iz,  Number_Of_Voxels_Along_x,  Number_Of_Voxels_Along_y,  Number_Of_Voxels_Along_z,  VOXEL_X_DIM,  VOXEL_Y_DIM,  VOXEL_Z_DIM, PHANTOM_X_DIM,  PHANTOM_Y_DIM,  PHANTOM_Z_DIM, std::ref(results),  incrementor );
threads_z[ incrementor].join();


}//2
 myTimer1->Stop();

}//1
cout <<"===InterDosi  VoxIsle data processing CPU time(s) " <<myTimer1->GetRealElapsed() << endl;;
int l=-1;

string  all_solid_data="";
string all_logical_data="";

for (int i=0; i < this->NumberOfPhantomOrgans; i++) 
{
 Organ_ID=this->ArrayOrgansIds[i];
if (Organ_ID!=this->BackgroundID) {//2
l++;
vector<int> dd;
string axis_flag="";
all_solid_data+= results[l][3];
all_logical_data+= results[l][4];
all_physical_data+="\nORGAN_ID\t"+to_string(Organ_ID)+results[l][5];
TotUnifromVoxels+=GetOrganTotalVoxels(Organ_ID,Voxels) ;
TotalNumberOfMergedVoxles+=stoi(results[l][1]);
TotalNumberOfNoMergedVoxles+=stoi(results[l][2]);
float compr_cent=100* stoi(results[l][1]) /(float)(stoi(results[l][1])+stoi(results[l][2]) );
data_statistcs+="===InterDosi  ORGAN_ID="+to_string(Organ_ID)+", voxel compression percent= "+to_string(compr_cent )+"%\n";
float TotalOrganVolume=( stoi(results[l][1])+stoi(results[l][2]))* this->VOXEL_X_DIM* this->VOXEL_Y_DIM* this->VOXEL_Z_DIM*0.001;//cm***3
 whole_body_volume+=TotalOrganVolume;
IrVoxVolumeSize+=std::to_string(TotalOrganVolume)+"\t";
}
}
vector<string>  array_total_solids;
list<string>  list_total_solids;
split(all_solid_data, '\t', array_total_solids);
for (int i=0; i<array_total_solids.size(); i++ )  {
list_total_solids.push_back(array_total_solids[i]);
}

list_total_solids.sort();
list_total_solids.unique();
string  solid_data="";
for (list<string>::iterator it=list_total_solids.begin(); it!=list_total_solids.end(); ++it){ 
solid_data+=*it+"\t";
}
vector<string>  array_total_logicals;
list<string>  list_total_logicals;
split(all_logical_data, '\t', array_total_logicals);
int  size_logical_data= array_total_logicals.size();
for (int i=0; i<array_total_logicals.size(); i++ )  {
list_total_logicals.push_back(array_total_logicals[i]);
}
remaing_word_volume= 0.001* (PHANTOM_X_DIM *PHANTOM_Y_DIM*PHANTOM_Z_DIM) -whole_body_volume;

//-write irvox file
IrVoxFile<<  "WORLD_VOLUME (VOL(cm^3),ID )\n " << remaing_word_volume<< "\t" << this->BackgroundID  <<endl;
IrVoxFile<<  "DIM_VOLUMES (cm^3)\n " << IrVoxVolumeSize<<endl;
IrVoxFile<<  "SOLID_VOLUMES " << list_total_solids.size() <<endl;
IrVoxFile<<  solid_data  <<endl;
list_total_logicals.sort();
list_total_logicals.unique();
IrVoxFile<<  "LOGICAL_VOLUMES " <<  list_total_logicals.size()  <<endl;
int _id =-1;
//-----------------------------------------------------------
for (list<string>::iterator it=list_total_logicals.begin(); it!=list_total_logicals.end(); ++it)
{ //1
vector<string> row_values;
split(*it, 'x', row_values);
int organ_id=std::stoi(row_values[0]);
for (list<string>::iterator it1=list_total_solids.begin(); it1!=list_total_solids.end(); ++it1)
{//2
_id++;
std::string  vox_str=row_values[1]+"x"+row_values[2];
if (*it1==vox_str ) {//3
break;
}}//2  3
IrVoxLogicalVolData+=std::to_string(organ_id)+"@"+std::to_string(_id)+"\t";
_id=-1;
}//1
//-----------------------------------------------------------------------
IrVoxFile<<   IrVoxLogicalVolData.c_str()  <<endl;
IrVoxFile <<all_physical_data ;
IrVoxFile.close();
data_to_irvox="";
 myTimer->Stop();
std::ofstream  outFile;
outFile.open( this->PhantomName+".irvox_info",std::ios::out );
outFile <<"===InterDosi  VoxIsle data processing CPU time(s) " <<myTimer->GetRealElapsed() <<G4endl;
outFile << "===InterDosi  Number of constructed solid volumes: "<<   list_total_solids.size()  << endl;
outFile<<"===InterDosi  Total number of whole body uniform voxels: "<< TotUnifromVoxels<< endl;
outFile<<data_statistcs<< endl;
outFile<<"===InterDosi  Total number of no merged voxels: "<<TotalNumberOfNoMergedVoxles<< endl;
outFile<<"===InterDosi  Total number of merged voxels: "<< TotalNumberOfMergedVoxles << endl;
outFile<<"===InterDosi  Percent of merged voxels is:  "<< 100*((TotalNumberOfMergedVoxles)/(double) (TotalNumberOfMergedVoxles+TotalNumberOfNoMergedVoxles))<<"% of the total number of the uniform voxels." << endl;
outFile.close();
cout<<"===InterDosi  Contruction of IrVox phantom was done successfully. "<< endl;
cout << "===InterDosi Please check the file :" <<this->PhantomName<<".irvox_info located in InterDosi/inputs/IRVOXPhantom_files" << endl;
ArrayLogicalVolumeName.clear();
ArraySolidVolumeName.clear();
}
//-----------------------------------------------------------//

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void VoxIsle::SetArrayOrgansIds(vector<int> _data){
this-> ArrayOrgansIds= _data;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string VoxIsle::GetIrVoxData(){
return  IrVoxData;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void  VoxIsle::SetPhantomName (std::string name) {
this->PhantomName= name;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  VoxIsle::split(const std::string &s, char delim, std::vector<std::string> &elems) 
{
std::stringstream ss;
ss.str(s);
std::string item;
while (std::getline(ss, item, delim)) 
{
elems.push_back(item);
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
