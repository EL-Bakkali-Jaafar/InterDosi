/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#include "G4RunManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h> 
#include <iterator>
#include <stdlib.h>
#include <vector>
#include "G4tgbGeometryDumper.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
#include "DetectorMessenger.hh"
#include "G4TransportationManager.hh"
#include "G4tgbVolumeMgr.hh"
#include "G4UserLimits.hh"
#include "G4tgrMessenger.hh"
#include "G4tgbMaterialMgr.hh"
#include "G4LogicalVolumeStore.hh"
#include <iostream>       
#include <cstddef>          
#include "G4ProductionCuts.hh"
#include "G4RegionStore.hh"
#include "G4Timer.hh"
#include "G4PhantomParameterisation.hh"
#include "G4PVParameterised.hh"
#include "G4SubtractionSolid.hh"
#include "PhantomSD_IrvoxNav.hh"
#include <boost/algorithm/string.hpp>
#include "VoxIsle.hh"
#include "PhantomSD_RegularNav.hh"
#include <parallel-util.hpp>
#include "G4AutoDelete.hh"
#include "G4GlobalMagFieldMessenger.hh"
#include "G4FieldManager.hh"
#include "G4UniformMagField.hh"
#include <vector>
using namespace                     std    ;
int incremetor                      = 0    ;
int  incrementor1                   = 0    ;
int NumberOfElements                = 0    ;
int NuMbeRoFmAtErIaL                = 0    ;
int incr                            = 0    ;
int  NumberOfConstructedVoxels      = 0    ;
static int total_number_of_voxels   = 0    ;

int lm                              = 0    ;
int rr                              = 0    ;
bool visualization                  = false;
VoxIsle *myVoxIsle;
std::ofstream  IrVoxFile;
std::string  data_to_irvox;
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4ThreeVector  DetectorConstruction::GetVoxelIndices(int copyNumber){
int  nx = int(copyNumber%this->Number_Of_Voxels_Along_x);
int  ny = int( (copyNumber/this->Number_Of_Voxels_Along_x)%this->Number_Of_Voxels_Along_y );
int  nz = int( (copyNumber/(this->Number_Of_Voxels_Along_x*this->Number_Of_Voxels_Along_y)) %this->Number_Of_Voxels_Along_z  );
return G4ThreeVector(nx, ny,nz);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::setScoreDosePerVoxel(bool _ScoreDosePerVoxel )
{
this->ScoreDosePerVoxel= _ScoreDosePerVoxel ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ReadMaterialDataFromFile(const G4String _MaterialFile)
{//1
material_density*= g/cm3;
ifstream MaterialDataFromFileStream ;
int i=-1;
MaterialDataFromFileStream .open(_MaterialFile.c_str());
string STR;
while ( getline(MaterialDataFromFileStream ,STR))
{//2
vector<string>  _result;
istringstream  _iss(STR);
i++;
for(string  _s_data;  _iss >>  _s_data; )
{//3
_result.push_back( _s_data);
}//3
if (i==0) 
{//4
material_name= _result[0];
material_density =stod(  _result[1]);
number_of_elements_in_material=stoi(  _result[2]);
_ELEMENT_DATA = new  ELEMENT_DATA[number_of_elements_in_material];
}//4
if (i>0) 
{//5
_ELEMENT_DATA[i-1].FRACTION =stod(_result[1]);
_ELEMENT_DATA[i-1].ELEMENT= _result[0];
}//5
} //2
MaterialDataFromFileStream.close();
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Material *DetectorConstruction::CreateMaterial(const G4String _MaterialName)
{
#include <unistd.h>
char cwd[1024];
getcwd(cwd, sizeof(cwd));
std::string InterDosiPath;
std::stringstream ss;
ss << cwd;
ss >> InterDosiPath;				  // or s = ss.str();
string toErase= "/bin/VoxGeoSAFs.bin";
size_t pos = InterDosiPath.find(toErase);
InterDosiPath.erase(pos, toErase.length());
std::string material_file= InterDosiPath+"/core/MaterialsDB/"+_MaterialName+".mat";
ifstream File;
bool file_exit;
File.open(material_file.c_str());
file_exit = File.good();
if (file_exit==false) {
G4cout <<"===InterDosi    Error: the material file named:" <<material_file <<" does not exist." <<G4endl;
exit(0);
} else {
ReadMaterialDataFromFile(material_file);
G4Material * myMaterial = new G4Material(_MaterialName,material_density*g/cm3,  number_of_elements_in_material );
for ( int i=0; i< number_of_elements_in_material;i++) {
myMaterial->AddElement(  G4NistManager::Instance()->FindOrBuildElement(_ELEMENT_DATA[i].ELEMENT),   _ELEMENT_DATA[i].FRACTION);
}
return myMaterial ;
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
  int  DetectorConstruction::OrganeID(const string OrganeName)
{
  int   _ORGAN_ID=0;
for (  int  i=0; i < this->NumberOfPhantomOrgans; i++)
{
if (_VoxelizedPhantomStruc[i].ORGAN_NAME==OrganeName) {_ORGAN_ID=_VoxelizedPhantomStruc[i].ORGAN_ID;
};
}
return _ORGAN_ID;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::CheckTheValidityOfOrganRegionName(std::string _OrganRegionName )
 {
std::string no_permitted_char="-";
    bool b = boost::algorithm::contains(_OrganRegionName, no_permitted_char);
if (b==true)
{
G4cout <<"===InterDosi    Error: the organ/region named:" <<_OrganRegionName <<" should not contain '-' char."<< G4endl;
exit(0);     
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
 string  DetectorConstruction::GetMaterialName(const int OrganeId)
{
string _ORGAN_MATERIAL="";
for (  int  i=0; i < this->NumberOfPhantomOrgans; i++)
{
if (_VoxelizedPhantomStruc[i].ORGAN_ID==OrganeId) {_ORGAN_MATERIAL=_VoxelizedPhantomStruc[i].ORGAN_MATERIAL;
} 
}
return _ORGAN_MATERIAL;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
string  DetectorConstruction::OrganeName(const   int OrganeId)
{
string  _ORGAN_NAME="";
for (  int   i=0; i < this->NumberOfPhantomOrgans; i++)
{
if (_VoxelizedPhantomStruc[i].ORGAN_ID==OrganeId)
{_ORGAN_NAME=_VoxelizedPhantomStruc[i].ORGAN_NAME;
};
}
return _ORGAN_NAME;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Colour DetectorConstruction::OrganeColor(const   int  OrganeId)
{
int  Organ_Color_R=0;
int  Organ_Color_G=0;
int  Organ_Color_B=0;
for (  int  i=0; i < NumberOfPhantomOrgans; i++)
{
if (_VoxelizedPhantomStruc[i].ORGAN_ID==OrganeId) {
Organ_Color_R =_VoxelizedPhantomStruc[i].ORGAN_COLOR_R;
Organ_Color_G =_VoxelizedPhantomStruc[i].ORGAN_COLOR_G;
Organ_Color_B =_VoxelizedPhantomStruc[i].ORGAN_COLOR_B;
};
}
return  G4Colour(Organ_Color_R/255.,Organ_Color_G/255.,Organ_Color_B/255.);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Material * DetectorConstruction::MaterialName(const   int OrganId)
{
string _ORGAN_MATERIAL=GetMaterialName(OrganId);
int mat_id=-1;
for (  int  j=0; j <  ArrayMat.size(); j++)
{
if (_ORGAN_MATERIAL == ArrayMat[j]->GetName().c_str()) {mat_id =j;}

}
return ArrayMat[mat_id] ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_kinetic_energy(G4double _kinetic_energy)
{ 
this->kinetic_energy=_kinetic_energy;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetPhantomDescriptorFileFullPath(string  _PhantomDescriptorFileFullPath) {
this->PhantomDescriptorFileFullPath = _PhantomDescriptorFileFullPath;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::DetectorConstruction(): G4VUserDetectorConstruction()
{
pDetectorMessenger= new DetectorMessenger(this); 
this->BackgroundID=-1;
this->SkipEqualMaterials=false;
voxphantomtype="ijkid";
remaing_word_volume=0.0;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetSliceId(   int  _SliceId)
{
this->SliceId=_SliceId;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetBackgroundID(   int  _BackgroundID)
{
this->BackgroundID=_BackgroundID;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetNumberOfThreads(   int  _NumberOfThread)
{
this->NumberOfThread=_NumberOfThread;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetParticleRecyclingFactor(   int  _ParticleRecyclingFactor)
{
this->ParticleRecyclingFactor=_ParticleRecyclingFactor;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorConstruction::~DetectorConstruction()
{ 
PhysicsVolPosList.clear();   
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
  int  DetectorConstruction::FindIteratorFromOrganIds( vector<   int> array,    int  _organ_id)
{
  int  result=0;

for (  int  i=0; i <array.size(); i++) { if (array[i]== _organ_id) {result=i ;} };

return result;
}
/*#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetupVoxelizedPhantomParametersForIrVoxFormat()
{
this->VOXEL_X_DIM=PHANTOM_X_DIM/(G4double)this->Number_Of_Voxels_Along_x; 
this->VOXEL_Y_DIM=PHANTOM_Y_DIM/(G4double)this->Number_Of_Voxels_Along_y; 
this->VOXEL_Z_DIM=PHANTOM_Z_DIM/(G4double)this->Number_Of_Voxels_Along_z; 
for (list<string>::iterator it=MaterialsList.begin(); it!=MaterialsList.end(); ++it){ 
G4Material * mat = CreateMaterial(*it);
ArrayMat.push_back(mat);  
NuMbeRoFmAtErIaL++;
}
this->runManager = G4RunManager::GetRunManager();
G4bool checkOverlaps = true;

world_mat =CreateMaterial(this->WorldMat);
solidWorld =new G4Box("SolidWorld",  this->WorldDimX/2., this->WorldDimY/2.,  this->WorldDimZ/2.);  
logicWorld =  new G4LogicalVolume(solidWorld,world_mat, to_string(this->BackgroundID)+"_LogicalWorld");      
  G4VisAttributes* motherAttr = new G4VisAttributes(G4Color(1., 0., 0.));
motherAttr->SetForceWireframe (true);
logicWorld ->SetVisAttributes(motherAttr);   
this->physWorld =  new G4PVPlacement(0,G4ThreeVector(),logicWorld,"PhysicalWorld",0, false, 0,checkOverlaps);  
ReadIrVoxData(this->PhantomFileDir.c_str());




}
/*#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4VPhysicalVolume* DetectorConstruction::Construct()
{//1  
this->NumberOfPhantomAnatomicalRegions=0;
myTimer= new G4Timer();
myTimer->Start();
this->AnatomicalRegion="";
NumberOfPhantomAnatomicalRegions=0;
ReadVoxelizedPhantomParameters();
voxphantomtype = VoxelizedPhantomType(this->PhantomFileName);
string   _InterDosiDirectory = InterDosiDirectory();
if (voxphantomtype=="ijkid") {
this->PhantomFileDir=_InterDosiDirectory+"/inputs/IJKIDPhantom_files/"+this->PhantomFileName; 
SetupVoxelizedPhantomParametersForIjkidFormat();

for (  int  i=0; i< this->NumberOfPhantomOrgans;  i++)
{
int  organ_id            = ArrayOrgansIds[i];
ArrayOrgansVolumes[i]    = GetOrganTotalVoxelizedVolumeFromId(organ_id);
ArrayOrgansVoxels[i]     = GetOrganTotalVoxels(organ_id);
ArrayOrgansDensities[i]  = GetOrganeDensity(organ_id);
MapOrganIdsIterators[organ_id] = OrganIDtoIterator(_VoxelizedPhantomStruc[i].ORGAN_ID);
MapOrganIdsToMaterialIds[organ_id] = OrganIDtoMaterialID(_VoxelizedPhantomStruc[i].ORGAN_ID);
}
if (this->NumberOfPhantomAnatomicalRegions> 0) {
// initialization
for (  int  i=0; i<this->NumberOfPhantomAnatomicalRegions;  i++) {
ArrayRegionsVolumes[i] = 0.0;
ArrayOrgansMasses[i]   = 0.0;
ArrayRegionsVoxels[i]  = 0;
}
//fill data
for (  int  i=0; i< this->NumberOfPhantomAnatomicalRegions;  i++) {
for (  int  j=0; j< _VoxelizedPhantomRegStruc[i].ARRAY_ORGAN_IDS.size(); j++)
{
  int  organ_id= _VoxelizedPhantomRegStruc[i].ARRAY_ORGAN_IDS[j];
  int  iterator = FindIteratorFromOrganIds( ArrayOrgansIds, organ_id);
ArrayRegionsVolumes[i] += ArrayOrgansVolumes[iterator];
ArrayOrgansMasses[i]   += ArrayOrgansDensities[iterator]*ArrayOrgansVolumes[iterator]/(double)1000;//g/cm^3;
ArrayRegionsVoxels[i]  += ArrayOrgansVoxels[iterator];
}
}
}
this->runManager = G4RunManager::GetRunManager();
G4bool checkOverlaps = true;
world_mat = CreateMaterial(this->WorldMat);

solidWorld =new G4Box("SolidWorld",  this->WorldDimX/2., this->WorldDimY/2.,  this->WorldDimZ/2.);  
logicWorld =  new G4LogicalVolume(solidWorld,world_mat,"LogicalWorld");      
  G4VisAttributes* motherAttr = new G4VisAttributes(G4Color(1., 0., 0.));
motherAttr->SetForceWireframe (true);
logicWorld ->SetVisAttributes(motherAttr);   
this->physWorld =  new G4PVPlacement(0,G4ThreeVector(),logicWorld,"PhysicalWorld",0, false, 0,checkOverlaps);        

if (this->Projection=="none")  
{
//contruct points belonging to organ source.
for (int i=0; i < this->Number_Of_Voxels_Along_x; i++){
for (int j=0; j < this->Number_Of_Voxels_Along_y; j++){
for (int k=0; k < this->Number_Of_Voxels_Along_z; k++){

if (this->SelectRegion==false) 
{//1
if ( OrganeName(Voxels[i][j][k] ) == this->SourceOrganeName)
{//2
G4double x_center_pos = (i+0.5)*VOXEL_X_DIM  - 0.5*PHANTOM_X_DIM;
G4double y_center_pos = (j+0.5)*VOXEL_Y_DIM - 0.5*PHANTOM_Y_DIM;
G4double z_center_pos = (k+0.5)*VOXEL_Z_DIM - 0.5*PHANTOM_Z_DIM;
PhysicsVolPosList.push_back(G4ThreeVector(x_center_pos,y_center_pos,z_center_pos));
}//2
}//1
else
{//3
for (int l=0; l< this->NumberOfPhantomAnatomicalRegions; l++)
{//4
if (_VoxelizedPhantomRegStruc[l].REGION_NAME==this->SourceOrganeName)
{//5

for (int m=0; m< _VoxelizedPhantomRegStruc[l].ARRAY_ORGAN_IDS.size(); m++) 
{//6
if ( Voxels[i][j][k]  == _VoxelizedPhantomRegStruc[l].ARRAY_ORGAN_IDS[m])
{//7
G4double x_center_pos = (i+0.5)*VOXEL_X_DIM  - 0.5*PHANTOM_X_DIM;
G4double y_center_pos = (j+0.5)*VOXEL_Y_DIM - 0.5*PHANTOM_Y_DIM;
G4double z_center_pos = (k+0.5)*VOXEL_Z_DIM - 0.5*PHANTOM_Z_DIM;
PhysicsVolPosList.push_back(G4ThreeVector(x_center_pos,y_center_pos,z_center_pos));
}//7
}//6
}//5
}//4
}//3
}}}
visualization=false;
Construct_Phantom_With_Regular_Navigation( );
} else {

visualization=true;

Construct_Partial_Phantom(this->SliceId) ;}



} else {

this->PhantomFileDir=_InterDosiDirectory+"/inputs/IRVOXPhantom_files/"+this->PhantomFileName; 

SetupVoxelizedPhantomParametersForIrVoxFormat();


for (  int  i=0; i< this->NumberOfPhantomOrgans;  i++)
{
int  organ_id            = ArrayOrgansIds[i];
if (organ_id==this->BackgroundID) 
{
ArrayOrgansVolumes[i]= this->WorldMathVolume;
 ArrayOrgansDensities[i]  =GetOrganeDensity (organ_id);
}  else
{
ArrayOrgansVolumes[i]    = ArrayIrVoxOrganeVolume[i-1];
 ArrayOrgansDensities[i]  = GetOrganeDensity(organ_id);
}
MapOrganIdsIterators[organ_id] = OrganIDtoIterator(_VoxelizedPhantomStruc[i].ORGAN_ID);
MapOrganIdsToMaterialIds[organ_id] = OrganIDtoMaterialID(_VoxelizedPhantomStruc[i].ORGAN_ID);
}
if (this->NumberOfPhantomAnatomicalRegions> 0) {
// initialization
for (  int  i=0; i<this->NumberOfPhantomAnatomicalRegions;  i++) {
ArrayRegionsVolumes[i] = 0.0;
ArrayOrgansMasses[i]   = 0.0;
ArrayRegionsVoxels[i]  = 0;
}
//fill data
for (  int  i=0; i< this->NumberOfPhantomAnatomicalRegions;  i++) {
for (  int  j=0; j< _VoxelizedPhantomRegStruc[i].ARRAY_ORGAN_IDS.size(); j++)
{
int  organ_id= _VoxelizedPhantomRegStruc[i].ARRAY_ORGAN_IDS[j];
int  iterator = FindIteratorFromOrganIds( ArrayOrgansIds, organ_id);
ArrayRegionsVolumes[i] += ArrayOrgansVolumes[iterator];
ArrayOrgansMasses[i]   += ArrayOrgansDensities[iterator]*ArrayOrgansVolumes[iterator]/(double)1000;//g/cm^3;
ArrayRegionsVoxels[i]  += ArrayOrgansVoxels[iterator];
}
}
}
}
myTimer->Stop();
G4cout <<"===InterDosi    Elapsed time to construct voxels  (seconds): " <<myTimer->GetRealElapsed()<<G4endl;
 
return this->physWorld;
}


//*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::setSkipEqualMaterials(bool _SkipEqualMaterials){

this->SkipEqualMaterials = _SkipEqualMaterials;
}
//*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructSDandField()
{
if (visualization==false) {
if (voxphantomtype=="ijkid") {
G4ThreadLocal PhantomSD_RegularNav *mSD;
G4SDManager* pSDManager ;
 pSDManager = G4SDManager::GetSDMpointer();
pSDManager->SetVerboseLevel(3);
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
mSD = new PhantomSD_RegularNav(this->PhantomName+str_thread);
mSD->SetVerboseLevel(3);
pSDManager-> AddNewDetector(mSD);
SetSensitiveDetector("PhantomContainer",mSD);
SetSensitiveDetector("LogiVoxel",mSD);





} else {
G4ThreadLocal PhantomSD_IrvoxNav *mSD;
G4SDManager* pSDManager ;
 pSDManager = G4SDManager::GetSDMpointer();
pSDManager->SetVerboseLevel(3);
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
mSD = new PhantomSD_IrvoxNav(this->PhantomName+str_thread);
mSD->SetVerboseLevel(3);


pSDManager-> AddNewDetector(mSD);

const G4LogicalVolumeStore* lvs = G4LogicalVolumeStore::GetInstance();
std::vector<G4LogicalVolume*>::const_iterator lvciter;


for( lvciter = lvs->begin(); lvciter != lvs->end(); lvciter++ )
{ 
SetSensitiveDetector( (*lvciter)->GetName(),mSD);



}
}


}

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetProjection(string  _Projection) {
this->Projection = _Projection;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::set_particle_name(string  _particle_name) {
this->particle_name = _particle_name;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganeDensity(  int   _organ_id) {
G4double density=0.0*g/cm3;
density= MaterialName(_organ_id)->GetDensity();
return density/(g/cm3) ;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganTotalVoxels(const   int   organ_id) {
int NumberOfVoxelsInCurrentOrgan=0;
for ( int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for ( int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
for ( int iz=0; iz< this->Number_Of_Voxels_Along_z; iz++){
{
if (Voxels[ix][iy][iz]==organ_id)
{ NumberOfVoxelsInCurrentOrgan++; }}}};}
return   NumberOfVoxelsInCurrentOrgan;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganTotalVoxelizedVolumeFromId(const   int   organ_id) {
int NumberOfVoxelsInCurrentOrgan=0;
G4double _OrganTotalVoxelizedVolume=0.0;
for (  int  ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (  int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
for (  int  iz=0; iz< this->Number_Of_Voxels_Along_z; iz++){
{
if (Voxels[ix][iy][iz]==organ_id)
{ 
NumberOfVoxelsInCurrentOrgan++;  }}}};}
_OrganTotalVoxelizedVolume=NumberOfVoxelsInCurrentOrgan* VOXEL_X_DIM*VOXEL_Y_DIM*VOXEL_Z_DIM;
return   _OrganTotalVoxelizedVolume/( cm* cm* cm);// cm3
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string DetectorConstruction::InterDosiDirectory(){
std::string _InterDosiDir="Unresolved";
char buffer[256];
char *val = getcwd(buffer, sizeof(buffer));
if (val) {
_InterDosiDir = buffer;

 string toErase= "/bin/VoxGeoSAFs.bin";
size_t pos = _InterDosiDir.find(toErase);
_InterDosiDir.erase(pos, toErase.length());
    std::cout <<"===InterDosi    Current directory: "<< _InterDosiDir << std::endl;
}
return _InterDosiDir;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4double DetectorConstruction::GetOrganTotalVoxelizedVolume(const string _OrganTotalVoxelizedVolumeName) {
int NumberOfVoxelsInCurrentOrgan=0;
G4double _OrganTotalVoxelizedVolume=0.0;
for ( int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for ( int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
for ( int iz=0; iz< this->Number_Of_Voxels_Along_z; iz++){
{if (OrganeName(Voxels[ix][iy][iz])==_OrganTotalVoxelizedVolumeName )
{ NumberOfVoxelsInCurrentOrgan++;  }}}};}
_OrganTotalVoxelizedVolume=NumberOfVoxelsInCurrentOrgan* VOXEL_X_DIM*VOXEL_Y_DIM*VOXEL_Z_DIM;
return _OrganTotalVoxelizedVolume/( cm* cm* cm);// cm3
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
  int  DetectorConstruction::OrganIDtoIterator(  int   _OrganID)
{  int  result=-2;
for (  int  Iterator=0; Iterator< this->NumberOfPhantomOrgans; Iterator++) {
if (_VoxelizedPhantomStruc[Iterator].ORGAN_ID==_OrganID) { result=Iterator;} }
if (result==-2) { //cout <<  "organ id not found, OrganID="<< _OrganID << endl;
//cout <<  "organ id was replaced by backgroud id" << endl;
result=this->BackgroundID;

}
return result;}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::ConstructLogicalVolumes(G4String _SourceOrganeName){
 tmp.reserve(this->NumberOfPhantomOrgans);
G4Box*  Voxel = new G4Box("Voxel", VOXEL_X_DIM/2.0, VOXEL_Y_DIM/2.0, VOXEL_Z_DIM/2.0);
for (  int  Iterator=0; Iterator< this->NumberOfPhantomOrgans; Iterator++) {
int OrganeId =_VoxelizedPhantomStruc[Iterator].ORGAN_ID;
if (OrganeId!=this->BackgroundID)
{
tmp[Iterator]= new G4LogicalVolume(Voxel, MaterialName(OrganeId),to_string(OrganeId), 0, 0, 0);
G4VisAttributes * _attribut=  new G4VisAttributes(   this->OrganeColor(OrganeId)); 
//tmp[Iterator]->SetUserLimits(new G4UserLimits(DBL_MAX, DBL_MAX, DBL_MAX, 55*keV));
tmp[Iterator]->SetVisAttributes(_attribut); 
//
if ( OrganeName(OrganeId)==_SourceOrganeName)
{
_attribut->SetForceSolid(true);  
_attribut->SetForceAuxEdgeVisible(true);  
tmp[Iterator]->SetVisAttributes(_attribut);
}}}}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::OrganIDtoMaterialID(int organid)
{
int mat_id=-1;
for (int i=0; i < ArrayMat.size(); i++)
{
if (MaterialName(organid)-> GetName().c_str() ==  ArrayMat[i]-> GetName().c_str()  ) mat_id= i;
}
return  mat_id;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::Construct_Phantom_With_Regular_Navigation( )
{
G4PhantomParameterisation *param = new G4PhantomParameterisation();
G4double halfX = this->VOXEL_X_DIM*0.5;
G4double halfY = this->VOXEL_Y_DIM*0.5;
G4double halfZ =this->VOXEL_Z_DIM*0.5;
param->SetVoxelDimensions( halfX, halfY, halfZ );
G4int nVoxelX =this->Number_Of_Voxels_Along_x;
G4int nVoxelY = this->Number_Of_Voxels_Along_y;
G4int nVoxelZ = this->Number_Of_Voxels_Along_z;
param->SetNoVoxel( nVoxelX, nVoxelY, nVoxelZ );
param->SetMaterials( ArrayMat ); 

param->SetSkipEqualMaterials(this->SkipEqualMaterials);
int cpt=0;
mateIDs = new size_t[nVoxelX*nVoxelY*nVoxelZ];
for( G4int iz = 0; iz < this->Number_Of_Voxels_Along_z; iz++ ) {
for( G4int iy = 0; iy < this->Number_Of_Voxels_Along_y; iy++ ) {
for( G4int ix = 0; ix < this->Number_Of_Voxels_Along_x; ix++ ) {
int organ_id = Voxels[ix][iy][iz];
CopyNumberArray[ix][iy][iz]= cpt;
mateIDs[cpt] = MapOrganIdsToMaterialIds[organ_id];
MapCopyNumbersToIterators[cpt] = OrganIDtoIterator(organ_id);
cpt++;
}}}
param->SetMaterialIndices( mateIDs );
G4NistManager* nist = G4NistManager::Instance();
G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
G4Box* cont_solid = new G4Box("PhantomContainer",nVoxelX*halfX,nVoxelY*halfY,nVoxelZ*halfZ);
G4LogicalVolume* cont_logic = new G4LogicalVolume( cont_solid, world_mat,  "PhantomContainer",0, 0, 0 );
G4VPhysicalVolume * cont_phys = new G4PVPlacement( 0,G4ThreeVector(0.0, 0.0, 0.0) ,"PhantomContainer", cont_logic,this->physWorld, false, 1); 
G4Box* voxel_solid = new G4Box("voxel_solid",halfX,halfY,halfZ);
G4LogicalVolume* voxel_logic = new G4LogicalVolume( voxel_solid, world_mat,  "LogiVoxel",0, 0, 0 );
param->BuildContainerSolid(cont_phys);
param->CheckVoxelsFillContainer( cont_solid->GetXHalfLength(), cont_solid->GetYHalfLength(), cont_solid->GetZHalfLength() );
G4PVParameterised * VoxelizedPhantom =
new G4PVParameterised("VoxelizedPhantom",voxel_logic ,cont_logic, kXAxis, nVoxelX*nVoxelY*nVoxelZ, param); 
VoxelizedPhantom->SetRegularStructureId(1);   
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void  DetectorConstruction:: CreateIrvoxPhantom( int low_iz, int high_iz)
{


cout<<"===InterDosi  VoxIsle technique is activated." << endl;


 myVoxIsle=VoxIsle::GetInstance();
myVoxIsle->SetWorldVolume(this->physWorld);
myVoxIsle->SetNumberOfVoxels(G4ThreeVector(this->Number_Of_Voxels_Along_x,this->Number_Of_Voxels_Along_y,this->Number_Of_Voxels_Along_z));
myVoxIsle->SetVoxelDimensions(G4ThreeVector(this->VOXEL_X_DIM,this->VOXEL_Y_DIM,this->VOXEL_Z_DIM));
myVoxIsle->SetPhantomDimensions(G4ThreeVector(this->PHANTOM_X_DIM,this->PHANTOM_Y_DIM,this->PHANTOM_Z_DIM));
myVoxIsle->SetBackgroudID(this->BackgroundID);
myVoxIsle->SetNumberOfPhantomOrgans(this->NumberOfPhantomOrgans);
myVoxIsle->SetArrayOrgansIds(ArrayOrgansIds);


string toErase= ".ijkid";
size_t pos = this->PhantomFileName.find(toErase);
string _file=  this->PhantomFileName.erase(pos, toErase.length());
myVoxIsle->SetPhantomName(_file);
 myVoxIsle->Apply(Voxels);
exit(0);



}

 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::SetSourceOrganeName( G4String _SourceOrganeName)
{
this->SourceOrganeName=_SourceOrganeName;
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::Construct_Partial_Phantom(   int  slice_id)
{//1
ConstructLogicalVolumes(this->SourceOrganeName);
int  val_x, val_y, val_z;
int  ix, iy, iz;
int  i_z=0;
if ( this->Projection=="3D")  {//2
cout<<"===InterDosi  Projection 3D"<< endl;

if (voxphantomtype=="ijkid") {//3
for (iz=0; iz< this->Number_Of_Voxels_Along_z; iz++)
{//4
for ( iy=0; iy< this->Number_Of_Voxels_Along_y; iy++)
{//5
for ( ix=0; ix< this->Number_Of_Voxels_Along_x; ix++)
{//6
if (OrganIDtoIterator(Voxels[ix][iy][iz])!=this->BackgroundID ){
if (Voxels[ix][iy][iz]!=this->BackgroundID )
{//7

std::string physics_vol_name= this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz) ;
//cout<<"ix,iy,iz="<< to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz) << endl;
G4double  pos_x= ((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM;
G4double  pos_y= ((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM;
G4double  pos_z= ((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM;
new G4PVPlacement(0,G4ThreeVector( pos_x, pos_y,pos_z), 
physics_vol_name, 
tmp[OrganIDtoIterator(Voxels[ix][iy][iz])],
this->physWorld,
false,ix*iy*iz);
}}}} // 7 6 5 4 
}
}//3
else 
{//8
this->PhantomFileDir= InterDosiDirectory()+"/inputs/IRVOXPhantom_files/"+this->PhantomFileName; 
this->runManager = G4RunManager::GetRunManager();
G4bool checkOverlaps = true;
world_mat = CreateMaterial("World_Material");
solidWorld =new G4Box("SolidWorld",  PHANTOM_X_DIM/2., PHANTOM_Y_DIM/2.,  PHANTOM_Z_DIM/2.);  
logicWorld =  new G4LogicalVolume(solidWorld,world_mat,"LogicalWorld");      
  G4VisAttributes* motherAttr = new G4VisAttributes(G4Color(1., 0., 0.));
motherAttr->SetForceWireframe (true);
logicWorld ->SetVisAttributes(motherAttr);   
this->physWorld =  new G4PVPlacement(0,G4ThreeVector(),logicWorld,"PhysicalWorld",0, false, 0,checkOverlaps);   
SetupVoxelizedPhantomParametersForIrVoxFormat();
} //8 
}//2

if ( this->Projection=="PlaneYZ") 
{
ix=slice_id; val_y=this->Number_Of_Voxels_Along_y ; val_z= this->Number_Of_Voxels_Along_z;
for ( iy=0; iy< val_y; iy++)
{
for ( iz=0; iz< val_z; iz++)
{
if (Voxels[ix][iy][iz]!=this->BackgroundID )
{
new G4PVPlacement(0,G4ThreeVector( ((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM, ((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM,  ((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz), tmp[OrganIDtoIterator((Voxels[ix][iy][iz]))]
,this->physWorld,false,ix*iy*iz);
}}}};
if ( this->Projection=="PlaneXZ")
{
iy=slice_id; val_x=this->Number_Of_Voxels_Along_x ; val_z= this->Number_Of_Voxels_Along_z;
for ( ix=0; ix< val_x; ix++)
{
for ( iz=0; iz< val_z; iz++)
{
if (Voxels[ix][iy][iz]!=(this->BackgroundID) )
{
 new G4PVPlacement(0,G4ThreeVector( ((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM, ((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM,  ((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz), tmp[OrganIDtoIterator((Voxels[ix][iy][iz]))]
,this->physWorld,false,ix*iy*iz);
}}}};
if ( this->Projection=="PlaneXY") 
{
iz=slice_id; val_y=this->Number_Of_Voxels_Along_y ; val_x= this->Number_Of_Voxels_Along_x;
for ( ix=0; ix< val_x; ix++)
{
for ( iy=0; iy< val_y; iy++)
{
 
if (Voxels[ix][iy][iz]!=this->BackgroundID)
{
 new G4PVPlacement(0,G4ThreeVector( ((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM, ((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM,  ((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM),this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz), tmp[OrganIDtoIterator(Voxels[ix][iy][iz])]
,this->physWorld,false,ix*iy*iz);
}}}};

if ( this->Projection=="Condensed3D")  {
CreateIrvoxPhantom( 0,  this->Number_Of_Voxels_Along_z-1);
};

if ( this->Projection=="3D_Organ") 
{
for (iz=0; iz< this->Number_Of_Voxels_Along_z; iz++)
{
for ( iy=0; iy< this->Number_Of_Voxels_Along_y; iy++)
{
for ( ix=0; ix< this->Number_Of_Voxels_Along_x; ix++)
{
if (Voxels[ix][iy][iz]==OrganeID(OrganToVis3D)  )
{
std::string physics_vol_name= this->SourceOrganeName+"_"+to_string(ix)+"_"+to_string(iy)+"_"+to_string(iz) ;
G4double  pos_x= ((ix+0.5)*VOXEL_X_DIM)-0.5*PHANTOM_X_DIM;
G4double  pos_y= ((iy+0.5)*VOXEL_Y_DIM)-0.5*PHANTOM_Y_DIM;
G4double  pos_z= ((iz+0.5)*VOXEL_Z_DIM) -0.5*PHANTOM_Z_DIM;
new G4PVPlacement(0,G4ThreeVector( pos_x, pos_y,pos_z), 
physics_vol_name, 
tmp[OrganIDtoIterator(Voxels[ix][iy][iz])],
this->physWorld,
false,ix*iy*iz);
}}}}};

delete [] Voxels;
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::ID_SolidVol(std::string a, std::string b)
{
int id=0;
for (int i=0; i <ArraySolidVoxIslesVolume.size(); i++)
{
std::string  vox_str=a+"_"+b;
if (ArraySolidVoxIslesVolume[i]->GetName().c_str()==vox_str ) {
id=i;
break;
}}
return id;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void DetectorConstruction::ReadVoxelizedPhantomParameters(){
int  incrementor=0;
int  incrementor2=0;
int  incrementor3=0;
ifstream PhantomDescriptorFile;
PhantomDescriptorFile.open(this->PhantomDescriptorFileFullPath);
string str,cp_str;
string key="";
string   _InterDosiDirectory = InterDosiDirectory();
vector<string> data;
while (getline(PhantomDescriptorFile,str))
{
cp_str= str;
vector<string> result;
istringstream iss(str);
while (getline(iss,str,'\t'))
{
result.push_back(str);
}
key=result[0];
if (key=="@VoxelizedPhantomName") {
this->PhantomName=result[1]; 
cout << "===InterDosi Voxelized Phantom Name:"<<this->PhantomName <<endl;
 };
if (key=="@VoxelizedPhantomFileName") {this->PhantomFileDir=_InterDosiDirectory+"/inputs/IJKIDPhantom_files/"+result[1]; 
this->PhantomFileName=result[1];
cout << "===InterDosi Voxelized Phantom File Name:"<< result[1]<< endl;
};
if (key=="@Voxelizedimensions")
{ 
this->PHANTOM_X_DIM=atof(result[1].c_str());
this->PHANTOM_Y_DIM=stod(result[2]);
this->PHANTOM_Z_DIM=stod(result[3]);
this->WorldMat="World_Material";
this->WorldDimX=this->PHANTOM_X_DIM;
this->WorldDimY=this->PHANTOM_Y_DIM;
this->WorldDimZ=this->PHANTOM_Z_DIM;
cout << "===InterDosi Voxelized Phantom Dimensions (mm,mm,mm):"<< G4ThreeVector(this->PHANTOM_X_DIM,this->PHANTOM_Y_DIM,this->PHANTOM_Z_DIM)<< endl;
};
if (key=="@NumberOfVoxels"){ 
this->Number_Of_Voxels_Along_x=stoi(result[1]);
this->Number_Of_Voxels_Along_y=stoi(result[2]);
this->Number_Of_Voxels_Along_z=stoi(result[3]);
cout << "===InterDosi Voxelized Phantom Number of voxels:"<< G4ThreeVector(this->Number_Of_Voxels_Along_x,this->Number_Of_Voxels_Along_y,this->Number_Of_Voxels_Along_z)<< endl;
};
if (key=="@NumberOfPhantomOrgans") {
this->NumberOfPhantomOrgans=stoi(result[1]);
_VoxelizedPhantomStruc = new VoxelizedPhantomStruc[this->NumberOfPhantomOrgans];
ArrayOrgansIds.reserve(this->NumberOfPhantomOrgans);
ArrayOrgansVolumes = new double[this->NumberOfPhantomOrgans];
ArrayOrgansVoxels = new   int [this->NumberOfPhantomOrgans];
ArrayOrgansDensities =  new double[this->NumberOfPhantomOrgans];
}
if (key=="@NumberOfPhantomAnatomicalRegions") {
this->NumberOfPhantomAnatomicalRegions=stoi(result[1]);
if (this->NumberOfPhantomAnatomicalRegions> 0) {
_VoxelizedPhantomRegStruc = std::vector<VoxelizedPhantomRegStruc>  (this->NumberOfPhantomAnatomicalRegions);
ArrayRegionsIds =new   int  [this->NumberOfPhantomAnatomicalRegions];
ArrayRegionsVolumes = new double[this->NumberOfPhantomAnatomicalRegions];
ArrayRegionsVoxels = new   int  [this->NumberOfPhantomAnatomicalRegions];
ArrayOrgansMasses =new double[this->NumberOfPhantomAnatomicalRegions];
}}

if (key=="@WORLD_DIMS") {
this->WorldDimX=stof(result[1]); 
this->WorldDimY=stof(result[2]); 
this->WorldDimZ=stof(result[3]); 
cout << "===InterDosi Word  Dim along X axis:"<<this->WorldDimX <<endl;
cout << "===InterDosi Word  Dim along Y axis:"<<this->WorldDimY <<endl;
cout << "===InterDosi Word  Dim along Z axis:"<<this->WorldDimZ <<endl;

 };
if (key=="@WORLD_MAT") {
this->WorldMat=(result[1]); 
cout << "===InterDosi Word  Material Name:"<<this->WorldMat <<endl;

 };
if (key=="@BackgroundID") 
{
this->BackgroundID=stoi(result[1]);
}
if (key=="@PhantomOrganItem") {
ArrayOrgansIds.push_back(stoi(result[1]));{
_VoxelizedPhantomStruc[incrementor].ORGAN_ID         = stoi(result[1]);
_VoxelizedPhantomStruc[incrementor].ORGAN_NAME       = result[2];
CheckTheValidityOfOrganRegionName(_VoxelizedPhantomStruc[incrementor].ORGAN_NAME );
_VoxelizedPhantomStruc[incrementor].ORGAN_MATERIAL   = result[3];
_VoxelizedPhantomStruc[incrementor].ORGAN_COLOR_R    = stoi(result[4]);
_VoxelizedPhantomStruc[incrementor].ORGAN_COLOR_G    = stoi(result[5]);
_VoxelizedPhantomStruc[incrementor].ORGAN_COLOR_B    = stoi(result[6]);
MaterialsList.push_back(result[3]);
MaterialsList.sort();
MaterialsList.unique();
incrementor++;
}
incrementor2++;
};
if (key=="@PhantomAnatomicalRegion")
 {
ArrayRegionsIds[incrementor3]=(incrementor3);
_VoxelizedPhantomRegStruc[lm].REGION_NAME= result[1];
CheckTheValidityOfOrganRegionName(_VoxelizedPhantomRegStruc[lm].REGION_NAME);
incrementor3 ++;
rr=0;
for (  int  i=2; i< result.size(); i++) {
rr++;
_VoxelizedPhantomRegStruc[lm].ARRAY_ORGAN_IDS.push_back(stoi(result[i])); }
lm++;
rr=0;
}
}
PhantomDescriptorFile.close();

}
/*#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetupVoxelizedPhantomParametersForIjkidFormat(){
this->VOXEL_X_DIM=PHANTOM_X_DIM/(G4double)this->Number_Of_Voxels_Along_x; 
this->VOXEL_Y_DIM=PHANTOM_Y_DIM/(G4double)this->Number_Of_Voxels_Along_y; 
this->VOXEL_Z_DIM=PHANTOM_Z_DIM/(G4double)this->Number_Of_Voxels_Along_z; 
cout<< "===InterDosi    Voxelized phantom name: " << this->PhantomName <<'\n'
    << "===InterDosi    Number of voxels along X: "<< this->Number_Of_Voxels_Along_x<< '\n' 
    << "===InterDosi    Number of voxels along Y: "<< this->Number_Of_Voxels_Along_y << '\n'   
    << "===InterDosi    Number of voxels along Z: "<< this->Number_Of_Voxels_Along_z << '\n'         
    << "===InterDosi    Voxel dimensions (x,y,z) (mm mm mm):"<< this->VOXEL_X_DIM<<" , " << this->VOXEL_Y_DIM <<" , " << this->VOXEL_Z_DIM <<'\n'     
    << "===InterDosi    Total number of voxels: "<< this->Number_Of_Voxels_Along_y *this->Number_Of_Voxels_Along_x*this->Number_Of_Voxels_Along_z <<endl;  

Voxels = new   int  **[this->Number_Of_Voxels_Along_x];
for (  int  i=0; i< this->Number_Of_Voxels_Along_x ; i++)
{
Voxels[i]= new    int  *[this->Number_Of_Voxels_Along_y];
for (  int  j=0; j< this->Number_Of_Voxels_Along_y ; j++)  Voxels[i][j] =  new    int [this->Number_Of_Voxels_Along_z];
}
CopyNumberArray = new   int  **[this->Number_Of_Voxels_Along_x];
for (  int  i=0; i< this->Number_Of_Voxels_Along_x ; i++)
{
CopyNumberArray[i]= new    int  *[this->Number_Of_Voxels_Along_y];
for (  int  j=0; j< this->Number_Of_Voxels_Along_y ; j++)  CopyNumberArray[i][j] =  new    int [this->Number_Of_Voxels_Along_z];
}
// INITIALIZATION OF DATA
for (  int  i=0; i< this->Number_Of_Voxels_Along_x ; i++)  {
for (  int  j=0; j< this->Number_Of_Voxels_Along_y ; j++)  {
for (  int  k=0; k< this->Number_Of_Voxels_Along_z ; k++)  {
Voxels[i][j][k]= this->BackgroundID;
}}}
ifstream inFile_IJKID_FILE;
bool file_exit;
inFile_IJKID_FILE.open(this->PhantomFileDir.c_str());
file_exit = inFile_IJKID_FILE.good();
if (file_exit==false) {  
cout << "===InterDosi    The file named << "<<this->PhantomFileDir.c_str()<< ">> does not exist !"  << endl;  
cout << "===InterDosi    The simulation was crached." << endl;
exit(0);      
}
string STR;
while (getline(inFile_IJKID_FILE,STR))
{
vector<string> IJKID_result;
istringstream IJKID_iss(STR);
for(string IJKID_s_data; IJKID_iss >> IJKID_s_data; )
{
IJKID_result.push_back(IJKID_s_data);
}
int ix=0;
int iy=0;
int iz=0;
string  organ_id="-1";
ix=stoi( IJKID_result[0]);
iy=stoi( IJKID_result[1]);
iz=stoi( IJKID_result[2]);
organ_id= IJKID_result[3];
{
Voxels[ix][iy][iz]=stoi(organ_id);
}
total_number_of_voxels++;
} 
inFile_IJKID_FILE.close();
for (list<string>::iterator it=MaterialsList.begin(); it!=MaterialsList.end(); ++it){ 
G4Material * mat = CreateMaterial(*it);
ArrayMat.push_back(mat);  
NuMbeRoFmAtErIaL++;
}}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::setSelectRegion (bool _SelectRegion )
{
this->SelectRegion= _SelectRegion;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetCutForElectron(G4double _CutForElectron){
this->CutForElectron=_CutForElectron;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetCutForGamma(G4double _CutForGamma){
this->CutForGamma=_CutForGamma;
}
/*#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetCutForPositron(G4double _CutForPositron){
this->CutForPositron=_CutForPositron;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetPhysicsPackage(G4String _PhysicsPackage){
this->PhysicsPackage=_PhysicsPackage;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetPartDistType(std::string  _PartDistType){
this->PartDistType=_PartDistType;
}

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4ThreeVector   DetectorConstruction::Calcualte3DposSegment(int ix1, int ix2, int iy1, int iy2, int iz, float PhantomXDim, float PhantomYDim,float PhantomZDim,float VoxelXDim, float VoxelYDim,float VoxelZDim){
float segment_center_x=0.0, segment_center_y=0.0, segment_center_z=0.0;
if ((std::abs(ix2-ix1)==0) and (std::abs(iy2-iy1)==0))
{

//cout<<" no merged voxels"<< endl;
segment_center_x=  -PhantomXDim*0.5 +( 0.5+ ix1 )*VoxelXDim;
segment_center_y= -PhantomYDim*0.5 +( 0.5+ iy1 )*VoxelYDim;
//segment_center_y= ( -(PhantomYDim/VoxelYDim) + 1+ 2*iy1 )*VoxelYDim*0.5;
//segment_center_x= ((ix1+0.5)*VoxelXDim)-0.5*PhantomXDim;
//
//segment_center_y= ((iy1+0.5)*VoxelYDim)-0.5*PhantomYDim;
//segment_center_y= VoxelYDim+((iy1+0.5)*VoxelYDim)-0.5*PhantomYDim;
}


else

{
//segment_center_x= 0.5*(-PhantomXDim+ (VoxelXDim*(ix1+ix2+1)));

//segment_center_y= 0.5*(-PhantomYDim+ (VoxelYDim*(iy1+iy2+1)));

//segment_center_y= 0.5*(PhantomYDim-(VoxelYDim*(iy1+iy2+1)));

float x1=  0.5*(-PhantomXDim+ (VoxelXDim*(2*ix1+1)));
float x2=  0.5*(-PhantomXDim+ (VoxelXDim*(2*ix2+1)));
//cout<<"x1="<<ix1<<"   pos="<< x1<<endl;
//cout<<"x2="<<ix2<<"   pos="<< x2<<endl;
segment_center_x=0.5*(x1+x2);
float y1=  0.5*(-PhantomYDim+ (VoxelYDim*(2*iy1+1)));
float y2=  0.5*(-PhantomYDim+ (VoxelYDim*(2*iy2+1)));

//cout<<"y1="<<iy1<<"   pos="<< y1<<endl;
//cout<<"y2="<<iy2<<"   pos="<< y2<<endl;
segment_center_y=0.5*(y1+y2);
//cout<<"  merged voxels"<< endl;
}   

segment_center_z=  0.5*(-PhantomZDim+ (VoxelZDim*(2*iz+1)));
return G4ThreeVector(segment_center_x,segment_center_y, segment_center_z);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::SetOrganToVis3D(std::string  _OrganToVis3D){
this->OrganToVis3D=_OrganToVis3D;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ReadIrVoxData(std::string  _IrVoxFileFullPath){
std::string  organ_id_key="ORGAN_ID";
std::string solid_volume_key="SOLID_VOLUMES";
std::string logical_volume_key="LOGICAL_VOLUMES";
std::string world_volume_key="WORLD_VOLUME (VOL(cm^3),ID )";
std::string dim_volumes_key="DIM_VOLUMES";
std::string optim_axis_key="OPTIM_AXIS";
int width,  height,_width,   _height,organ_id, _organ_id, _solid_id;
int iz=0;

    std::ifstream IrVoxFile;
    IrVoxFile.open(_IrVoxFileFullPath.c_str());
bool file_exit = IrVoxFile.good();
if (file_exit==false) {  
cout << "===InterDosi    The file named << "<<_IrVoxFileFullPath.c_str()<< ">> does not exist !"  << endl;  
cout << "===InterDosi    The simulation was crached." << endl;
exit(0);      
}

    std::stringstream strStream;
    strStream << IrVoxFile.rdbuf(); 
    std::string str = strStream.str(); 
IrVoxFile.close();


vector<string> row_values;
vector<string> solid_volume_data;

split(str, '\n', row_values);
 str="";
for ( int i=0; i < row_values.size(); i++) 
{
if (row_values[i].find(world_volume_key) != std::string::npos)  {
vector<string> rval;
split(row_values[i+1], '\t', rval);
this->WorldMathVolume= std::stof(rval[0]);
this->BackgroundID= std::stoi(rval[1]);
break;
//rval.clear();
}}

for ( int i=0; i < row_values.size(); i++) 
{
     if (row_values[i].find(dim_volumes_key) != std::string::npos)  {
vector<string> rvalues;
split(row_values[i+1], '\t', rvalues);
for (int k=0; k < rvalues.size();k++)  {
ArrayIrVoxOrganeVolume.push_back(std::stof(rvalues[k]));
}
break;
}
}
vector <int> ids_pos;

for ( int i=0; i < row_values.size(); i++)
{
     if (row_values[i].find(organ_id_key) != std::string::npos) 
     {
vector<string> rvalues;
split(row_values[i], '\t', rvalues);

ids_pos.push_back(i);

       }
}


//-------------get optim axis data---------------
vector <string>  optim_axis_data;
for (int j=0; j < row_values.size(); j++)
{
if (row_values[j].find(optim_axis_key) != std::string::npos)  
{
split(row_values[j], '\t', optim_axis_data);
break;
}
}

//-------------get solid volumes---------------
for (int j=0; j < row_values.size(); j++)

{
if (row_values[j].find(solid_volume_key) != std::string::npos)  
{
split(row_values[j+1], '\t', solid_volume_data);
for (int k=0; k< solid_volume_data.size(); k++) {
vector<string> solid_volume_array_data;
split(solid_volume_data[k], 'x', solid_volume_array_data);
  _width=std::stoi( solid_volume_array_data[0]);
_height=std::stoi( solid_volume_array_data[1]);
ConstArraySolidVoxIslesVolumesZAXIS(   _width,    _height,  this->VOXEL_X_DIM,   this->VOXEL_Y_DIM,   this->VOXEL_Z_DIM);
solid_volume_array_data.clear();
}
break;
solid_volume_data.clear();

}
}
vector<string> logical_volume_data;
//-------------get logical volumes---------------
for (int j=0; j < row_values.size(); j++)

{
if (row_values[j].find(logical_volume_key) != std::string::npos)  
{
vector<string> logical_volume_array_data;

split(row_values[j+1], '\t', logical_volume_data);
for (int k=0; k< logical_volume_data.size(); k++) {
split(logical_volume_data[k], '@', logical_volume_array_data);
  _organ_id=std::stoi( logical_volume_array_data[0]);
  _solid_id=std::stoi( logical_volume_array_data[1]);
ConstArrayLogicalVoxIslesVolumes(  _organ_id, _solid_id );
logical_volume_array_data.clear();
}
break;
logical_volume_data.clear();
}
}
//-----------------------------------------------

const G4LogicalVolumeStore* lvs = G4LogicalVolumeStore::GetInstance();
std::vector<G4LogicalVolume*>::const_iterator lvciter;
//cout<< "solid volume size==" << ArraySolidVoxIslesVolume.size()<<endl;
for( lvciter = lvs->begin(); lvciter != lvs->end(); lvciter++ )
{ 
//cout<<"logvol_name="<<(*lvciter)->GetName()<< endl;
}



//-------------get physical volumes---------------
for ( int l=0; l < ids_pos.size()-1; l++) 
{
vector<string> rvalues;
split(row_values[ids_pos[l]], '\t', rvalues);

organ_id=stoi(rvalues[1]);

for ( int v=ids_pos[l]+1; v< ids_pos[l+1]; v++) 
{
                     vector<string> rw_val2;
                                       split(row_values[v], '\t', rw_val2);
                                       iz=std::stoi(rw_val2[0]);

                               for (int k=1; k< rw_val2.size();k++) 
                                                {

                                                  ProcessIrregularVoxDataZAxis(rw_val2[k] , organ_id,iz);
                                         }
}

}

vector<string> rvalues;
split(row_values[ids_pos[ids_pos.size()-1]], '\t', rvalues);

organ_id=stoi(rvalues[1]);
for ( int v=ids_pos[ids_pos.size()-1]+1; v< row_values.size(); v++) 
{
                     vector<string> rw_val2;
                                       split(row_values[v], '\t', rw_val2);
                                       iz=std::stoi(rw_val2[0]);

                               for (int k=1; k< rw_val2.size();k++) 
                                                {

                                                  ProcessIrregularVoxDataZAxis(rw_val2[k] , organ_id,iz);
                                         }
}


}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::ProcessIrregularVoxDataZAxis( std::string rectangular_data, int
organ_id2, int iz) 
{//1
int ix1=0, ix2=0, iy1=0,iy2=0;
int width,  height,_width,   _height,  _solid_id;
std::string Organe_Name="";
Organe_Name=OrganeName(organ_id2);
std::string non_merged_voxels_key="#";
std::string merged_voxels_key=":";
vector<string> row_val;
split(rectangular_data, '\t', row_val);
for (int j=0; j < row_val.size(); j++)

{//2
if (row_val[j].find(non_merged_voxels_key) != std::string::npos) 
{//3
vector<string> row_val2;
split(row_val[j], '#', row_val2);
ix1=std::stoi(row_val2[0]);
ix2=std::stoi(row_val2[0]);
iy1=std::stoi(row_val2[1]);
iy2=std::stoi(row_val2[1]);
G4ThreeVector center_pos=Calcualte3DposSegment( ix1,  ix2, iy1,  iy2,  iz,  this->PHANTOM_X_DIM, this->PHANTOM_Y_DIM, this->PHANTOM_Z_DIM, this->VOXEL_X_DIM,  this->VOXEL_Y_DIM, this->VOXEL_Z_DIM);
width= ix2-ix1+1;
height= iy2-iy1+1;
row_val2.clear();
const G4String logical_volume=std::to_string(organ_id2)+"_"+std::to_string(width)+"_"+std::to_string(height);
const G4LogicalVolumeStore* lvs = G4LogicalVolumeStore::GetInstance();
G4LogicalVolume* logvol= lvs->GetVolume(logical_volume, true) ;
ConstructIrVoxPhysicalVolumeZAXIS(logvol, center_pos,  width,  height,   iz,Organe_Name);
} //3

if (row_val[j].find(merged_voxels_key) != std::string::npos) 

 {//4
vector<string> row_val2;
split(row_val[j], ':', row_val2);
ix1=std::stoi(row_val2[0]);
ix2=std::stoi(row_val2[2]);
iy1=std::stoi(row_val2[1]);
iy2=std::stoi(row_val2[3]);
G4ThreeVector center_pos=Calcualte3DposSegment( ix1,  ix2, iy1,  iy2,  iz,  this->PHANTOM_X_DIM, this->PHANTOM_Y_DIM, this->PHANTOM_Z_DIM, this->VOXEL_X_DIM,  this->VOXEL_Y_DIM, this->VOXEL_Z_DIM);
int __width= ix2-ix1+1;
int __height= iy2-iy1+1;
row_val2.clear();
row_val.clear();
const G4String logical_volume=std::to_string(organ_id2)+"_"+std::to_string(__width)+"_"+std::to_string(__height);
const G4LogicalVolumeStore* lvs = G4LogicalVolumeStore::GetInstance();
G4LogicalVolume* logvol= lvs->GetVolume(logical_volume, true) ;
ConstructIrVoxPhysicalVolumeZAXIS(logvol, center_pos,  __width,  __height,   iz,Organe_Name);
}//4
}//2
row_val.clear();
}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void  DetectorConstruction::split(const std::string &s, char delim, std::vector<std::string> &elems) 
{
std::stringstream ss;
ss.str(s);
std::string item;
while (std::getline(ss, item, delim)) 
{
elems.push_back(item);
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::FillDataIrVox(std::string  _data){
IrVoxFile << _data<<endl;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::GetMax_MinZID(int organ_id){
std::vector<int>  ZID_Vec;


for (int iz=this->Number_Of_Voxels_Along_z-1; iz>=0 ; iz--)
{
for (int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
if (Voxels[ix][iy][iz]==(organ_id))
{
ZID_Vec.push_back(iz);
}
}}}

if (ZID_Vec.size() > 0)
{  
 MinZID = *min_element(ZID_Vec.begin(), ZID_Vec.end());
MaxZID = *max_element(ZID_Vec.begin(), ZID_Vec.end());
} 
ZID_Vec.clear();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4Box* DetectorConstruction::ConstructSolidVolume(int width, int height) {
G4Box* new_solid;
std::string solidvolname = "Voxel_"+std::to_string(width)+"_"+std::to_string(height);
int index = GetSolidVolIndexInArray(solidvolname);
if (index==-1) { new_solid=  new G4Box(solidvolname , (width*this->VOXEL_X_DIM/2.0), (height*this->VOXEL_Y_DIM/2.0),this-> VOXEL_Z_DIM/2.0);
this->ArrayIrVoxSolidVolume.push_back(new_solid);

} else { new_solid= ArrayIrVoxSolidVolume[index];}
return new_solid;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::GetSolidVolIndexInArray(std::string SolidVolumeName)
{
int index=-1;
for (unsigned int i=0; i< ArrayIrVoxSolidVolume.size();i++)
{if (this->ArrayIrVoxSolidVolume[i]->GetName().c_str()==SolidVolumeName )
{
index=i;
break;
}}
return index;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4LogicalVolume* DetectorConstruction::ConstructIrVoxLogicalVolume(int width, int height, std::string OrganeName ) {
G4LogicalVolume * new_logical_vol ;
int index=-1;
std::string logivolname=OrganeName+"_"+std::to_string(width)+"_"+std::to_string(height);
const G4LogicalVolumeStore* lvs = G4LogicalVolumeStore::GetInstance();
std::vector<G4LogicalVolume*>::const_iterator lvciter;
for( lvciter = lvs->begin(); lvciter != lvs->end(); lvciter++ )
{ 
std::string logvol= (*lvciter)->GetName();
if (logvol==logivolname) 
{
new_logical_vol= (*lvciter);
index=0;
break;
}  }
if (index==-1){
new_logical_vol = new G4LogicalVolume(ConstructSolidVolume(width, height), MaterialName(OrganeID(OrganeName)),logivolname, 0, 0, 0);
G4VisAttributes * _attribut=  new G4VisAttributes(OrganeColor(OrganeID(OrganeName))); 
new_logical_vol->SetVisAttributes(_attribut);
}
return new_logical_vol;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int DetectorConstruction::GetIrVoxLogicalVolIndexInArray(std::string LogicalVoluName)
{
int index=-1;
for (unsigned int i=0; i< ArrayIrVoxLogicalVolume.size();i++)
{
if (ArrayIrVoxLogicalVolume[i]->GetName().c_str()==LogicalVoluName )
{
index=i;
break;
}}
return index;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string DetectorConstruction::VoxelizedPhantomType( std:: string phantom_file_name)
{
string file_type="";
vector<string> row_val;
split(phantom_file_name, '.', row_val);
file_type= row_val[1];
return file_type;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructIrVoxPhysicalVolumeZAXIS(G4LogicalVolume* mylogvol,
 G4ThreeVector center_pos, int width, int height,  int iz, std::string OrganeName)
{
if ( OrganeName == this->SourceOrganeName)
{
vector <float>   arrayX_pos= GetMergedVoxelsIndicesX( width, center_pos.x()) ;
vector <float>  arrayY_pos=  GetMergedVoxelsIndicesY( height, center_pos.y()) ;
for (int i=0; i<arrayX_pos.size(); i++){
for (int j=0; j<arrayY_pos.size(); j++){
float  x_center_pos =arrayX_pos[i];
float  y_center_pos =arrayY_pos[j];
float  z_center_pos =center_pos.z();
//cout<< "add source position" <<  G4ThreeVector(x_center_pos,y_center_pos,z_center_pos)  <<  endl;
PhysicsVolPosList.push_back(G4ThreeVector(x_center_pos,y_center_pos,z_center_pos));
}}}
new G4PVPlacement(0,center_pos, OrganeName+to_string(width )+"_"+to_string(height )+"_"+to_string(iz ), mylogvol,this->physWorld,false,0);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructIrVoxPhysicalVolumeYAXIS(G4LogicalVolume* mylogvol,
 G4ThreeVector center_pos, int width, int height,  int iy, std::string OrganeName)
{
if ( OrganeName == this->SourceOrganeName)
{
vector <float>   arrayX_pos= GetMergedVoxelsIndicesX( height ,center_pos.x()) ;
vector <float>  arrayZ_pos=  GetMergedVoxelsIndicesZ(width,  center_pos.z()) ;
for (int i=0; i<arrayX_pos.size(); i++){
for (int k=0; k<arrayZ_pos.size(); k++){
float  x_center_pos =arrayX_pos[i];
float  z_center_pos =arrayZ_pos[k];
float  y_center_pos =center_pos.y();
PhysicsVolPosList.push_back(G4ThreeVector(x_center_pos,y_center_pos,z_center_pos));
}}}
new G4PVPlacement(0,center_pos, OrganeName+to_string(width )+"_"+to_string(height )+"_"+to_string(iy), mylogvol,this->physWorld,false,0);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstructIrVoxPhysicalVolumeXAXIS(G4LogicalVolume* mylogvol,
 G4ThreeVector center_pos, int width, int height,  int iy, std::string OrganeName)
{
if ( OrganeName == this->SourceOrganeName)
{
vector <float>   arrayY_pos= GetMergedVoxelsIndicesY( height ,center_pos.y()) ;
vector <float>  arrayZ_pos=  GetMergedVoxelsIndicesZ(width,  center_pos.z()) ;
for (int i=0; i<arrayY_pos.size(); i++){
for (int k=0; k<arrayZ_pos.size(); k++){
float  y_center_pos =arrayY_pos[i];
float  z_center_pos =arrayZ_pos[k];
float  x_center_pos =center_pos.x();
PhysicsVolPosList.push_back(G4ThreeVector(x_center_pos,y_center_pos,z_center_pos));
}}}
new G4PVPlacement(0,center_pos, OrganeName+to_string(width )+"_"+to_string(height )+"_"+to_string(iy), mylogvol,this->physWorld,false,0);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstArrayLogicalVoxIslesVolumes( int organ_id, int solid_id)
{
std::string  logivolname=std::to_string(organ_id)+"_"+ArraySolidVoxIslesVolume[solid_id]->GetName();
G4LogicalVolume*
new_logical_vol = new G4LogicalVolume(ArraySolidVoxIslesVolume[solid_id], MaterialName(organ_id),logivolname, 0, 0, 0);
G4VisAttributes * _attribut=  new G4VisAttributes(OrganeColor(organ_id)); 
new_logical_vol->SetVisAttributes(_attribut);
ArrayLogicalVoxIslesVolume.push_back(new_logical_vol);

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int * DetectorConstruction::LowerHeigherZID( int organ_id)
{
int*  LowerHeigherZID = new int [2];
vector<int> array_zid;
for (int iz=0; iz<this->Number_Of_Voxels_Along_z; iz++)
{
for (int ix=0; ix< this->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->Number_Of_Voxels_Along_y; iy++){
if (Voxels[ix][iy][iz]==(organ_id))
{
array_zid.push_back(iz);
}
}}}
LowerHeigherZID[0] =  *min_element(array_zid.begin(), array_zid.end());
LowerHeigherZID[1] =  *max_element(array_zid.begin(), array_zid.end());
return LowerHeigherZID;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstArraySolidVoxIslesVolumesZAXIS( int width,  int height, float VOXEL_X_DIM, float VOXEL_Y_DIM, float VOXEL_Z_DIM)
{
G4Box* new_solid;
std::string  _name=std::to_string(width)+"_"+std::to_string(height);
new_solid=new 
 G4Box(_name, width* VOXEL_X_DIM/2., height*VOXEL_Y_DIM/2.,  VOXEL_Z_DIM/2.); 
ArraySolidVoxIslesVolume.push_back(new_solid);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstArraySolidVoxIslesVolumesXAXIS( int width,  int height, float VOXEL_X_DIM, float VOXEL_Y_DIM, float VOXEL_Z_DIM)
{
G4Box* new_solid;
std::string  _name=std::to_string(width)+"_"+std::to_string(height);
new_solid=new 
 G4Box(_name, VOXEL_X_DIM/2., height*VOXEL_Y_DIM/2.,  width* VOXEL_Z_DIM/2.); 
ArraySolidVoxIslesVolume.push_back(new_solid);
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorConstruction::ConstArraySolidVoxIslesVolumesYAXIS( int width,  int height, float VOXEL_X_DIM, float VOXEL_Y_DIM, float VOXEL_Z_DIM)
{
G4Box* new_solid;
std::string  _name=std::to_string(width)+"_"+std::to_string(height);
new_solid=new 
 G4Box(_name,  height*VOXEL_X_DIM/2.,VOXEL_Y_DIM/2.,  width* VOXEL_Z_DIM/2.); 
ArraySolidVoxIslesVolume.push_back(new_solid);

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::vector <float>  DetectorConstruction::GetMergedVoxelsIndicesZ( int width, float center_pos_z)
{
std::vector <float> _data;
for (int i=0; i< width; i++){_data.push_back(center_pos_z-(VOXEL_Z_DIM*width/2.0) +0.5*VOXEL_Z_DIM*(1+2*i) );}
return _data;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::vector <float>  DetectorConstruction::GetMergedVoxelsIndicesX( int width, float center_pos_x)
{
std::vector <float> _data;
for (int i=0; i< width; i++){_data.push_back(center_pos_x-(VOXEL_X_DIM*width/2.0) +0.5*VOXEL_X_DIM*(1+2*i) );}
return _data;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::vector <float>  DetectorConstruction::GetMergedVoxelsIndicesY( int height, float center_pos_y) {
std::vector <float> _data;
for (int i=0; i< height; i++){_data.push_back(center_pos_y-(VOXEL_Y_DIM*height/2.0)+ 0.5*VOXEL_Y_DIM*(1+2*i) );}
return _data;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/

void DetectorConstruction::SetVoxGeomMacroFileName(G4String _VoxGeomMacroFileName){
this->VoxGeomMacroFileName=_VoxGeomMacroFileName;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
