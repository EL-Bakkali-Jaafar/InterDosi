/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorMessenger.hh"
#include "DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
#include <iomanip>
#include "G4Threading.hh"
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::DetectorMessenger(DetectorConstruction* pDetectorConstruction)
: G4UImessenger(),fDetectorConstruction(pDetectorConstruction)
{
 DetectorDir           = new G4UIdirectory("/InterDosi/");
 DetectorDir           -> SetGuidance("............................");
 PrimaryParticleKineticEnergyCmd = new G4UIcmdWithADoubleAndUnit("/InterDosi/PrimaryParticleKineticEnergy",this);  
 PrimaryParticleKineticEnergyCmd->SetGuidance("PrimaryParticleKineticEnergy.");
 PrimaryParticleKineticEnergyCmd->SetParameterName("PrimaryParticleKineticEnergy",false);
 PrimaryParticleKineticEnergyCmd->SetUnitCategory("Energy");
 PrimaryParticleKineticEnergyCmd->SetRange("PrimaryParticleKineticEnergy>0.0");
 PrimaryParticleNameCmd = new G4UIcmdWithAString("/InterDosi/PrimaryParticleName",this);  
 PrimaryParticleNameCmd->SetGuidance("PrimaryParticleName");
 PrimaryParticleNameCmd->SetParameterName("PrimaryParticleName",false);
 BackgroundID_Cmd = new G4UIcmdWithAnInteger("/InterDosi/BackgroundID",this);  
 BackgroundID_Cmd->SetGuidance("Set BackgroundID.");
 BackgroundID_Cmd ->SetParameterName("BackgroundID",false);
 BackgroundID_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 NumberOfSameParticle_Cmd = new G4UIcmdWithAnInteger("/InterDosi/ParticleRecyclingFactor",this);  
 NumberOfSameParticle_Cmd->SetGuidance("Set ParticleRecyclingFactor.");
 NumberOfSameParticle_Cmd ->SetParameterName("ParticleRecyclingFactor",false);
 NumberOfSameParticle_Cmd ->SetRange("ParticleRecyclingFactor>=0");
 NumberOfSameParticle_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 PhantomDescriptorFileFullPath_Cmd  = new G4UIcmdWithAString("/InterDosi/PhantomDescriptorFileFullPath",this);
 PhantomDescriptorFileFullPath_Cmd  ->SetGuidance("");
 PhantomDescriptorFileFullPath_Cmd ->SetParameterName("PhantomDescriptorFileFullPath",false);
 PhantomDescriptorFileFullPath_Cmd  ->SetDefaultValue("");
 PhantomDescriptorFileFullPath_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


 ScoreDosePerVoxelCmd = new G4UIcmdWithABool("/InterDosi/ScoreDosePerVoxel",this);  
 ScoreDosePerVoxelCmd->SetGuidance("ScoreDosePerVoxel.");
 ScoreDosePerVoxelCmd->SetParameterName("ScoreDosePerVoxel",false);
 ScoreDosePerVoxelCmd->AvailableForStates(G4State_PreInit,G4State_Idle);



 SkipEqualMaterialsCmd = new G4UIcmdWithABool("/InterDosi/SkipEqualMaterials",this);  
 SkipEqualMaterialsCmd->SetGuidance("SkipEqualMaterials.");
 SkipEqualMaterialsCmd->SetParameterName("SkipEqualMaterials",false);
 SkipEqualMaterialsCmd->AvailableForStates(G4State_PreInit,G4State_Idle);


 SelectRegionCmd = new G4UIcmdWithABool("/InterDosi/SelectRegion",this);  
 SelectRegionCmd->SetGuidance("SelectRegion.");
 SelectRegionCmd->SetParameterName("SelectRegion",false);
 SelectRegionCmd->AvailableForStates(G4State_PreInit,G4State_Idle);



 NumberOfThreads_Cmd = new G4UIcmdWithAnInteger("/InterDosi/NumberOfThreads",this);  
 NumberOfThreads_Cmd->SetGuidance("Set  Number Of Threads.");
 NumberOfThreads_Cmd ->SetParameterName("NumberOfThreads",false);
 NumberOfThreads_Cmd ->SetRange("NumberOfThreads>=0");
 NumberOfThreads_Cmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 SourceOrganeNameCmd  = new G4UIcmdWithAString("/InterDosi/SourceName",this);
 SourceOrganeNameCmd  ->SetGuidance("");
 SourceOrganeNameCmd  ->SetParameterName("SourceName",false);
 SourceOrganeNameCmd  ->SetDefaultValue("");
 SourceOrganeNameCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 projectionCmd  = new G4UIcmdWithAString("/InterDosi/Projection",this);
 projectionCmd  ->SetGuidance("");
 projectionCmd  ->SetParameterName("Projection",false);
 projectionCmd  ->SetDefaultValue("");
 projectionCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);
 SliceIdCmd = new G4UIcmdWithAnInteger("/InterDosi/SliceId",this);  
 SliceIdCmd->SetGuidance("Set SliceId.");
 SliceIdCmd ->SetParameterName("SliceId",false);
 SliceIdCmd ->SetRange("SliceId>=0");

 PhysicsPackageCmd            = new G4UIcmdWithAString("/InterDosi/PhysicsPackage",this);
 PhysicsPackageCmd            ->SetGuidance("");
 PhysicsPackageCmd            ->SetParameterName("PhysicsPackage",false);
 PhysicsPackageCmd            ->SetDefaultValue("");

 PartDistTypeCmd            = new G4UIcmdWithAString("/InterDosi/SourceParDistType",this);
 PartDistTypeCmd            ->SetGuidance("");
 PartDistTypeCmd            ->SetParameterName("SourceParDistType",false);
 PartDistTypeCmd            ->SetDefaultValue("");


OrganToVis3DCmd            = new G4UIcmdWithAString("/InterDosi/OrganToVis3D",this);
 OrganToVis3DCmd            ->SetGuidance("");
 OrganToVis3DCmd            ->SetParameterName("OrganToVis3D",false);
 OrganToVis3DCmd            ->SetDefaultValue("");

 CutForElectronCmd = new G4UIcmdWithADouble("/InterDosi/CutForElectron",this);  
 CutForElectronCmd->SetGuidance("CutForElectron.");
 CutForElectronCmd->SetParameterName("CutForElectron",false);
 CutForElectronCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);

 CutForGammaCmd = new G4UIcmdWithADouble("/InterDosi/CutForGamma",this);  
 CutForGammaCmd->SetGuidance("CutForGamma.");
 CutForGammaCmd->SetParameterName("CutForGamma",false);
 CutForGammaCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


 CutForPositronCmd = new G4UIcmdWithADouble("/InterDosi/CutForPositron",this);  
 CutForPositronCmd->SetGuidance("CutForPositron.");
 CutForPositronCmd->SetParameterName("CutForPositron",false);
 CutForPositronCmd ->AvailableForStates(G4State_PreInit,G4State_Idle);


 VoxGeomMacroFileNameCmd            = new G4UIcmdWithAString("/InterDosi/VoxGeomMacroFileName",this);
 VoxGeomMacroFileNameCmd            ->SetGuidance("");
 VoxGeomMacroFileNameCmd            ->SetParameterName(" VoxGeomMacroFileName",false);
 VoxGeomMacroFileNameCmd            ->SetDefaultValue("");



}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
DetectorMessenger::~DetectorMessenger()
{
  delete PrimaryParticleNameCmd;
  delete PrimaryParticleKineticEnergyCmd;
  delete DetectorDir;    
  delete PrimaryParticleKineticEnergyCmd;
  delete NumberOfSameParticle_Cmd;
  delete SourceOrganeNameCmd;
  delete projectionCmd;
  delete SliceIdCmd;
  delete PhantomDescriptorFileFullPath_Cmd;
  delete BackgroundID_Cmd;
  delete PhysicsPackageCmd;
  delete CutForPositronCmd;
  delete CutForGammaCmd;
  delete CutForElectronCmd;
  delete ScoreDosePerVoxelCmd;
  delete  SelectRegionCmd;
delete PartDistTypeCmd;
delete OrganToVis3DCmd;
delete VoxGeomMacroFileNameCmd;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{       
      if(command==NumberOfSameParticle_Cmd ){fDetectorConstruction->SetParticleRecyclingFactor(NumberOfSameParticle_Cmd->GetNewIntValue(newValue));}  
else  if( command == NumberOfThreads_Cmd ){fDetectorConstruction-> SetNumberOfThreads(NumberOfThreads_Cmd->GetNewIntValue(newValue));}  
else  if( command == PrimaryParticleKineticEnergyCmd ){ fDetectorConstruction->set_kinetic_energy(PrimaryParticleKineticEnergyCmd->GetNewDoubleValue(newValue));}
else  if( command == PrimaryParticleNameCmd ){ fDetectorConstruction->set_particle_name(newValue);}
else  if(command==SourceOrganeNameCmd ){fDetectorConstruction->SetSourceOrganeName(newValue);}   
else  if(command==projectionCmd ){fDetectorConstruction->SetProjection(newValue);}   
else  if( command == SliceIdCmd){fDetectorConstruction-> SetSliceId(SliceIdCmd->GetNewIntValue(newValue));} 
else  if(command==PhantomDescriptorFileFullPath_Cmd){fDetectorConstruction->SetPhantomDescriptorFileFullPath(newValue);} 
else  if( command == BackgroundID_Cmd){fDetectorConstruction-> SetBackgroundID(BackgroundID_Cmd->GetNewIntValue(newValue));}  
else  if( command == ScoreDosePerVoxelCmd ){ fDetectorConstruction->setScoreDosePerVoxel(ScoreDosePerVoxelCmd->GetNewBoolValue(newValue));}
else  if( command == SkipEqualMaterialsCmd ){ fDetectorConstruction->setSkipEqualMaterials(SkipEqualMaterialsCmd->GetNewBoolValue(newValue));}
else  if( command == SelectRegionCmd ){ fDetectorConstruction->setSelectRegion(SelectRegionCmd->GetNewBoolValue(newValue));}
else  if(command==CutForPositronCmd ){ fDetectorConstruction->SetCutForPositron(CutForPositronCmd->GetNewDoubleValue(newValue));}
else  if(command==CutForGammaCmd ){ fDetectorConstruction->SetCutForGamma(CutForGammaCmd->GetNewDoubleValue(newValue));}
else  if(command==CutForElectronCmd ){ fDetectorConstruction->SetCutForElectron(CutForElectronCmd->GetNewDoubleValue(newValue));}
else  if(command==PhysicsPackageCmd ){fDetectorConstruction->SetPhysicsPackage(newValue);}
else  if(command==PartDistTypeCmd ){fDetectorConstruction->SetPartDistType(newValue);}
else  if(command==OrganToVis3DCmd ){fDetectorConstruction->SetOrganToVis3D(newValue);}
else  if(command==VoxGeomMacroFileNameCmd ){fDetectorConstruction->SetVoxGeomMacroFileName(newValue);}   



}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
