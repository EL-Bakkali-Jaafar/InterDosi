/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized phantoms.
Developed by Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
08/12/2020: public version 1.0
 * Copyright (C) 2019-2020 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#define  MAX_ORGANE_NAME_LENGTH 10000
#include "G4Event.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4RunManager.hh"
#include "G4SDManager.hh"
#include "G4UnitsTable.hh"
#include "G4ThreeVector.hh"
#include "G4ios.hh"
#include <stdio.h>
#include "PhantomSD_RegularNav.hh"
#include "DetectorConstruction.hh"
#include <vector>
#include "G4SystemOfUnits.hh"
#include "G4Threading.hh"
#include "G4EventManager.hh"
#include "G4Threading.hh"
#include "G4AutoLock.hh"
#include <math.h>
#include <fstream>
#include <math.h>
#include "H5Cpp.h"
#include <iostream>
#include "G4Timer.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4PVParameterised.hh"
#include <iomanip>
 using namespace std;
 namespace {G4Mutex _Mutex = G4MUTEX_INITIALIZER;}  

 G4ThreadLocal                                  std::ofstream   S_File;

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD_RegularNav::PhantomSD_RegularNav(G4String name )
: G4VSensitiveDetector(name)
{ 
//BeginOfRun();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string PhantomSD_RegularNav::Abrev_SourcePartDistType(string _val) {
string result="";
if (_val=="Uniform_dist") {result="unidist";}
if (_val=="StndRayleigh_dist") {result="rylghdist";}
if (_val=="EvenVoxIDs_dist") {result="evoxidsdist";}
return result;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string  PhantomSD_RegularNav::G4PartToPart(std::string g4_particle_name) 
{
std::string part=g4_particle_name;
if (g4_particle_name=="e-") { part="electron";}
if (g4_particle_name=="e+") { part="positron";}
return part;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
int* PhantomSD_RegularNav::GetIdsVoxelXYZ(std::string _physical_volume_name) {
static int  r[4];
std::istringstream iss(_physical_volume_name);
std::string _s;
int i=0;
while ( std::getline( iss, _s, '_' ) ) {
r[i]=std::stoi( _s);
i++;
}
return r;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PhantomSD_RegularNav::~PhantomSD_RegularNav()
{//1

}//1
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
string PhantomSD_RegularNav::StrWithoutDigits(string source)
{
string target;
for  (char& _char: source) 
{
if (std::isdigit(_char)==false){target+=_char;}
}
return target;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
G4bool PhantomSD_RegularNav::ProcessHits(G4Step* aStep,G4TouchableHistory*)
{//1
G4double ENERGY_DEPOSIT ;
ENERGY_DEPOSIT*=MeV;
ENERGY_DEPOSIT = aStep -> GetTotalEnergyDeposit();
G4double kinetic_energy = aStep -> GetTrack()->GetKineticEnergy();
if (ENERGY_DEPOSIT == 0.) {return false;}
else 
{//2
const G4VTouchable* touchable_previousvol = aStep->GetPreStepPoint()->GetTouchable();
G4int copyNumber=touchable_previousvol ->GetCopyNumber(0);
int ix, iy, iz;
ix = this->pDetectorConstruction->GetVoxelIndices(copyNumber).x();
iy = this->pDetectorConstruction->GetVoxelIndices(copyNumber).y();
iz = this->pDetectorConstruction->GetVoxelIndices(copyNumber).z();
int i = this->pDetectorConstruction->MapCopyNumbersToIterators[copyNumber];
int organ_id =  this->pDetectorConstruction->Voxels[ix][iy][iz];
std::string vol_current  = aStep-> GetPreStepPoint() -> GetPhysicalVolume() -> GetLogicalVolume()->GetName();
if (this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions> 0) {FillDataInAnatomicalRegions(organ_id,ENERGY_DEPOSIT/MeV);}
if (this->pDetectorConstruction->ScoreDosePerVoxel==true) 
{//3
G4double _density=aStep->GetPreStepPoint()->GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetDensity();
G4double volume = this->pDetectorConstruction->VOXEL_X_DIM*this->pDetectorConstruction->VOXEL_Y_DIM*this->pDetectorConstruction->VOXEL_Z_DIM;
G4double voxel_masse;
voxel_masse*=g;
voxel_masse= _density*volume;
MVoxels[ix][iy][iz].absorbed_dose+=ENERGY_DEPOSIT/voxel_masse/(MeV/g) ;
}//3
myInterDosiData_vector[i].ABSORBED_ENERGY+=ENERGY_DEPOSIT/(MeV);
myInterDosiData_vector[i].ABSORBED_ENERGY2+= (ENERGY_DEPOSIT/MeV)*(ENERGY_DEPOSIT/MeV);
myInterDosiData_vector[i].NEVENT++;
return true;
}//2
}//1

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#*/
void PhantomSD_RegularNav::InitializeDataInAnatomicalRegions()
{
int max_reg=0;
max_reg=this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions;
pRegStruc = std::vector<RegStruc>  (max_reg);
for (int i=0; i< this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions; i++)
{
const char *	region_name= this->pDetectorConstruction->_VoxelizedPhantomRegStruc[i].REGION_NAME.c_str();
strcpy (pRegStruc[i].REGION_NAME,region_name );
pRegStruc[i].KINETIC_ENERGY=this->pDetectorConstruction->kinetic_energy/MeV;
pRegStruc[i].ABSORBED_ENERGY=0.0;
pRegStruc[i].ABSORBED_ENERGY2=0.0;
pRegStruc[i].REGION_NEVENT=0;
pRegStruc[i].REGION_VOLUME=0.0;
pRegStruc[i].REGION_MASSE=0.0;
pRegStruc[i].REGION_NVOXELS=0;
pRegStruc[i].REGION_VOLUME=this->pDetectorConstruction-> ArrayRegionsVolumes[i];
pRegStruc[i].REGION_MASSE=this->pDetectorConstruction-> ArrayOrgansMasses[i];
pRegStruc[i].REGION_NVOXELS= this->pDetectorConstruction->ArrayRegionsVoxels[i];
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD_RegularNav::FillDataInAnatomicalRegions(int _OrganID, double _ENERGY_DEPOSIT)
{//1
for (int i=0; i< this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions; i++) 
{//2
for ( int j=0; j< this->pDetectorConstruction->_VoxelizedPhantomRegStruc[i].ARRAY_ORGAN_IDS.size(); j++)
{//3
int OrganIdInRegion = this->pDetectorConstruction->_VoxelizedPhantomRegStruc[i].ARRAY_ORGAN_IDS[j];
if ( OrganIdInRegion== _OrganID) 
{//4
pRegStruc[i].ABSORBED_ENERGY+=_ENERGY_DEPOSIT;
pRegStruc[i].ABSORBED_ENERGY2+= _ENERGY_DEPOSIT*_ENERGY_DEPOSIT;
pRegStruc[i].REGION_NEVENT++;
}//4
}//3
}//2
}//1
/*#=#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD_RegularNav::SaveDosimetricDataInBinaryFile(std::string INTERNAL_DOSIMETRIC_DATA_FILE_NAME)
{//1
G4ThreadLocal fstream fs;
InterDosiData tmp_InterDosiData;
fs.open(INTERNAL_DOSIMETRIC_DATA_FILE_NAME+".dat", ios::out | ios::binary );
for (int i=0;i<myInterDosiData_vector.size();i++) {
tmp_InterDosiData.ORGANE_ID        =   myInterDosiData_vector[i].ORGANE_ID;
strcpy(tmp_InterDosiData.ORGANE_NAME     , myInterDosiData_vector[i].ORGANE_NAME);
strcpy(tmp_InterDosiData.ORGANE_MATERIAL     , myInterDosiData_vector[i].ORGANE_MATERIAL);
tmp_InterDosiData.KINETIC_ENERGY   = this->pDetectorConstruction->kinetic_energy/MeV;
tmp_InterDosiData.ABSORBED_ENERGY  = myInterDosiData_vector[i].ABSORBED_ENERGY;
tmp_InterDosiData.ABSORBED_ENERGY2 = myInterDosiData_vector[i].ABSORBED_ENERGY2;
tmp_InterDosiData.NEVENT           = myInterDosiData_vector[i].NEVENT;
tmp_InterDosiData.ORGANE_VOLUME    =myInterDosiData_vector[i].ORGANE_VOLUME;
tmp_InterDosiData.ORGANE_MASSE     = myInterDosiData_vector[i].ORGANE_MASSE;//gramme.
tmp_InterDosiData.ORGANE_NVOXELS     = myInterDosiData_vector[i].ORGANE_NVOXELS;//gramme.

fs.write(reinterpret_cast<char *>(&tmp_InterDosiData),sizeof(InterDosiData));
}
fs.close();
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#==#=#=#=#=#=#=#=#*/
void PhantomSD_RegularNav::CreateDosePerVoxelMapFile(){
auto str_thread = std::to_string(G4Threading::G4GetThreadId());

std::ostringstream str;
// Set Fixed -Point Notation
str << std::fixed;
// Set precision to 12 digits
str << std::setprecision(12);
//Add double to stream
str << this->pDetectorConstruction->kinetic_energy;
// Get string from output string stream
std::string str_energy = str.str();
std::string file_name_thread= 
this->pDetectorConstruction ->VoxGeomMacroFileName+"-"+str_thread+".txt";
S_File.open(file_name_thread, std::ios::app);
for (int ix=0; ix< this->pDetectorConstruction->Number_Of_Voxels_Along_x; ix++){
for (int iy=0; iy< this->pDetectorConstruction->Number_Of_Voxels_Along_y; iy++){
for (int iz=0; iz< this->pDetectorConstruction->Number_Of_Voxels_Along_z; iz++){
if ( this->MVoxels[ix][iy][iz].absorbed_dose!=0.0) S_File<<  ix << " "<< iy<< " "<< iz<< " "<< this->MVoxels[ix][iy][iz].absorbed_dose<<endl;
}}}
S_File.close();
}


/*#=#=#=#=#==#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string PhantomSD_RegularNav::Abrev_ListPhysics(string _val) {
string result="";
if (_val=="G4EmStandardPhysics_option1") {result="EMSP1";}
if (_val=="G4EmStandardPhysics_option2") {result="EMSP2";}
if (_val=="G4EmStandardPhysics_option3") {result="EMSP3";}
if (_val=="G4EmStandardPhysics_option4") {result="EMSP4";}
if (_val=="G4EmPenelopePhysics"        ) {result="EMPP";}
if (_val=="G4EmLivermorePhysics"       ) {result="EMLVP";}
return result;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/


void PhantomSD_RegularNav::BeginOfRun(){
this->runManager = G4RunManager::GetRunManager();
this->pDetectorConstruction = (DetectorConstruction*)(this->runManager->GetUserDetectorConstruction()); 
this-> NumberTotalEvents=0;
this-> VoxelVolume=0.;
this-> VoxelMass=0.*g;
this->Total_Events_To_Be_Processed               = this->runManager ->GetNumberOfEventsToBeProcessed();
this-> NumberOfThreads =pDetectorConstruction->NumberOfThread;
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
this->Total_Events_To_Be_Processed               = runManager->GetNumberOfEventsToBeProcessed();
 myInterDosiData_vector = std::vector<InterDosiData>  (this->pDetectorConstruction->NumberOfPhantomOrgans);
if (this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions> 0) {InitializeDataInAnatomicalRegions();}
for (   int i=0;i< this->pDetectorConstruction->NumberOfPhantomOrgans  ;i++) 
{ 
const char *organ_name= this->pDetectorConstruction->_VoxelizedPhantomStruc[i].ORGAN_NAME.c_str();
const char *organ_material= this->pDetectorConstruction->_VoxelizedPhantomStruc[i].ORGAN_MATERIAL.c_str();
strcpy (myInterDosiData_vector[i].ORGANE_NAME,organ_name );
strcpy (myInterDosiData_vector[i].ORGANE_MATERIAL,organ_material );
myInterDosiData_vector[i].ORGANE_ID=this->pDetectorConstruction->_VoxelizedPhantomStruc[i].ORGAN_ID;
myInterDosiData_vector[i].KINETIC_ENERGY=this->pDetectorConstruction->kinetic_energy/MeV;
myInterDosiData_vector[i].ABSORBED_ENERGY=0.0;
myInterDosiData_vector[i].ABSORBED_ENERGY2=0.0;
myInterDosiData_vector[i].NEVENT=0;
myInterDosiData_vector[i].ORGANE_VOLUME= this->pDetectorConstruction->ArrayOrgansVolumes[i];
myInterDosiData_vector[i].ORGANE_MASSE=this->pDetectorConstruction->ArrayOrgansDensities[i]*myInterDosiData_vector[i].ORGANE_VOLUME/(double)1000;//KILO_GRAMME.;
myInterDosiData_vector[i].ORGANE_NVOXELS = this->pDetectorConstruction->ArrayOrgansVoxels[i];

}
if (this->pDetectorConstruction->ScoreDosePerVoxel==true) 
{
this->MVoxels=new dvxm**[this->pDetectorConstruction->Number_Of_Voxels_Along_x];
for (int ix=0; ix< this->pDetectorConstruction->Number_Of_Voxels_Along_x; ix++)
{
this->MVoxels[ix]=new dvxm*[this->pDetectorConstruction->Number_Of_Voxels_Along_y];
for (int iy=0; iy< this->pDetectorConstruction->Number_Of_Voxels_Along_y; iy++)
{
this->MVoxels[ix][iy]=new dvxm[this->pDetectorConstruction->Number_Of_Voxels_Along_z];
for (int iz=0; iz< this->pDetectorConstruction->Number_Of_Voxels_Along_z; iz++)
{
this->MVoxels[ix][iy][iz].absorbed_dose  = 0.;
}}}
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD_RegularNav::EndOfRun(){
G4AutoLock _m(&_Mutex);
if( G4Threading::G4GetThreadId()!=-1)
{//2 
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
std::string file_name= this->pDetectorConstruction ->VoxGeomMacroFileName+"-"+str_thread+".h5";
WRITE_INTERNAL_DOSIMETRIC_DATA_FILE(file_name);
if (this->pDetectorConstruction->ScoreDosePerVoxel==true) { CreateDosePerVoxelMapFile();}
_m.unlock();
}//2
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PhantomSD_RegularNav::WRITE_INTERNAL_DOSIMETRIC_DATA_FILE(std::string INTERNAL_DOSIMETRIC_DATA_FILE_NAME){
 G4ThreadLocal const std::string 
 DatasetName                     ("InternalDosimetricData"       ),
 MEMBER_ORGANE_NAME              ("_ORGANE_NAME"                 ),
 MEMBER_ORGANE_MATERIAL          ("_ORGANE_MATERIAL"             ),
 MEMBER_ORGANE_MASSE             ("_ORGANE_MASSE"                ),
 MEMBER_ORGANE_VOLUME            ("_ORGANE_VOLUME"               ),
 MEMBER_KINETIC_ENERGY           ("_KINETIC_ENERGY"              ),
 MEMBER_ABSORBED_ENERGY          ("_ABSORBED_ENERGY"             ),
 MEMBER_ABSORBED_ENERGY2         ("_ABSORBED_ENERGY2"            ),
 MEMBER_NEVENT                   ("_NEVENT"                      ),
 MEMBER_ORGANE_ID                ("_ORGANE_ID"                   ),
 MEMBER_ORGANE_NVOXELS           ("_ORGANE_NVOXELS"              ),
 DatasetName_region              ("InternalDosimetricRegionData" ),
 MEMBER_REGION_NAME              ("_REGION_NAME"                 ),
 MEMBER_REGION_MASSE             ("_REGION_MASSE"                ),
 MEMBER_REGION_VOLUME            ("_REGION_VOLUME"               ),
 MEMBER_REGION_NEVENT            ("_REGION_NEVENT"               ),
 MEMBER_REGION_KINETIC_ENERGY    ("_REGION_KINETIC_ENERGY"       ),
 MEMBER_REGION_ABSORBED_ENERGY   ("_REGION_ABSORBED_ENERGY"      ),
 MEMBER_REGION_ABSORBED_ENERGY2  ("_REGION_ABSORBED_ENERGY2"     ),
 MEMBER_REGION_NVOXELS           ("_REGION_NVOXELS"              );
try{
hsize_t dim[1],dim_region[1] ;
dim[0]         = myInterDosiData_vector.size();
dim_region[0]  = pRegStruc.size();
int rank                = sizeof(dim) / sizeof(hsize_t);
int rank_region                = sizeof(dim_region) / sizeof(hsize_t);
 H5::CompType mtype(sizeof(InterDosiData));
 H5::CompType mtype_region(sizeof(RegStruc));
mtype.insertMember(MEMBER_ORGANE_NAME,         HOFFSET(InterDosiData, ORGANE_NAME),  H5::StrType(H5::PredType::C_S1, MAX_ORGANE_NAME_LENGTH));

mtype.insertMember(MEMBER_ORGANE_MATERIAL,         HOFFSET(InterDosiData, ORGANE_MATERIAL),  H5::StrType(H5::PredType::C_S1, MAX_ORGANE_NAME_LENGTH));

mtype.insertMember(MEMBER_ORGANE_MASSE,        HOFFSET(InterDosiData, ORGANE_MASSE),   H5::PredType::NATIVE_DOUBLE);

mtype.insertMember(MEMBER_ORGANE_VOLUME,       HOFFSET(InterDosiData, ORGANE_VOLUME),    H5::PredType::NATIVE_DOUBLE);
mtype.insertMember(MEMBER_KINETIC_ENERGY,      HOFFSET(InterDosiData, KINETIC_ENERGY),    H5::PredType::NATIVE_DOUBLE);
mtype.insertMember(MEMBER_ABSORBED_ENERGY,     HOFFSET(InterDosiData, ABSORBED_ENERGY),    H5::PredType::NATIVE_DOUBLE );
mtype.insertMember(MEMBER_ABSORBED_ENERGY2,    HOFFSET(InterDosiData, ABSORBED_ENERGY2),    H5::PredType::NATIVE_DOUBLE );
mtype.insertMember(MEMBER_NEVENT,              HOFFSET(InterDosiData, NEVENT),    H5::PredType::NATIVE_INT );
mtype.insertMember(MEMBER_ORGANE_ID,           HOFFSET(InterDosiData , ORGANE_ID),  H5::PredType::NATIVE_INT );
mtype.insertMember(MEMBER_ORGANE_NVOXELS,           HOFFSET(InterDosiData , ORGANE_NVOXELS),  H5::PredType::NATIVE_INT );
mtype_region.insertMember(MEMBER_REGION_NAME,         HOFFSET(RegStruc, REGION_NAME),  H5::StrType(H5::PredType::C_S1, MAX_ORGANE_NAME_LENGTH));
mtype_region.insertMember(MEMBER_REGION_MASSE,        HOFFSET(RegStruc, REGION_MASSE),   H5::PredType::NATIVE_DOUBLE);
mtype_region.insertMember(MEMBER_REGION_VOLUME,       HOFFSET(RegStruc, REGION_VOLUME),    H5::PredType::NATIVE_DOUBLE);
mtype_region.insertMember(MEMBER_REGION_KINETIC_ENERGY,      HOFFSET(RegStruc, KINETIC_ENERGY),    H5::PredType::NATIVE_DOUBLE);
mtype_region.insertMember(MEMBER_REGION_ABSORBED_ENERGY,     HOFFSET(RegStruc, ABSORBED_ENERGY),    H5::PredType::NATIVE_DOUBLE );
mtype_region.insertMember(MEMBER_REGION_ABSORBED_ENERGY2,    HOFFSET(RegStruc, ABSORBED_ENERGY2),    H5::PredType::NATIVE_DOUBLE );
mtype_region.insertMember(MEMBER_REGION_NVOXELS,      HOFFSET(RegStruc, REGION_NVOXELS),    H5::PredType::NATIVE_INT );
mtype_region.insertMember(MEMBER_REGION_NEVENT,        HOFFSET(RegStruc , REGION_NEVENT),  H5::PredType::NATIVE_INT );
H5::DataSpace space(rank, dim);
H5::DataSpace space_region(rank_region, dim_region);

 H5::H5File *file                 = new H5::H5File(INTERNAL_DOSIMETRIC_DATA_FILE_NAME, H5F_ACC_TRUNC	);
 H5::DataSet *dataset             = new H5::DataSet(file->createDataSet(DatasetName, mtype, space));
 H5::DataSet *dataset_region             = new H5::DataSet(file->createDataSet(DatasetName_region, mtype_region, space_region));
dataset->write(myInterDosiData_vector.data(), mtype);

if (this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions> 0) { dataset_region->write(pRegStruc.data(), mtype_region);}
delete   dataset;
delete  dataset_region;
myInterDosiData_vector.clear();
pRegStruc.clear();
delete   file;

}
catch( H5::FileIException error )
{
    std::cout << "FileIException" << std::endl;
}
catch( H5::DataSetIException error ){
    std::cout << "DataSetIException" << std::endl;
}
catch( H5::DataSpaceIException error )
{
    std::cout << "DataSpaceIException" << std::endl;
}
catch( H5::DataTypeIException error )
{
    std::cout << "DataTypeIException" << std::endl;
}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
