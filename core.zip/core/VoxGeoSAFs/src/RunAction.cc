/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/ 
#include "RunAction.hh"
#include <ctime>
#include <fstream>
#include <iostream>
#include "G4ios.hh"
#include <stdio.h>
#include <math.h>
#include "G4RunManager.hh"
#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"
#include "G4Timer.hh"
#include "G4Threading.hh"
#include "PhantomSD_RegularNav.hh"
#include "PhantomSD_IrvoxNav.hh"
#include "G4VSensitiveDetector.hh"
#include "G4SDManager.hh"
#include <iomanip>

#include "G4Threading.hh"
#include "G4AutoLock.hh"
using namespace std;
G4Timer                                                  * myTimer;
 namespace {G4Mutex _Mutex = G4MUTEX_INITIALIZER;}  
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
RunAction::RunAction()
{
if( IsMaster() ) {myTimer                                     = new G4Timer();}

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
RunAction::~RunAction()
{


}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string  RunAction::G4PartToPart(std::string g4_particle_name) 
{
std::string part=g4_particle_name;
if (g4_particle_name=="e-") { part="electron";}
if (g4_particle_name=="e+") { part="positron";}
return part;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void RunAction::BeginOfRunAction(const G4Run* aRun )
{
if( IsMaster() )
{ 



this->runManager                    = G4RunManager::GetRunManager();
this->pDetectorConstruction         = (DetectorConstruction*)(runManager->GetUserDetectorConstruction());
std::ostringstream str;
str << std::fixed;
str << std::setprecision(12);
str << this->pDetectorConstruction->kinetic_energy;
std::string str_energy = str.str();


myTimer= new G4Timer();
cout << "===InterDosi    The simulation has been started with the following configuration:"
     <<"\n               Source: "<<this->pDetectorConstruction->SourceOrganeName 
     <<"\n               Initial kinetic energy: "<< str_energy
     <<"\n               Particle: "<<this->pDetectorConstruction->particle_name 
     <<"\n               Physics package: " <<this->pDetectorConstruction->PhysicsPackage
     <<"\n               Skip equal materials: " <<this->pDetectorConstruction->SkipEqualMaterials 
     <<"\n               Histories number: "<<runManager->GetNumberOfEventsToBeProcessed() *this->pDetectorConstruction-> ParticleRecyclingFactor<< endl;
 myTimer->Start();
} else {
this->runManager                    = G4RunManager::GetRunManager();
this->pDetectorConstruction         = (DetectorConstruction*)(runManager->GetUserDetectorConstruction());
if (pDetectorConstruction->voxphantomtype=="ijkid"){
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
 G4SDManager* pSDManager = G4SDManager::GetSDMpointerIfExist();
pSDManager->SetVerboseLevel(2);
G4VSensitiveDetector* sd = pSDManager->FindSensitiveDetector("/"+pDetectorConstruction->PhantomName+str_thread,true);
G4ThreadLocal PhantomSD_RegularNav *myPhantomSD_RegularNav = dynamic_cast<PhantomSD_RegularNav*>(sd);
myPhantomSD_RegularNav->BeginOfRun();
}

else {

auto str_thread = std::to_string(G4Threading::G4GetThreadId());
 G4SDManager* pSDManager = G4SDManager::GetSDMpointerIfExist();
pSDManager->SetVerboseLevel(2);
G4VSensitiveDetector* sd = pSDManager->FindSensitiveDetector("/"+pDetectorConstruction->PhantomName+str_thread,true);
G4ThreadLocal PhantomSD_IrvoxNav *myPhantomSD_IrvoxNav = dynamic_cast<PhantomSD_IrvoxNav*>(sd);
myPhantomSD_IrvoxNav->BeginOfRun();

}


}
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string RunAction::Abrev_ListPhysics(string _val) {
string result="";
if (_val=="G4EmStandardPhysics_option1") {result="EMSP1";}
if (_val=="G4EmStandardPhysics_option2") {result="EMSP2";}
if (_val=="G4EmStandardPhysics_option3") {result="EMSP3";}
if (_val=="G4EmStandardPhysics_option4") {result="EMSP4";}
if (_val=="G4EmPenelopePhysics"        ) {result="EMPP" ;}
if (_val=="G4EmLivermorePhysics"       ) {result="EMLVP";}
return result;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
std::string RunAction::Abrev_SourcePartDistType(string _val) {
string result="";
if (_val=="Uniform_dist") {result="unidist";}
if (_val=="StndRayleigh_dist") {result="rylghdist";}
if (_val=="EvenVoxIDs_dist") {result="evoxidsdist";}
return result;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=##=#=#=#=#=#=#=#*/
void RunAction::EndOfRunAction(const G4Run*aRun)
{//0

if( !IsMaster() ) 
{
G4RunManager *runManager                    = G4RunManager::GetRunManager();
DetectorConstruction* mDetectorConstruction         = (DetectorConstruction*)(runManager->GetUserDetectorConstruction());
if (mDetectorConstruction->voxphantomtype=="irvox"){
auto str_thread = std::to_string(G4Threading::G4GetThreadId());;
 G4SDManager* pSDManager = G4SDManager::GetSDMpointerIfExist();
pSDManager->SetVerboseLevel(2);
G4VSensitiveDetector* sd = pSDManager->FindSensitiveDetector("/"+mDetectorConstruction->PhantomName+str_thread,true);
G4ThreadLocal PhantomSD_IrvoxNav *myPhantomSD_IrvoxNav= dynamic_cast<PhantomSD_IrvoxNav*>(sd);
myPhantomSD_IrvoxNav->EndOfRun();
}
if (mDetectorConstruction->voxphantomtype=="ijkid"){
auto str_thread = std::to_string(G4Threading::G4GetThreadId());
 G4SDManager* pSDManager = G4SDManager::GetSDMpointerIfExist();
pSDManager->SetVerboseLevel(2);
G4VSensitiveDetector* sd = pSDManager->FindSensitiveDetector("/"+mDetectorConstruction->PhantomName+str_thread,true);
G4ThreadLocal PhantomSD_RegularNav *myPhantomSD_RegularNav = dynamic_cast<PhantomSD_RegularNav*>(sd);
myPhantomSD_RegularNav->EndOfRun();
}
}
else
{//1
myTimer->Stop();
this->cpu_time=myTimer->GetRealElapsed();
std::ostringstream str;
str << std::fixed;
str << std::setprecision(12);
str << this->pDetectorConstruction->kinetic_energy;
std::string str_energy = str.str();
G4cout <<"===InterDosi    The simulation has been terminated."   <<G4endl;
G4cout <<"===InterDosi    Elapsed computing time: " <<this->cpu_time <<" seconds."<<G4endl;
std::ofstream  File;
string skipm ="SM0";
if (this->pDetectorConstruction->SkipEqualMaterials==true) { skipm= "SM1";};
//string strfile=this->pDetectorConstruction->SourceOrganeName+"-"+str_energy+"-"+G4PartToPart(this->pDetectorConstruction->particle_name)+"-"+Abrev_ListPhysics(this->pDetectorConstruction->PhysicsPackage)+"-"+skipm+"-"+ Abrev_SourcePartDistType(this->pDetectorConstruction -> PartDistType)  ;
string strfile= this->pDetectorConstruction ->VoxGeomMacroFileName;
File.open("sim.data", std::ios::out);
this->NumberOfThread =this->pDetectorConstruction ->NumberOfThread;
File <<strfile<< "\n"<<
this->cpu_time 
<< "\n" <<
this->NumberOfThread 
<< "\n" <<
this->runManager ->GetNumberOfEventsToBeProcessed()  
<< "\n" <<
this->pDetectorConstruction->ParticleRecyclingFactor
<< "\n"  <<
str_energy
<<"\n"<<
this->pDetectorConstruction->NumberOfPhantomOrgans
<<"\n"<<
this->pDetectorConstruction->PhantomName
<< "\n"<<
this->pDetectorConstruction ->PhantomDescriptorFileFullPath
<< "\n" <<
this->pDetectorConstruction ->PhysicsPackage
<< "\n" <<
this->pDetectorConstruction->NumberOfPhantomAnatomicalRegions
<< "\n" <<
this->pDetectorConstruction->SkipEqualMaterials
<< "\n" <<
this->pDetectorConstruction->Number_Of_Voxels_Along_x
<< "\n" <<
this->pDetectorConstruction->Number_Of_Voxels_Along_y
<< "\n" <<
this->pDetectorConstruction->Number_Of_Voxels_Along_z
<< "\n" <<
this->pDetectorConstruction->PHANTOM_X_DIM
<< "\n" <<
this->pDetectorConstruction->PHANTOM_Y_DIM
<< "\n" <<
this->pDetectorConstruction->PHANTOM_Z_DIM
<< "\n" <<
Abrev_SourcePartDistType(this->pDetectorConstruction -> PartDistType)
 <<endl ;
File.close();


string  cmd= "./DoseOrgMerger  sim.data ";
system(cmd.c_str()); 


}

}//0
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
