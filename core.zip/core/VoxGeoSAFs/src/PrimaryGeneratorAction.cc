/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4RunManager.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4Navigator.hh"
#include "G4TransportationManager.hh"
#include "G4ThreeVector.hh"
#include <iostream>
#include <math.h>
#include <fstream>
#include "G4EventManager.hh"
#include <cmath>
#include "G4PhysicalConstants.hh"
#include "Randomize.hh"
#include "G4Navigator.hh"
#include "G4Navigator.hh"
#include "G4TransportationManager.hh"
using namespace std;

/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::PrimaryGeneratorAction():G4VUserPrimaryGeneratorAction(),fParticleGun(0)
{
fParticleGun                           = new G4ParticleGun(1);
this->runManager                       = G4RunManager::GetRunManager();
this->pDetectorConstruction            = (DetectorConstruction*)(runManager->GetUserDetectorConstruction()); 
G4ParticleTable* particleTable         = G4ParticleTable::GetParticleTable();
G4ParticleDefinition* particle         = particleTable->FindParticle(this->pDetectorConstruction->particle_name);
fParticleGun                           ->SetParticleDefinition(particle);
fParticleGun                           ->SetParticleEnergy(this->pDetectorConstruction->kinetic_energy);

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::Initialize()
{
G4ParticleTable* particleTable         = G4ParticleTable::GetParticleTable();
G4ParticleDefinition* particle         = particleTable->FindParticle(this->pDetectorConstruction->particle_name);
fParticleGun                           ->SetParticleDefinition(particle);
fParticleGun                           ->SetParticleEnergy(this->pDetectorConstruction->kinetic_energy);
//cout << "===fParticleGun                           ->GetParticleEnergy " << fParticleGun                           ->GetParticleEnergy() << endl;
//cout << "===fParticle                          PART   " << fParticleGun                           ->GetParticleDefinition()<< endl;

}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
delete fParticleGun;
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent) 
{
GenerateOrgansPositionData();
GenerateOrgansMomentumDirection();
int ParticleRecyclingFactor=this->pDetectorConstruction->ParticleRecyclingFactor;
for (int i=0; i<ParticleRecyclingFactor ;i++) 
{  

fParticleGun->GeneratePrimaryVertex(anEvent);};
}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GenerateOrgansPositionData()
{
Initialize();
//cout << "this->pDetectorConstruction->kinetic_energy" <<  this->pDetectorConstruction->kinetic_energy << endl;
//for (int i=0; i<  this->pDetectorConstruction->PhysicsVolPosList.size() ; i++) cout << this->pDetectorConstruction->PhysicsVolPosList[i] << endl;

int random_id, low_v=0;
int high_v = this->pDetectorConstruction->PhysicsVolPosList.size()-1;
int range =  (high_v - low_v) +1 ;
double r = G4UniformRand();

//

G4String  dist_type= this->pDetectorConstruction->PartDistType;
if (dist_type=="Uniform_dist") {
random_id = low_v + int (range *G4UniformRand() );

}  else if (dist_type=="StndRayleigh_dist") {
double random_rayleigh=(1.0/3.0)*sqrt(-2*log(1-G4UniformRand()));
if  (random_rayleigh >1) { random_rayleigh=1;};
random_id = low_v + int (range *random_rayleigh );

} else if (dist_type=="EvenVoxIDs_dist"){
random_id = low_v + int (range *G4UniformRand() );
double r1 = G4UniformRand();

if (r1<=0.5 & random_id>0)  { random_id=random_id-1; }//emit ionizing radiation only from voxels with even IDs
}
//cout << "random_id" <<  random_id << endl;
G4float x = this->pDetectorConstruction->PhysicsVolPosList[random_id].x()+ 0.5* this->pDetectorConstruction->VOXEL_X_DIM*(1-2*G4UniformRand());
G4float y = this->pDetectorConstruction->PhysicsVolPosList[random_id].y()+ 0.5* this->pDetectorConstruction->VOXEL_Y_DIM*(1-2*G4UniformRand());
G4float z = this->pDetectorConstruction->PhysicsVolPosList[random_id].z()+ 0.5* this->pDetectorConstruction->VOXEL_Z_DIM*(1-2*G4UniformRand());
//cout<< "G4ThreeVector(x ,y,z): "  <<  G4ThreeVector(x ,y,z)<<  endl;
fParticleGun->SetParticlePosition(G4ThreeVector(x ,y,z));

/*
for (int i=0; i< this->pDetectorConstruction->PhysicsVolPosList.size(); i++)
{
x= this->pDetectorConstruction->PhysicsVolPosList[i].x();
y= this->pDetectorConstruction->PhysicsVolPosList[i].y();
z= this->pDetectorConstruction->PhysicsVolPosList[i].z();
cout << "source position " << G4ThreeVector(x ,y,z)<< endl;
} 

//test if phantom has been successfully implemented
G4Navigator* aNavigator = G4TransportationManager::GetTransportationManager()->GetNavigatorForTracking();
G4VPhysicalVolume* aVolume = aNavigator->LocateGlobalPointAndSetup(G4ThreeVector( x,y,z));
//for(int i=0; i < high_v; i++) 
cout<< "Material: "  <<  aVolume->GetLogicalVolume()->GetMaterial()->GetName() <<  endl;
*/



}
/*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
void PrimaryGeneratorAction::GenerateOrgansMomentumDirection(){
G4double a,b,c,n;
do  {
a = ( G4UniformRand() - 0.5 )/0.5;
b = ( G4UniformRand() - 0.5 )/0.5;
c = ( G4UniformRand() - 0.5 )/0.5;
n = a * a + b*b + c*c;

    } while (n > 1  || n == 0.0);

n = std::sqrt(n);
a /=n;
b /=n;
c /=n;
G4ThreeVector direction(a,b,c);
 fParticleGun->SetParticleMomentumDirection(direction);
}
 /*#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#*/
