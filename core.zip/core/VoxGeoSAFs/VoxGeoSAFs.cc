/*
InterDosi, an open-source Geant4-based code for internal dosimetry in voxelized and primitive phantoms.
Developed by Jaafar EL Bakkali,  Professor in Nuclear Physics Associated member to RNSL laboratory, UAE, Faculty of Sciences of Tetuan, Morocco. 
Webpage :https://github.com/EL-Bakkali-Jaafar/InterDosi
01/09/2023: current public version 1.3
 * Copyright (C) 2019-2023 Jaafar EL Bakkali
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DetectorConstruction.hh"
#ifdef G4MULTITHREADED
#include "G4MTRunManager.hh"
#else
#include "G4RunManager.hh"
#endif
#include "ActionInitialization.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "Randomize.hh"
#include "RunAction.hh"
#include "Physics.hh"
int main(int argc,char** argv)
{
std::string         TERMINAL_HEADER =
"#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#\nInterDosi version 1.1: an open-source Geant4-based application for internal dosimetry in voxelized phantom\nDeveloped by Dr.Jaafar EL Bakkali, Assistant Prof. of Nuclear Physics, ERSSM, Rabat, Morocco,  10/05/ 2021\nWebpage :https://github.com/EL-Bakkali-Jaafar/G4InterDosi\n#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#\n";
G4cout <<  TERMINAL_HEADER  <<G4endl;
G4UIExecutive* ui = 0;
if ( argc == 1 ) {
ui = new G4UIExecutive(argc, argv);
}
G4Random::setTheEngine(new CLHEP::MTwistEngine);
#ifdef G4MULTITHREADED
G4MTRunManager* runManager = new G4MTRunManager;
#else
G4RunManager* runManager = new G4RunManager;
#endif
DetectorConstruction * pDetectorConstruction= new  DetectorConstruction();
runManager->SetUserInitialization(pDetectorConstruction);
Physics* physics = new Physics();
physics->SetVerboseLevel(2);
runManager->SetUserInitialization(physics);
runManager->SetUserInitialization(new ActionInitialization());  
G4VisManager* visManager = new G4VisExecutive;
visManager->RegisterGraphicsSystem (new G4DAWNFILE);
visManager->SetVerboseLevel(0);
visManager->Initialize();
G4UImanager* UImanager = G4UImanager::GetUIpointer();
if ( ! ui ) { 
G4String command = "/control/execute ";
G4String fileName = argv[1];
UImanager->ApplyCommand(command+fileName);
}
else { 
UImanager->ApplyCommand("/control/execute init_vis.mac");
ui->SessionStart();
delete ui;
}
delete visManager;
delete runManager;
}
